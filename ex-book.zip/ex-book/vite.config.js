import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative base keeps the build working on Cloudflare Pages, GitHub Pages
// or any static host. The app uses HashRouter, so no server rewrites are needed.
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
});
