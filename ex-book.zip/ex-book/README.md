# Ex-Book

**Your Book. Their Need. A Perfect Exchange.**

An Indian online book marketplace to buy, sell, list and exchange books, with large circular
multi-person exchange chains. Built with React, Vite, JavaScript and CSS. No paid services and no backend:
all data is local demo data stored in the visitor's browser (`localStorage`).

## Features

- Home, Browse, Buy, Sell, Exchange, My Listings, Messages, Login and a 9-section Dashboard
- Class 9-12 textbooks (CBSE / ICSE / State Board), storybooks, novels and more; subject, board, price, state, city and PIN filters
- Listing form with **one front-cover image only** (placeholder cover drawn when none is uploaded)
- Purchase requests, one-to-one swap requests, favourites, listing edit / pause / delete
- Demo chat (clearly labelled: nothing is delivered without a real backend)
- Circular exchange chains of any size (4, 8, 15, 25, 50+), full chain shown, every participant must approve,
  delivery tracking and cancellation handling. No chain is shown when no compatible match exists
- 50-50 price difference calculator, calculated per link (never highest vs lowest across the chain)
- City-level locations only; no payment details or delivery addresses are collected

## Run locally

Requires Node.js 18+ (20 recommended).

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # logic tests: pricing, matching, chain workflow, filters
npm run build      # production build in dist/
npm run preview    # preview the production build
```

## Upload to GitHub

```bash
git init
git add .
git commit -m "Ex-Book"
git branch -M main
# create an empty repo on github.com first, then:
git remote add origin https://github.com/<your-username>/ex-book.git
git push -u origin main
```

## Publish on Cloudflare Pages (free)

1. Cloudflare dashboard > **Workers & Pages** > **Create** > **Pages** > **Connect to Git**, pick the `ex-book` repo.
2. Build settings: **Framework preset** `Vite` (or None), **Build command** `npm run build`, **Build output directory** `dist`.
3. Environment variable (optional): `NODE_VERSION` = `20`.
4. **Save and Deploy.** Every push to `main` redeploys automatically.

The app uses hash-based routes (`/#/browse`), so deep links and refresh work without any server rewrite rules.

## Notes

- Reset the sample data any time from Dashboard > My Profile > Reset demo data.
- Real payments, real chat delivery and real accounts need a secure backend, which this demo intentionally does not include.
