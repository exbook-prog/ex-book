import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { createSeedState, STORAGE_VERSION, DEMO_USER_ID } from '../data/seed.js';
import { CATEGORY_BY_ID } from '../data/taxonomy.js';
import { uid } from '../utils/format.js';
import {
  buildChainRecord,
  approveParticipant,
  approveAllOthers,
  dispatchBook,
  confirmReceived,
  cancelChain,
  markReturned,
  simulateDelivery,
  isActiveChain,
} from '../utils/chainFlow.js';

const STORAGE_KEY = 'exbook.demo.state';
const AppContext = createContext(null);

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === STORAGE_VERSION) return parsed;
    }
  } catch {
    /* storage unavailable or corrupt - fall back to fresh demo data */
  }
  return createSeedState();
}

const note = (state, userId, text, link) => [
  { id: uid('n'), userId, text, link, ts: Date.now(), read: false },
  ...state.notifications,
];

const CANNED_REPLIES = [
  'Thanks for your message! (simulated reply)',
  'Yes, it is still available. (simulated reply)',
  'Sounds good to me. Let us confirm the details here. (simulated reply)',
  'Could you tell me which city you are in? (simulated reply)',
];

export function AppProvider({ children }) {
  const [state, setState] = useState(loadState);
  const [toasts, setToasts] = useState([]);
  const warnedRef = useRef(false);
  const stateRef = useRef(state);

  // Apply a state change synchronously. Because the updater runs immediately (not lazily inside React),
  // actions such as requestPurchase() can safely return the record they just created.
  const update = useCallback((fn) => {
    const next = fn(stateRef.current);
    if (next !== stateRef.current) {
      stateRef.current = next;
      setState(next);
    }
  }, []);

  // Persist to this browser only (localStorage). There is no server in this demo.
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      if (!warnedRef.current) {
        warnedRef.current = true;
        setToasts((t) => [...t, { id: uid('t'), msg: 'Browser storage is full or blocked, so changes will not be kept after reload.', type: 'error' }]);
      }
    }
  }, [state]);

  const toast = useCallback((msg, type = 'info') => {
    const id = uid('t');
    setToasts((t) => [...t, { id, msg, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);
  const dismissToast = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const me = useMemo(() => state.users.find((u) => u.id === state.currentUserId) || null, [state.users, state.currentUserId]);
  const usersById = useMemo(() => new Map(state.users.map((u) => [u.id, u])), [state.users]);
  const listingsById = useMemo(() => new Map(state.listings.map((l) => [l.id, l])), [state.listings]);
  const getUser = useCallback((id) => usersById.get(id) || null, [usersById]);
  const getListing = useCallback((id) => listingsById.get(id) || null, [listingsById]);

  const myFavs = useMemo(() => (me ? state.favs[me.id] || [] : []), [state.favs, me]);
  const myNotifications = useMemo(
    () => (me ? state.notifications.filter((n) => n.userId === me.id) : []),
    [state.notifications, me],
  );
  const myConversations = useMemo(
    () => (me ? state.conversations.filter((c) => c.participants.includes(me.id)) : []),
    [state.conversations, me],
  );
  const unreadMessages = useMemo(
    () => myConversations.reduce((s, c) => s + (c.unread?.[me.id] || 0), 0),
    [myConversations, me],
  );
  const myChains = useMemo(
    // Chains the user takes part in, plus chains they proposed themselves (e.g. simulated Chain Lab rings).
    () => (me ? state.chains.filter((c) => c.createdBy === me.id || c.participants.some((p) => p.userId === me.id)) : []),
    [state.chains, me],
  );

  // ---------- auth (demo only: no passwords, no server) ----------
  const login = useCallback(({ name, city, stateName }) => {
    const user = {
      id: uid('u'),
      name: name.trim(),
      city: city.trim(),
      state: stateName,
      pin: '',
      wants: [],
      bio: '',
      joined: Date.now(),
      custom: true,
    };
    update((s) => ({ ...s, users: [...s.users, user], currentUserId: user.id }));
    return user;
  }, []);
  const loginDemo = useCallback(() => update((s) => ({ ...s, currentUserId: DEMO_USER_ID })), []);
  const logout = useCallback(() => update((s) => ({ ...s, currentUserId: null })), []);

  const updateProfile = useCallback(
    (patch) => update((s) => ({ ...s, users: s.users.map((u) => (u.id === s.currentUserId ? { ...u, ...patch } : u)) })),
    [],
  );
  const addWant = useCallback((text) => {
    const clean = text.trim();
    if (!clean) return false;
    update((s) => ({
      ...s,
      users: s.users.map((u) =>
        u.id === s.currentUserId && !u.wants.some((w) => w.toLowerCase() === clean.toLowerCase())
          ? { ...u, wants: [...u.wants, clean] }
          : u,
      ),
    }));
    return true;
  }, []);
  const removeWant = useCallback(
    (text) =>
      update((s) => ({
        ...s,
        users: s.users.map((u) => (u.id === s.currentUserId ? { ...u, wants: u.wants.filter((w) => w !== text) } : u)),
      })),
    [],
  );

  // ---------- listings ----------
  const addListing = useCallback(
    (data, wants = []) => {
      const id = uid('b');
      update((s) => {
        const owner = s.users.find((u) => u.id === s.currentUserId);
        const cat = CATEGORY_BY_ID[data.category];
        const listing = {
          ...data,
          id,
          ownerId: owner.id,
          classLevel: cat?.classLevel || null,
          status: 'active',
          featured: false,
          createdAt: Date.now(),
        };
        const users = wants.length
          ? s.users.map((u) =>
              u.id === owner.id
                ? { ...u, wants: [...u.wants, ...wants.filter((w) => !u.wants.some((x) => x.toLowerCase() === w.toLowerCase()))] }
                : u,
            )
          : s.users;
        return { ...s, users, listings: [listing, ...s.listings] };
      });
      return id;
    },
    [],
  );
  const updateListing = useCallback((id, data, wants = []) => {
    update((s) => ({
      ...s,
      listings: s.listings.map((l) =>
        l.id === id ? { ...l, ...data, classLevel: CATEGORY_BY_ID[data.category]?.classLevel || null } : l,
      ),
      users: wants.length
        ? s.users.map((u) =>
            u.id === s.currentUserId
              ? { ...u, wants: [...u.wants, ...wants.filter((w) => !u.wants.some((x) => x.toLowerCase() === w.toLowerCase()))] }
              : u,
          )
        : s.users,
    }));
  }, []);
  const setListingStatus = useCallback(
    (id, status) => update((s) => ({ ...s, listings: s.listings.map((l) => (l.id === id ? { ...l, status } : l)) })),
    [],
  );
  const deleteListing = useCallback((id) => {
    update((s) => ({
      ...s,
      listings: s.listings.filter((l) => l.id !== id),
      purchases: s.purchases.map((p) => (p.listingId === id && ['pending', 'accepted'].includes(p.status) ? { ...p, status: 'cancelled' } : p)),
      exchangeRequests: s.exchangeRequests.map((x) =>
        (x.offeredId === id || x.targetId === id) && ['pending', 'accepted'].includes(x.status) ? { ...x, status: 'cancelled' } : x,
      ),
      favs: Object.fromEntries(Object.entries(s.favs).map(([k, v]) => [k, v.filter((b) => b !== id)])),
    }));
  }, []);

  const toggleFav = useCallback((listingId) => {
    update((s) => {
      if (!s.currentUserId) return s;
      const cur = s.favs[s.currentUserId] || [];
      const next = cur.includes(listingId) ? cur.filter((b) => b !== listingId) : [...cur, listingId];
      return { ...s, favs: { ...s.favs, [s.currentUserId]: next } };
    });
  }, []);

  // ---------- purchase requests ----------
  const requestPurchase = useCallback((listing, message) => {
    let created = null;
    update((s) => {
      if (s.purchases.some((p) => p.listingId === listing.id && p.buyerId === s.currentUserId && p.status === 'pending')) return s;
      created = {
        id: uid('p'),
        listingId: listing.id,
        title: listing.title,
        buyerId: s.currentUserId,
        sellerId: listing.ownerId,
        price: listing.price,
        message,
        status: 'pending',
        createdAt: Date.now(),
      };
      const seller = s.users.find((u) => u.id === listing.ownerId);
      return {
        ...s,
        purchases: [created, ...s.purchases],
        notifications: note(s, s.currentUserId, `Purchase request sent to ${seller?.name || 'the seller'} for "${listing.title}".`, '/dashboard/purchases'),
      };
    });
    return created;
  }, []);
  const respondPurchase = useCallback((id, status) => {
    update((s) => {
      const p = s.purchases.find((x) => x.id === id);
      if (!p) return s;
      const buyer = s.users.find((u) => u.id === p.buyerId);
      const text = {
        accepted: `Request for "${p.title}" accepted. Agree on handover in Messages.`,
        declined: `Request for "${p.title}" was declined.`,
        completed: `"${p.title}" marked as sold.`,
        cancelled: `Request for "${p.title}" was cancelled.`,
      }[status];
      return {
        ...s,
        purchases: s.purchases.map((x) => (x.id === id ? { ...x, status } : x)),
        listings: status === 'completed' ? s.listings.map((l) => (l.id === p.listingId ? { ...l, status: 'sold' } : l)) : s.listings,
        notifications: note(s, s.currentUserId, `${text}${status === 'accepted' && buyer ? ` (buyer: ${buyer.name})` : ''}`, '/dashboard/sales'),
      };
    });
  }, []);

  // ---------- one-to-one exchange requests ----------
  const requestExchange = useCallback((offered, target, message) => {
    let created = null;
    update((s) => {
      if (s.exchangeRequests.some((x) => x.offeredId === offered.id && x.targetId === target.id && x.status === 'pending')) return s;
      created = {
        id: uid('x'),
        fromUserId: s.currentUserId,
        toUserId: target.ownerId,
        offeredId: offered.id,
        targetId: target.id,
        message,
        status: 'pending',
        createdAt: Date.now(),
      };
      const owner = s.users.find((u) => u.id === target.ownerId);
      return {
        ...s,
        exchangeRequests: [created, ...s.exchangeRequests],
        notifications: note(s, s.currentUserId, `Exchange proposed to ${owner?.name || 'the owner'}: "${offered.title}" for "${target.title}".`, '/dashboard/exchange-requests'),
      };
    });
    return created;
  }, []);
  const respondExchange = useCallback((id, status) => {
    update((s) => {
      const x = s.exchangeRequests.find((r) => r.id === id);
      if (!x) return s;
      const listings =
        status === 'completed'
          ? s.listings.map((l) => (l.id === x.offeredId || l.id === x.targetId ? { ...l, status: 'exchanged' } : l))
          : s.listings;
      return {
        ...s,
        exchangeRequests: s.exchangeRequests.map((r) => (r.id === id ? { ...r, status } : r)),
        listings,
        notifications: note(s, s.currentUserId, `Exchange request ${status}.`, '/dashboard/exchange-requests'),
      };
    });
  }, []);

  // ---------- chat (demo: stored on this device only) ----------
  const startConversation = useCallback((listing) => {
    let convoId = null;
    update((s) => {
      const existing = s.conversations.find(
        (c) => c.listingId === listing.id && c.participants.includes(s.currentUserId) && c.participants.includes(listing.ownerId),
      );
      if (existing) {
        convoId = existing.id;
        return s;
      }
      convoId = uid('c');
      return {
        ...s,
        conversations: [
          { id: convoId, listingId: listing.id, participants: [s.currentUserId, listing.ownerId], unread: {}, messages: [] },
          ...s.conversations,
        ],
      };
    });
    return convoId;
  }, []);
  const sendMessage = useCallback((convoId, text) => {
    const clean = text.trim();
    if (!clean) return;
    update((s) => ({
      ...s,
      conversations: s.conversations.map((c) =>
        c.id === convoId ? { ...c, messages: [...c.messages, { id: uid('m'), from: s.currentUserId, text: clean.slice(0, 1000), ts: Date.now() }] } : c,
      ),
    }));
  }, []);
  const simulateReply = useCallback((convoId) => {
    update((s) => ({
      ...s,
      conversations: s.conversations.map((c) => {
        if (c.id !== convoId) return c;
        const other = c.participants.find((p) => p !== s.currentUserId);
        const text = CANNED_REPLIES[c.messages.length % CANNED_REPLIES.length];
        return { ...c, messages: [...c.messages, { id: uid('m'), from: other, text, ts: Date.now(), simulated: true }] };
      }),
    }));
  }, []);
  const markRead = useCallback((convoId) => {
    update((s) => {
      const c = s.conversations.find((x) => x.id === convoId);
      if (!c || !c.unread?.[s.currentUserId]) return s;
      return {
        ...s,
        conversations: s.conversations.map((x) => (x.id === convoId ? { ...x, unread: { ...x.unread, [s.currentUserId]: 0 } } : x)),
      };
    });
  }, []);

  // ---------- notifications ----------
  const markAllNotificationsRead = useCallback(
    () => update((s) => ({ ...s, notifications: s.notifications.map((n) => (n.userId === s.currentUserId ? { ...n, read: true } : n)) })),
    [],
  );
  const markNotificationRead = useCallback(
    (id) => update((s) => ({ ...s, notifications: s.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)) })),
    [],
  );

  // ---------- exchange chains ----------
  const proposeChain = useCallback(
    (found, { users, listings, simulated = false }) => {
      let id = null;
      update((s) => {
        const dupe = s.chains.find((c) => c.code === found.code && isActiveChain(c) && !!c.simulated === simulated);
        if (dupe) {
          id = dupe.id;
          return s;
        }
        const record = buildChainRecord(found, users, listings, { simulated, createdBy: s.currentUserId });
        id = record.id;
        return {
          ...s,
          chains: [record, ...s.chains],
          notifications: note(s, s.currentUserId, `Chain ${record.code} proposed with ${record.participants.length} participants. Waiting for everyone to approve.`, '/dashboard/chains'),
        };
      });
      return id;
    },
    [],
  );

  const applyChain = useCallback((chainId, fn) => {
    update((s) => {
      const before = s.chains.find((c) => c.id === chainId);
      if (!before) return s;
      const after = fn(before, s);
      if (after === before) return s;
      let listings = s.listings;
      let notifications = s.notifications;
      if (after.status === 'completed' && before.status !== 'completed') {
        const ids = new Set(after.participants.map((p) => p.giveListingId));
        listings = s.listings.map((l) => (ids.has(l.id) ? { ...l, status: 'exchanged' } : l));
        notifications = note(s, s.currentUserId, `Chain ${after.code} completed. All ${after.participants.length} books were exchanged.`, '/dashboard/chains');
      } else if (after.status === 'confirmed' && before.status !== 'confirmed') {
        notifications = note(s, s.currentUserId, `Chain ${after.code} confirmed by all ${after.participants.length} participants.`, '/dashboard/chains');
      } else if (after.status === 'cancelled' && before.status !== 'cancelled') {
        notifications = note(s, s.currentUserId, `Chain ${after.code} was cancelled.`, '/dashboard/chains');
      }
      return { ...s, chains: s.chains.map((c) => (c.id === chainId ? after : c)), listings, notifications };
    });
  }, []);

  const chainActions = useMemo(
    () => ({
      approve: (id, idx) => applyChain(id, (c) => approveParticipant(c, idx)),
      approveOthers: (id, myIdx) => applyChain(id, (c) => approveAllOthers(c, myIdx)),
      dispatch: (id, idx) => applyChain(id, (c) => dispatchBook(c, idx)),
      receive: (id, idx) => applyChain(id, (c) => confirmReceived(c, idx)),
      cancel: (id, byName, reason) => applyChain(id, (c) => cancelChain(c, byName, reason)),
      returned: (id, idx) => applyChain(id, (c) => markReturned(c, idx)),
      simulateDelivery: (id) => applyChain(id, (c) => simulateDelivery(c)),
    }),
    [applyChain],
  );
  const deleteChain = useCallback((id) => update((s) => ({ ...s, chains: s.chains.filter((c) => c.id !== id) })), []);

  const resetDemo = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    update(() => createSeedState());
  }, []);

  const value = {
    ...state,
    me,
    getUser,
    getListing,
    myFavs,
    myNotifications,
    myConversations,
    unreadMessages,
    myChains,
    login,
    loginDemo,
    logout,
    updateProfile,
    addWant,
    removeWant,
    addListing,
    updateListing,
    setListingStatus,
    deleteListing,
    toggleFav,
    requestPurchase,
    respondPurchase,
    requestExchange,
    respondExchange,
    startConversation,
    sendMessage,
    simulateReply,
    markRead,
    markAllNotificationsRead,
    markNotificationRead,
    proposeChain,
    chainActions,
    deleteChain,
    resetDemo,
    toast,
    dismissToast,
    toasts,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}
