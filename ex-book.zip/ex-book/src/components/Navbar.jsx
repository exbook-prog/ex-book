import { useEffect, useState } from 'react';
import { NavLink, Link, useLocation, useNavigate } from 'react-router-dom';
import Logo from './Logo.jsx';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { initials } from '../utils/format.js';

const LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/browse', label: 'Browse Books' },
  { to: '/buy', label: 'Buy' },
  { to: '/sell', label: 'Sell' },
  { to: '/exchange', label: 'Exchange' },
  { to: '/my-listings', label: 'My Listings' },
  { to: '/messages', label: 'Messages' },
];

export default function Navbar() {
  const { me, unreadMessages, myNotifications, logout, toast } = useApp();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const unreadNotes = myNotifications.filter((n) => !n.read).length;

  useEffect(() => setOpen(false), [location.pathname]);

  return (
    <header className="nav">
      <div className="container nav__inner">
        <Logo light />
        <nav className={`nav__links ${open ? 'is-open' : ''}`} aria-label="Main">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => `nav__link ${isActive ? 'is-active' : ''}`}>
              {l.label}
              {l.to === '/messages' && me && unreadMessages > 0 && <span className="dot">{unreadMessages}</span>}
            </NavLink>
          ))}
          <div className="nav__auth nav__auth--mobile">
            {me ? (
              <>
                <Link className="nav__link" to="/dashboard">Dashboard</Link>
                <button type="button" className="nav__link nav__linkbtn" onClick={() => { logout(); toast('Logged out.'); navigate('/'); }}>Log out</button>
              </>
            ) : (
              <NavLink to="/login" className="nav__link">Login</NavLink>
            )}
          </div>
        </nav>
        <div className="nav__auth nav__auth--desktop">
          {me ? (
            <>
              <Link to="/dashboard/notifications" className="icon-btn icon-btn--light" aria-label={`Notifications (${unreadNotes} unread)`}>
                <Icon name="bell" />
                {unreadNotes > 0 && <span className="dot dot--abs">{unreadNotes}</span>}
              </Link>
              <Link to="/dashboard" className="avatar-chip" title="Open your dashboard">
                <span className="avatar">{initials(me.name)}</span>
                <span className="avatar-chip__name">{me.name.split(' ')[0]}</span>
              </Link>
              <button type="button" className="icon-btn icon-btn--light" onClick={() => { logout(); toast('Logged out.'); navigate('/'); }} aria-label="Log out">
                <Icon name="logout" />
              </button>
            </>
          ) : (
            <NavLink to="/login" className="btn btn--gold btn--sm">Login</NavLink>
          )}
        </div>
        <button type="button" className="icon-btn icon-btn--light nav__burger" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label="Toggle menu">
          <Icon name={open ? 'x' : 'menu'} />
        </button>
      </div>
    </header>
  );
}
