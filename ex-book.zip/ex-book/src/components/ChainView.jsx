import { useState } from 'react';
import ChainDiagram from './ChainDiagram.jsx';
import Modal from './Modal.jsx';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { CHAIN_STATUS, APPROVAL_LABEL, DELIVERY_LABEL, chainProgress } from '../utils/chainFlow.js';
import { inr, formatDateTime, initials } from '../utils/format.js';

const CANCEL_REASONS = [
  'I no longer want to exchange',
  'My book is no longer available',
  'I could not agree on shipping',
  'The book condition did not match the listing',
  'Another reason',
];

function Pill({ tone = 'neutral', children }) {
  return <span className={`pill pill--${tone}`}>{children}</span>;
}

const approvalTone = { pending: 'gold', approved: 'green', declined: 'red' };
const deliveryTone = { not_dispatched: 'neutral', dispatched: 'gold', delivered: 'green', return_pending: 'red', returned: 'neutral', cancelled: 'neutral' };

/**
 * Full view of one exchange chain: circular diagram, who gives/receives what,
 * per-link 50-50 price differences, approvals, delivery status and cancellation.
 * `chain` is a chain record. `saved` = it exists in the user's account (actions enabled).
 */
export default function ChainView({ chain, saved = false, onPropose }) {
  const { me, chainActions, toast, deleteChain } = useApp();
  const [selected, setSelected] = useState(null);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [reason, setReason] = useState(CANCEL_REASONS[0]);

  const n = chain.participants.length;
  const myIdx = me ? chain.participants.findIndex((p) => p.userId === me.id) : -1;
  const status = CHAIN_STATUS[chain.status];
  const prog = chainProgress(chain);
  const active = chain.status !== 'cancelled' && chain.status !== 'completed';
  const canAct = saved && active;
  const sel = selected !== null ? chain.participants[selected] : null;

  const doCancel = () => {
    chainActions.cancel(chain.id, myIdx >= 0 ? chain.participants[myIdx].name : 'A participant', reason);
    setCancelOpen(false);
    toast('Chain cancelled. See the delivery column for what happens to each book.');
  };

  return (
    <section className="chain card" aria-label={`Exchange chain ${chain.code}`}>
      <header className="chain__head">
        <div>
          <p className="eyebrow">Exchange chain {chain.code}</p>
          <h3>
            {n}-person circular exchange
            {chain.simulated && <span className="pill pill--gold pill--inline">Simulated participants</span>}
          </h3>
          <p className="muted">
            Everyone gives one book and receives one book. Nothing happens until <strong>all {n}</strong> participants approve.
          </p>
        </div>
        {saved ? <Pill tone={status.tone}>{status.label}</Pill> : <Pill tone="gold">Proposed - not yet saved</Pill>}
      </header>

      <div className="chain__layout">
        <div className="chain__diagram">
          <ChainDiagram participants={chain.participants} selected={selected} onSelect={(i) => setSelected(i === selected ? null : i)} />
          {sel ? (
            <div className="chain__pick">
              <strong>{sel.name}</strong> · {sel.city}
              <br />
              gives <em>{sel.giveTitle}</em> ({inr(sel.giveValue)})
              <br />
              receives <em>{sel.receiveTitle}</em> ({inr(sel.receiveValue)})
            </div>
          ) : (
            <p className="muted small center">Select a participant on the ring to see what they give and receive.</p>
          )}
        </div>

        <div className="chain__summary">
          <div className="stats stats--2">
            <div><span>Participants</span><strong>{n}</strong></div>
            <div><span>Books exchanged</span><strong>{n}</strong></div>
            <div><span>Approvals</span><strong>{prog.approved}/{n}</strong></div>
            <div><span>Delivered</span><strong>{prog.delivered}/{n}</strong></div>
          </div>
          <div className="progress" aria-label="Approval progress">
            <div style={{ width: `${(prog.approved / n) * 100}%` }} />
          </div>

          <h4>Chain order</h4>
          <p className="chain__order">
            {n <= 12 ? (
              <>
                {chain.participants.map((p) => p.name.split(' ')[0]).join(' → ')} → {chain.participants[0].name.split(' ')[0]}
              </>
            ) : (
              <>
                {chain.participants.slice(0, 5).map((p) => p.name.split(' ')[0]).join(' → ')} → … ({n - 6} more) …{' '}
                → {chain.participants[n - 1].name.split(' ')[0]} → {chain.participants[0].name.split(' ')[0]}
              </>
            )}
          </p>

          {!saved && (
            <div className="alert alert--info">
              <Icon name="info" size={16} />
              <span>This chain is a proposal found by the matcher. Proposing it creates the approval round for all {n} participants.</span>
            </div>
          )}
          {saved && chain.status === 'awaiting_approval' && myIdx >= 0 && (
            <div className="actions-row">
              {chain.participants[myIdx].approval === 'pending' ? (
                <button type="button" className="btn btn--primary" onClick={() => { chainActions.approve(chain.id, myIdx); toast('You approved the chain.'); }}>
                  <Icon name="check" size={16} /> I approve this chain
                </button>
              ) : (
                <Pill tone="green">You approved</Pill>
              )}
              <button type="button" className="btn btn--ghost" onClick={() => { chainActions.approveOthers(chain.id, myIdx); toast('Demo: the other participants approved.'); }}>
                Demo: simulate everyone else approving
              </button>
            </div>
          )}
          {saved && chain.status === 'awaiting_approval' && myIdx < 0 && (
            <div className="actions-row">
              <button type="button" className="btn btn--ghost" onClick={() => { chainActions.approveOthers(chain.id, -1); toast('Demo: all participants approved.'); }}>
                Demo: simulate all approvals
              </button>
            </div>
          )}
          {saved && (chain.status === 'confirmed' || chain.status === 'in_delivery') && (
            <div className="actions-row">
              <button type="button" className="btn btn--ghost" onClick={() => { chainActions.simulateDelivery(chain.id); toast('Demo: all books dispatched and delivered.'); }}>
                Demo: simulate full delivery
              </button>
            </div>
          )}
          {canAct && (
            <div className="actions-row">
              <button type="button" className="btn btn--danger-ghost" onClick={() => setCancelOpen(true)}>
                Cancel this chain
              </button>
            </div>
          )}
          {!saved && onPropose && (
            <button type="button" className="btn btn--primary btn--lg" onClick={onPropose}>
              <Icon name="repeat" size={18} /> Propose this {n}-person chain
            </button>
          )}
          {saved && !active && (
            <div className="actions-row">
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => { deleteChain(chain.id); toast('Chain removed from your list.'); }}>
                <Icon name="trash" size={14} /> Remove from my list
              </button>
            </div>
          )}
        </div>
      </div>

      {chain.status === 'cancelled' && chain.cancelSummary && (
        <div className="alert alert--danger">
          <Icon name="alert" size={18} />
          <div>
            <strong>Cancelled by {chain.cancelSummary.by}.</strong> Reason: {chain.cancelSummary.reason}.
            <br />
            {chain.cancelSummary.returns > 0 && <>{chain.cancelSummary.returns} dispatched book(s) must be returned to their owners. </>}
            {chain.cancelSummary.delivered > 0 && (
              <>{chain.cancelSummary.delivered} book(s) were already delivered; those two readers should agree on a return in Messages. </>
            )}
            {chain.cancelSummary.returns === 0 && chain.cancelSummary.delivered === 0 && <>No books had been dispatched, so every owner keeps their book.</>}
          </div>
        </div>
      )}

      <h4 className="chain__h">Who gives and receives what</h4>
      <div className="table-wrap">
        <table className="table table--chain">
          <thead>
            <tr>
              <th>#</th>
              <th>Reader</th>
              <th>Gives (to next reader)</th>
              <th>Receives (from previous)</th>
              <th>Approval</th>
              <th>Delivery of their book</th>
              {canAct && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {chain.participants.map((p, i) => {
              const next = chain.participants[(i + 1) % n];
              const isMe = i === myIdx;
              return (
                <tr key={i} className={isMe ? 'is-me' : ''}>
                  <td data-label="#">{i + 1}</td>
                  <td data-label="Reader">
                    <span className="person">
                      <span className="avatar avatar--sm">{initials(p.name)}</span>
                      <span>
                        {p.name}
                        {isMe && <em> (you)</em>}
                        <small>{p.city}{p.state ? `, ${p.state}` : ''}</small>
                      </span>
                    </span>
                  </td>
                  <td data-label="Gives">
                    <strong>{p.giveTitle}</strong>
                    <small>{inr(p.giveValue)} → {next.name.split(' ')[0]}</small>
                  </td>
                  <td data-label="Receives">
                    <strong>{p.receiveTitle}</strong>
                    <small>{inr(p.receiveValue)}{p.wantMatched ? ` · matches “${p.wantMatched}”` : ''}</small>
                  </td>
                  <td data-label="Approval"><Pill tone={approvalTone[p.approval]}>{APPROVAL_LABEL[p.approval]}</Pill></td>
                  <td data-label="Delivery"><Pill tone={deliveryTone[p.delivery]}>{DELIVERY_LABEL[p.delivery]}</Pill></td>
                  {canAct && (
                    <td data-label="Actions" className="cell-actions">
                      {chain.status === 'awaiting_approval' && p.approval === 'pending' && (
                        <button type="button" className="btn btn--ghost btn--xs" onClick={() => { chainActions.approve(chain.id, i); }}>
                          Demo: approve as {p.name.split(' ')[0]}
                        </button>
                      )}
                      {(chain.status === 'confirmed' || chain.status === 'in_delivery') && p.delivery === 'not_dispatched' && (
                        <button type="button" className="btn btn--ghost btn--xs" onClick={() => chainActions.dispatch(chain.id, i)}>
                          {isMe ? 'Mark my book dispatched' : 'Demo: mark dispatched'}
                        </button>
                      )}
                      {chain.status === 'in_delivery' && p.delivery === 'dispatched' && (
                        <button type="button" className="btn btn--ghost btn--xs" onClick={() => chainActions.receive(chain.id, i)}>
                          {(i + 1) % n === myIdx ? 'I received it' : `Demo: ${next.name.split(' ')[0]} received`}
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {chain.status === 'cancelled' && chain.participants.some((p) => p.delivery === 'return_pending') && (
        <div className="actions-row">
          {chain.participants.map((p, i) =>
            p.delivery === 'return_pending' ? (
              <button key={i} type="button" className="btn btn--ghost btn--sm" onClick={() => chainActions.returned(chain.id, i)}>
                Mark “{p.giveTitle}” returned to {p.name.split(' ')[0]}
              </button>
            ) : null,
          )}
        </div>
      )}

      <h4 className="chain__h">Price difference for every link (50-50 rule)</h4>
      <p className="muted small">
        Each link compares the agreed values of the two books in that link. The owner of the lower-value book pays the difference:
        50% to the owner of the higher-value book and 50% to Ex-Book. Links are never combined across the chain.
      </p>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>Link</th>
              <th>Book A (owner)</th>
              <th>Book B (owner)</th>
              <th>Difference</th>
              <th>Pays</th>
              <th>Owner share</th>
              <th>Ex-Book</th>
            </tr>
          </thead>
          <tbody>
            {chain.links.map((l) => {
              const A = chain.participants[l.from];
              const B = chain.participants[l.to];
              return (
                <tr key={l.index}>
                  <td data-label="Link">{l.from + 1} ↔ {l.to + 1}</td>
                  <td data-label="Book A"><strong>{inr(l.valueA)}</strong><small>{A.name.split(' ')[0]}</small></td>
                  <td data-label="Book B"><strong>{inr(l.valueB)}</strong><small>{B.name.split(' ')[0]}</small></td>
                  <td data-label="Difference">{inr(l.difference)}</td>
                  <td data-label="Pays">{l.payerIdx === null ? 'Nobody' : chain.participants[l.payerIdx].name.split(' ')[0]}</td>
                  <td data-label="Owner share">
                    {l.receiverIdx === null ? '-' : `${inr(l.ownerShare)} → ${chain.participants[l.receiverIdx].name.split(' ')[0]}`}
                  </td>
                  <td data-label="Ex-Book" className="gold">{inr(l.commission)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="stats stats--3">
        <div><span>Links</span><strong>{chain.links.length}</strong></div>
        <div><span>Total price differences</span><strong>{inr(chain.totalDifference)}</strong></div>
        <div><span>Ex-Book commission</span><strong className="gold">{inr(chain.totalCommission)}</strong></div>
      </div>
      <details className="details">
        <summary>Net amount per participant</summary>
        <ul className="net-list">
          {chain.participants.map((p, i) => {
            const v = chain.net[i];
            return (
              <li key={i}>
                <span>{p.name}</span>
                <strong className={v > 0 ? 'pos' : v < 0 ? 'neg' : ''}>{v > 0 ? `+${inr(v)}` : v < 0 ? `-${inr(Math.abs(v))}` : inr(0)}</strong>
              </li>
            );
          })}
        </ul>
      </details>
      <p className="muted small">
        <Icon name="info" size={14} /> These amounts are calculated for information. This demo does not collect or process any payment.
      </p>

      {saved && (
        <>
          <h4 className="chain__h">Activity</h4>
          <ol className="timeline">
            {chain.log.slice(0, 12).map((l, i) => (
              <li key={i}>
                <time>{formatDateTime(l.ts)}</time>
                <span>{l.text}</span>
              </li>
            ))}
          </ol>
        </>
      )}

      {cancelOpen && (
        <Modal title="Cancel this exchange chain?" onClose={() => setCancelOpen(false)}>
          <p>
            Cancelling stops the whole chain for all {n} participants, because every link depends on the others.
          </p>
          <ul className="plain-list">
            <li>Books <strong>not yet dispatched</strong> stay with their owners.</li>
            <li>Books <strong>on the way</strong> are marked “return pending” so they go back to their owners.</li>
            <li>Books <strong>already delivered</strong> stay with the receiver; the two readers agree on a return in Messages.</li>
          </ul>
          <label className="field">
            <span>Reason</span>
            <select value={reason} onChange={(e) => setReason(e.target.value)}>
              {CANCEL_REASONS.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
          <div className="modal__actions">
            <button type="button" className="btn btn--ghost" onClick={() => setCancelOpen(false)}>Keep the chain</button>
            <button type="button" className="btn btn--danger" onClick={doCancel}>Cancel the chain</button>
          </div>
        </Modal>
      )}
    </section>
  );
}
