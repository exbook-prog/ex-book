import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import BookCover from './BookCover.jsx';
import Modal from './Modal.jsx';
import Icon from './Icon.jsx';
import { TypeBadges } from './BookCard.jsx';
import { useApp } from '../context/AppContext.jsx';
import { inr, timeAgo } from '../utils/format.js';

export const REQUEST_STATUS = {
  pending: { label: 'Pending', tone: 'gold' },
  accepted: { label: 'Accepted', tone: 'green' },
  declined: { label: 'Declined', tone: 'red' },
  completed: { label: 'Completed', tone: 'green' },
  cancelled: { label: 'Cancelled', tone: 'neutral' },
};

export function StatusPill({ status }) {
  const s = REQUEST_STATUS[status] || { label: status, tone: 'neutral' };
  return <span className={`pill pill--${s.tone}`}>{s.label}</span>;
}

/** Seller view of purchase requests with accept / decline / complete actions. */
export function SaleRequestRow({ req }) {
  const { getUser, getListing, respondPurchase, startConversation, toast } = useApp();
  const navigate = useNavigate();
  const buyer = getUser(req.buyerId);
  const listing = getListing(req.listingId);
  const chat = () => {
    if (!listing) return;
    const cid = startConversation(listing);
    navigate(`/messages/${cid}`);
  };
  return (
    <li className="req">
      <div className="req__main">
        <strong>{buyer?.name || 'A reader'}</strong> wants <em>{req.title}</em> for {inr(req.price)}
        <small>{timeAgo(req.createdAt)} · “{req.message}”</small>
      </div>
      <div className="req__side">
        <StatusPill status={req.status} />
        {req.status === 'pending' && (
          <>
            <button type="button" className="btn btn--primary btn--xs" onClick={() => { respondPurchase(req.id, 'accepted'); toast('Request accepted. Agree on handover in Messages.', 'success'); }}>Accept</button>
            <button type="button" className="btn btn--ghost btn--xs" onClick={() => respondPurchase(req.id, 'declined')}>Decline</button>
          </>
        )}
        {req.status === 'accepted' && (
          <>
            <button type="button" className="btn btn--gold btn--xs" onClick={() => { respondPurchase(req.id, 'completed'); toast('Marked as sold.', 'success'); }}>Mark as sold</button>
            {listing && (
              <button type="button" className="btn btn--ghost btn--xs" onClick={chat}>Message buyer</button>
            )}
          </>
        )}
      </div>
    </li>
  );
}

/** Create / edit / delete / pause listings and see purchase requests for each one. */
export default function ListingManager() {
  const { me, listings, purchases, exchangeRequests, setListingStatus, deleteListing, toast } = useApp();
  const [toDelete, setToDelete] = useState(null);
  const mine = useMemo(() => listings.filter((l) => l.ownerId === me.id), [listings, me]);

  if (!mine.length) {
    return (
      <div className="empty">
        <Icon name="book" size={36} />
        <p>You have not listed any books yet.</p>
        <Link to="/sell" className="btn btn--primary">List your first book</Link>
      </div>
    );
  }

  return (
    <>
      <div className="actions-row">
        <Link to="/sell" className="btn btn--primary"><Icon name="plus" size={16} /> List another book</Link>
      </div>
      <ul className="manage-list">
        {mine.map((l) => {
          const reqs = purchases.filter((p) => p.listingId === l.id);
          const pending = reqs.filter((p) => p.status === 'pending').length;
          const swaps = exchangeRequests.filter((x) => x.targetId === l.id && x.status === 'pending').length;
          return (
            <li key={l.id} className="manage card">
              <div className="manage__cover"><BookCover book={l} size="sm" /></div>
              <div className="manage__body">
                <div className="manage__top">
                  <h3><Link to={`/book/${l.id}`}>{l.title}</Link></h3>
                  <span className={`pill pill--${l.status === 'active' ? 'green' : 'neutral'}`}>{l.status}</span>
                </div>
                <p className="muted small">{l.author} · {l.condition} · {l.city}</p>
                <div className="manage__meta">
                  <TypeBadges book={l} />
                  {l.price != null && <span>Price <strong>{inr(l.price)}</strong></span>}
                  {l.exchangeValue != null && <span>Swap value <strong>{inr(l.exchangeValue)}</strong></span>}
                  <span>{pending} purchase request{pending === 1 ? '' : 's'}</span>
                  {swaps > 0 && <span>{swaps} exchange proposal{swaps === 1 ? '' : 's'}</span>}
                </div>
                <div className="actions-row">
                  <Link to={`/sell?edit=${l.id}`} className="btn btn--ghost btn--sm"><Icon name="edit" size={14} /> Edit</Link>
                  {l.status === 'active' && <button type="button" className="btn btn--ghost btn--sm" onClick={() => { setListingStatus(l.id, 'paused'); toast('Listing paused. It is hidden from search.'); }}>Pause</button>}
                  {l.status === 'paused' && <button type="button" className="btn btn--ghost btn--sm" onClick={() => { setListingStatus(l.id, 'active'); toast('Listing is live again.'); }}>Make live</button>}
                  <button type="button" className="btn btn--danger-ghost btn--sm" onClick={() => setToDelete(l)}><Icon name="trash" size={14} /> Delete</button>
                </div>
                {reqs.length > 0 && (
                  <ul className="req-list">
                    {reqs.map((r) => <SaleRequestRow key={r.id} req={r} />)}
                  </ul>
                )}
              </div>
            </li>
          );
        })}
      </ul>

      {toDelete && (
        <Modal title="Delete this listing?" onClose={() => setToDelete(null)}>
          <p>This removes <strong>{toDelete.title}</strong> and cancels its pending requests. This cannot be undone.</p>
          <div className="modal__actions">
            <button type="button" className="btn btn--ghost" onClick={() => setToDelete(null)}>Keep it</button>
            <button type="button" className="btn btn--danger" onClick={() => { deleteListing(toDelete.id); setToDelete(null); toast('Listing deleted.'); }}>Delete</button>
          </div>
        </Modal>
      )}
    </>
  );
}
