import { calcLink } from '../utils/pricing.js';
import { inr } from '../utils/format.js';

/**
 * Shows the 50-50 rule for ONE link (two books).
 * labelA / labelB describe the owners, e.g. "Owner of Book A" or a person's name.
 */
export default function PriceBreakdown({ valueA, valueB, labelA = 'Book A', labelB = 'Book B', compact = false }) {
  const r = calcLink(valueA, valueB);
  if (!r) return <p className="muted small">Enter two valid book values to see the price difference.</p>;

  if (r.equal) {
    return (
      <div className={`breakdown ${compact ? 'breakdown--compact' : ''}`}>
        <p className="breakdown__line">
          Both books are valued at <strong>{inr(r.valueA)}</strong>. No price difference to pay.
        </p>
      </div>
    );
  }

  const payerLabel = r.payer === 'A' ? labelA : labelB;
  const receiverLabel = r.receiver === 'A' ? labelA : labelB;
  const lowerVal = r.payer === 'A' ? r.valueA : r.valueB;
  const higherVal = r.payer === 'A' ? r.valueB : r.valueA;

  return (
    <div className={`breakdown ${compact ? 'breakdown--compact' : ''}`}>
      <p className="breakdown__line">
        {labelA} {inr(r.valueA)} &nbsp;vs&nbsp; {labelB} {inr(r.valueB)}
      </p>
      <dl className="breakdown__grid">
        <div>
          <dt>Difference</dt>
          <dd>{inr(higherVal)} &minus; {inr(lowerVal)} = <strong>{inr(r.difference)}</strong></dd>
        </div>
        <div>
          <dt>Pays the difference</dt>
          <dd>{payerLabel} <small>(lower-value book)</small></dd>
        </div>
        <div>
          <dt>50% to {receiverLabel}</dt>
          <dd className="pos">{inr(r.ownerShare)}</dd>
        </div>
        <div>
          <dt>50% to Ex-Book</dt>
          <dd className="gold">{inr(r.commission)}</dd>
        </div>
      </dl>
    </div>
  );
}
