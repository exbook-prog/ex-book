import { Link, useNavigate } from 'react-router-dom';
import BookCover from './BookCover.jsx';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { inr } from '../utils/format.js';

export function TypeBadges({ book }) {
  return (
    <div className="badges">
      {(book.type === 'sell' || book.type === 'both') && <span className="badge badge--sell">Sell</span>}
      {(book.type === 'exchange' || book.type === 'both') && <span className="badge badge--swap">Exchange</span>}
    </div>
  );
}

export default function BookCard({ book }) {
  const { me, myFavs, toggleFav, toast } = useApp();
  const navigate = useNavigate();
  const saved = myFavs.includes(book.id);

  const onFav = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!me) {
      toast('Log in to save books.');
      navigate('/login', { state: { from: '/browse' } });
      return;
    }
    toggleFav(book.id);
    toast(saved ? 'Removed from saved books.' : 'Saved to your books.');
  };

  return (
    <article className="card book-card">
      <Link to={`/book/${book.id}`} className="book-card__link" aria-label={`${book.title} by ${book.author}`}>
        <div className="book-card__cover">
          <BookCover book={book} />
          <TypeBadges book={book} />
        </div>
        <div className="book-card__body">
          <h3 className="book-card__title">{book.title}</h3>
          <p className="book-card__author">{book.author}</p>
          <p className="book-card__meta">
            <span>{book.condition}</span>
            {book.classLevel && <span>Class {book.classLevel}</span>}
            {book.board && <span>{book.board}</span>}
          </p>
          <div className="book-card__foot">
            <div className="book-card__price">
              {book.price != null && <strong>{inr(book.price)}</strong>}
              {book.exchangeValue != null && (
                <small>
                  <Icon name="repeat" size={12} /> Swap value {inr(book.exchangeValue)}
                </small>
              )}
            </div>
            <span className="book-card__loc">
              <Icon name="pin" size={13} /> {book.city}
            </span>
          </div>
        </div>
      </Link>
      <button
        type="button"
        className={`fav ${saved ? 'fav--on' : ''}`}
        onClick={onFav}
        aria-pressed={saved}
        aria-label={saved ? `Remove ${book.title} from saved books` : `Save ${book.title}`}
      >
        <Icon name="heart" size={18} filled={saved} />
      </button>
    </article>
  );
}

export function BookGrid({ books, empty }) {
  if (!books.length) {
    return (
      <div className="empty">
        <Icon name="book" size={36} />
        <p>{empty || 'No books match your search yet.'}</p>
      </div>
    );
  }
  return (
    <div className="book-grid">
      {books.map((b) => (
        <BookCard key={b.id} book={b} />
      ))}
    </div>
  );
}
