import { CATEGORY_BY_ID } from '../data/taxonomy.js';
import { hashStr } from '../utils/format.js';

// Deep, bookstore-style cloth colours (forest, burgundy, navy, plum, ochre, teal ...).
const PALETTES = [
  ['#14342b', '#2b6552'],
  ['#5b1f2b', '#8c3b4a'],
  ['#1d2f4f', '#3d5a8c'],
  ['#3b2a50', '#6b4f8a'],
  ['#6e4510', '#b8813a'],
  ['#12423f', '#2f7c76'],
  ['#3d3a2a', '#7c7752'],
  ['#6a2f1b', '#a45a3a'],
];

/**
 * Every book has exactly ONE image: its FRONT COVER.
 * If the seller uploaded a cover it is shown; otherwise a generated placeholder front cover is drawn.
 */
export default function BookCover({ book, size = 'md', className = '' }) {
  if (book.cover) {
    return (
      <div className={`cover cover--img cover--${size} ${className}`}>
        <img src={book.cover} alt={`Front cover of ${book.title}`} loading="lazy" />
      </div>
    );
  }
  const [c1, c2] = PALETTES[hashStr(book.title) % PALETTES.length];
  const cat = CATEGORY_BY_ID[book.category];
  const label = book.classLevel ? `CLASS ${book.classLevel}${book.board ? ` · ${book.board}` : ''}` : (cat?.short || '').toUpperCase();
  const len = book.title.length;
  const titleClass = len > 38 ? 'cover__title--xs' : len > 24 ? 'cover__title--sm' : '';

  return (
    <div
      className={`cover cover--${size} ${className}`}
      style={{ '--c1': c1, '--c2': c2 }}
      role="img"
      aria-label={`Placeholder front cover of ${book.title} by ${book.author}`}
    >
      <div className="cover__frame">
        <span className="cover__label">{label}</span>
        <span className={`cover__title ${titleClass}`}>{book.title}</span>
        <span className="cover__orn" aria-hidden="true">
          <i />
          <b />
          <i />
        </span>
        <span className="cover__author">{book.author}</span>
        {book.subject && <span className="cover__subject">{book.subject}</span>}
      </div>
    </div>
  );
}
