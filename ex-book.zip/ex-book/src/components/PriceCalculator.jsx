import { useMemo, useState } from 'react';
import Icon from './Icon.jsx';
import PriceBreakdown from './PriceBreakdown.jsx';
import { calcChain } from '../utils/pricing.js';
import { inr, letterLabel } from '../utils/format.js';

const MAX_PARTICIPANTS = 60;
const DEFAULT_CHAIN = ['200', '350', '120', '280'];

function parseValue(v) {
  if (v === '' || v === null) return NaN;
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : NaN;
}

export default function PriceCalculator() {
  const [mode, setMode] = useState('pair');
  const [a, setA] = useState('200');
  const [b, setB] = useState('350');
  const [values, setValues] = useState(DEFAULT_CHAIN);
  const [closed, setClosed] = useState(true);

  const numeric = useMemo(() => values.map(parseValue), [values]);
  const chainValid = numeric.length >= 2 && numeric.every((n) => !Number.isNaN(n));
  const chain = useMemo(() => (chainValid ? calcChain(numeric, { closed }) : null), [chainValid, numeric, closed]);

  const setValue = (i, v) => setValues((arr) => arr.map((x, idx) => (idx === i ? v : x)));
  const addRow = () => setValues((arr) => (arr.length < MAX_PARTICIPANTS ? [...arr, ''] : arr));
  const removeRow = (i) => setValues((arr) => (arr.length > 2 ? arr.filter((_, idx) => idx !== i) : arr));
  const setCount = (n) => {
    const count = Math.max(2, Math.min(MAX_PARTICIPANTS, Number(n) || 2));
    setValues((arr) => {
      if (count <= arr.length) return arr.slice(0, count);
      const extra = Array.from({ length: count - arr.length }, (_, i) => String(120 + ((arr.length + i) * 37) % 260));
      return [...arr, ...extra];
    });
  };

  return (
    <div className="card calc" id="calculator">
      <div className="calc__head">
        <div>
          <h3>
            <Icon name="calc" /> 50-50 price difference calculator
          </h3>
          <p className="muted">
            The owner of the lower-value book pays the difference. 50% goes to the owner of the higher-value book and 50% goes to
            Ex-Book. In a chain, every link is calculated on its own.
          </p>
        </div>
        <div className="tabs tabs--pill" role="tablist" aria-label="Calculator mode">
          <button type="button" role="tab" aria-selected={mode === 'pair'} className={mode === 'pair' ? 'is-active' : ''} onClick={() => setMode('pair')}>
            Two books
          </button>
          <button type="button" role="tab" aria-selected={mode === 'chain'} className={mode === 'chain' ? 'is-active' : ''} onClick={() => setMode('chain')}>
            Whole chain
          </button>
        </div>
      </div>

      {mode === 'pair' && (
        <div className="calc__body">
          <div className="calc__inputs">
            <label className="field">
              <span>Book A value (₹)</span>
              <input type="number" inputMode="decimal" min="0" step="1" value={a} onChange={(e) => setA(e.target.value)} />
            </label>
            <label className="field">
              <span>Book B value (₹)</span>
              <input type="number" inputMode="decimal" min="0" step="1" value={b} onChange={(e) => setB(e.target.value)} />
            </label>
            <button type="button" className="btn btn--ghost btn--sm" onClick={() => { setA('200'); setB('350'); }}>
              Use the example (₹200 and ₹350)
            </button>
          </div>
          <PriceBreakdown valueA={parseValue(a)} valueB={parseValue(b)} labelA="Owner of Book A" labelB="Owner of Book B" />
        </div>
      )}

      {mode === 'chain' && (
        <div className="calc__body">
          <div className="calc__toolbar">
            <label className="field field--inline">
              <span>Participants</span>
              <input type="number" min="2" max={MAX_PARTICIPANTS} value={values.length} onChange={(e) => setCount(e.target.value)} />
            </label>
            <div className="chips">
              {[4, 8, 15, 25, 50].map((n) => (
                <button key={n} type="button" className="chip" onClick={() => setCount(n)}>
                  {n}
                </button>
              ))}
            </div>
            <label className="check">
              <input type="checkbox" checked={closed} onChange={(e) => setClosed(e.target.checked)} />
              <span>Circular (last book links back to the first)</span>
            </label>
          </div>

          <div className="calc__values">
            {values.map((v, i) => (
              <div className="calc__value" key={i}>
                <label>
                  <span>Book {letterLabel(i)} (₹)</span>
                  <input type="number" min="0" inputMode="decimal" value={v} onChange={(e) => setValue(i, e.target.value)} aria-label={`Value of book ${letterLabel(i)}`} />
                </label>
                <button type="button" className="icon-btn" onClick={() => removeRow(i)} disabled={values.length <= 2} aria-label={`Remove book ${letterLabel(i)}`}>
                  <Icon name="x" size={16} />
                </button>
              </div>
            ))}
            <button type="button" className="btn btn--ghost btn--sm" onClick={addRow} disabled={values.length >= MAX_PARTICIPANTS}>
              <Icon name="plus" size={16} /> Add a book
            </button>
          </div>

          {!chainValid && <p className="alert alert--warn">Fill in a valid value (0 or more) for every book to calculate.</p>}

          {chain && chain.valid && (
            <>
              <div className="stats stats--3">
                <div><span>Links calculated</span><strong>{chain.links.length}</strong></div>
                <div><span>Total price differences</span><strong>{inr(chain.totalDifference)}</strong></div>
                <div><span>Ex-Book share (50%)</span><strong className="gold">{inr(chain.totalCommission)}</strong></div>
              </div>
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Link</th>
                      <th>Values</th>
                      <th>Difference</th>
                      <th>Pays</th>
                      <th>Owner share</th>
                      <th>Ex-Book</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chain.links.map((l) => (
                      <tr key={l.index}>
                        <td data-label="Link">
                          {letterLabel(l.from)} ↔ {letterLabel(l.to)}
                        </td>
                        <td data-label="Values">
                          {inr(l.valueA)} vs {inr(l.valueB)}
                        </td>
                        <td data-label="Difference">{inr(l.difference)}</td>
                        <td data-label="Pays">{l.payerIdx === null ? 'Nobody' : `Owner of ${letterLabel(l.payerIdx)}`}</td>
                        <td data-label="Owner share">
                          {l.receiverIdx === null ? '-' : `${inr(l.ownerShare)} → ${letterLabel(l.receiverIdx)}`}
                        </td>
                        <td data-label="Ex-Book" className="gold">{inr(l.commission)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <details className="details">
                <summary>Net result for each participant</summary>
                <ul className="net-list">
                  {chain.net.map((n, i) => (
                    <li key={i}>
                      <span>Owner of Book {letterLabel(i)}</span>
                      <strong className={n > 0 ? 'pos' : n < 0 ? 'neg' : ''}>{n > 0 ? `+${inr(n)}` : n < 0 ? `-${inr(Math.abs(n))}` : inr(0)}</strong>
                    </li>
                  ))}
                </ul>
                <p className="muted small">
                  Each owner can appear in two links (their book is compared with the book before and the book after). The figures
                  above add those together. Ex-Book&apos;s share is the only money that does not go to another participant.
                </p>
              </details>
            </>
          )}
        </div>
      )}
      <p className="muted small calc__foot">
        <Icon name="info" size={14} /> This is a calculator only. The demo does not collect or process payments.
      </p>
    </div>
  );
}
