import { initials } from '../utils/format.js';

/**
 * Circular diagram of an exchange chain with any number of participants.
 * Arrow i -> i+1 means "participant i gives their book to participant i+1".
 */
export default function ChainDiagram({ participants, selected = null, onSelect, size = 440 }) {
  const n = participants.length;
  const cx = size / 2;
  const cy = size / 2;
  const nodeR = n <= 6 ? 26 : n <= 12 ? 21 : n <= 20 ? 16 : n <= 35 ? 11 : 8;
  const R = size / 2 - nodeR - (n <= 12 ? 56 : 18);
  const showInitials = n <= 35;
  const showNames = n <= 10;

  const pos = participants.map((_, i) => {
    const a = -Math.PI / 2 + (2 * Math.PI * i) / n;
    return { x: cx + R * Math.cos(a), y: cy + R * Math.sin(a), a };
  });

  const arrows = pos.map((p, i) => {
    if (n < 2) return null;
    const q = pos[(i + 1) % n];
    const dx = q.x - p.x;
    const dy = q.y - p.y;
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len;
    const uy = dy / len;
    const pad = nodeR + 3;
    const sx = p.x + ux * pad;
    const sy = p.y + uy * pad;
    const ex = q.x - ux * (pad + 3);
    const ey = q.y - uy * (pad + 3);
    const bend = Math.min(26, len * 0.18);
    const mx = (sx + ex) / 2 + uy * bend; // bend to the right of travel
    const my = (sy + ey) / 2 - ux * bend;
    return `M${sx.toFixed(1)},${sy.toFixed(1)} Q${mx.toFixed(1)},${my.toFixed(1)} ${ex.toFixed(1)},${ey.toFixed(1)}`;
  });

  return (
    <svg className="chain-svg" viewBox={`0 0 ${size} ${size}`} role="img" aria-label={`Circular exchange chain with ${n} participants`}>
      <defs>
        <marker id={`arrow-${n}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth={n > 25 ? 4 : 6} markerHeight={n > 25 ? 4 : 6} orient="auto-start-reverse">
          <path d="M0,0 L10,5 L0,10 z" fill="#b8913b" />
        </marker>
      </defs>
      <circle cx={cx} cy={cy} r={R} className="chain-svg__ring" />
      {arrows.map((d, i) => (
        <path key={i} d={d} className="chain-svg__arrow" markerEnd={`url(#arrow-${n})`} strokeWidth={n > 25 ? 1.2 : 2} fill="none" />
      ))}
      {participants.map((p, i) => {
        const { x, y, a } = pos[i];
        const label = p.name.split(' ')[0];
        const lx = cx + (R + nodeR + 20) * Math.cos(a);
        const ly = cy + (R + nodeR + 20) * Math.sin(a);
        return (
          <g
            key={i}
            className={`chain-node chain-node--${p.approval} ${selected === i ? 'is-selected' : ''} ${onSelect ? 'is-clickable' : ''}`}
            onClick={onSelect ? () => onSelect(i) : undefined}
            tabIndex={onSelect ? 0 : undefined}
            onKeyDown={onSelect ? (e) => (e.key === 'Enter' || e.key === ' ') && onSelect(i) : undefined}
            role={onSelect ? 'button' : undefined}
            aria-label={`${i + 1}. ${p.name}, ${p.city}`}
          >
            <title>{`${i + 1}. ${p.name} (${p.city}) gives "${p.giveTitle}"`}</title>
            <circle cx={x} cy={y} r={nodeR} />
            {showInitials && (
              <text x={x} y={y} textAnchor="middle" dominantBaseline="central" fontSize={nodeR * 0.72}>
                {initials(p.name)}
              </text>
            )}
            {showNames && (
              <text x={lx} y={ly} textAnchor="middle" dominantBaseline="central" className="chain-node__label" fontSize="12">
                {label}
              </text>
            )}
          </g>
        );
      })}
      <text x={cx} y={cy - 8} textAnchor="middle" className="chain-svg__center-big">
        {n}
      </text>
      <text x={cx} y={cy + 14} textAnchor="middle" className="chain-svg__center-small">
        readers · 1 book each
      </text>
    </svg>
  );
}
