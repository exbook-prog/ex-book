import { useMemo, useState } from 'react';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { isExchangeEligible, listingTokens, wantMatches } from '../utils/matching.js';

const SUGGESTIONS = ['Class 10 Science', 'Class 12 Physics', 'Harry Potter', 'Wings of Fire', 'Class 11 Commerce', 'Ruskin Bond'];

/** Books I want to receive in an exchange. These drive the circular-chain matching. */
export default function WantsEditor() {
  const { me, listings, addWant, removeWant, toast } = useApp();
  const [text, setText] = useState('');

  const counts = useMemo(() => {
    const others = listings.filter((l) => isExchangeEligible(l) && l.ownerId !== me?.id);
    const tokens = others.map((l) => listingTokens(l));
    const out = {};
    (me?.wants || []).forEach((w) => {
      out[w] = tokens.filter((t) => wantMatches(w, t)).length;
    });
    return out;
  }, [listings, me]);

  if (!me) return null;

  const add = (value) => {
    const v = (value ?? text).trim();
    if (v.length < 2) {
      toast('Type at least two characters, for example a title or "Class 10 Science".', 'error');
      return;
    }
    if (v.length > 80) {
      toast('Keep wants under 80 characters.', 'error');
      return;
    }
    if (me.wants.some((w) => w.toLowerCase() === v.toLowerCase())) {
      toast('You already have that want.');
      return;
    }
    addWant(v);
    setText('');
  };

  return (
    <div className="wants">
      <form
        className="wants__form"
        onSubmit={(e) => {
          e.preventDefault();
          add();
        }}
      >
        <label className="field">
          <span>Add a book you would like to receive</span>
          <div className="input-row">
            <input
              type="text"
              value={text}
              maxLength={80}
              onChange={(e) => setText(e.target.value)}
              placeholder='A title or keywords, e.g. "Class 11 Physics" or "The Hobbit"'
            />
            <button type="submit" className="btn btn--primary">
              <Icon name="plus" size={16} /> Add
            </button>
          </div>
        </label>
      </form>
      <div className="chips">
        {SUGGESTIONS.filter((s) => !me.wants.includes(s)).map((s) => (
          <button key={s} type="button" className="chip chip--ghost" onClick={() => add(s)}>
            + {s}
          </button>
        ))}
      </div>
      {me.wants.length === 0 ? (
        <p className="muted small">No wants yet. Chains need to know what you would like to receive.</p>
      ) : (
        <ul className="want-list">
          {me.wants.map((w) => (
            <li key={w}>
              <span>
                <strong>{w}</strong>
                <small>{counts[w] ? `${counts[w]} exchange listing${counts[w] === 1 ? '' : 's'} match` : 'No exchange listings match yet'}</small>
              </span>
              <button type="button" className="icon-btn" onClick={() => removeWant(w)} aria-label={`Remove ${w}`}>
                <Icon name="x" size={16} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="muted small">
        Matching uses the title, author, class, subject and board of other readers&apos; exchange listings. All the words you type must
        appear.
      </p>
    </div>
  );
}
