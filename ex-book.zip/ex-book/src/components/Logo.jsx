import { Link } from 'react-router-dom';

export function LogoMark({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#14342b" />
      <path d="M17 20h13c2.2 0 2 1.2 2 2v22c0-1-.8-2-2.4-2H17z" fill="#f3ecdb" />
      <path d="M47 20H34c-2.2 0-2 1.2-2 2v22c0-1 .8-2 2.4-2H47z" fill="#d4b46a" />
      <path d="M20 14a18 18 0 0 1 24 0" fill="none" stroke="#d4b46a" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M44 50a18 18 0 0 1-24 0" fill="none" stroke="#f3ecdb" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export default function Logo({ light = false, tagline = false }) {
  return (
    <Link to="/" className={`logo ${light ? 'logo--light' : ''}`} aria-label="Ex-Book home">
      <LogoMark />
      <span className="logo__text">
        <span className="logo__name">
          Ex<span>-</span>Book
        </span>
        {tagline && <span className="logo__tag">Your Book. Their Need. A Perfect Exchange.</span>}
      </span>
    </Link>
  );
}
