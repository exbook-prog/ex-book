import { useRef, useState } from 'react';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';

const MAX_BYTES = 6 * 1024 * 1024;
const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_W = 360;
const MAX_H = 540;

function readAndShrink(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read that file.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('That file is not a valid image.'));
      img.onload = () => {
        const scale = Math.min(1, MAX_W / img.width, MAX_H / img.height);
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.78));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * ONE image only: the FRONT COVER. The input is single-file, and if several files are dropped
 * only the first one is used. The seller must confirm it is the front cover (no back cover or inside pages).
 */
export default function CoverUploader({ value, onChange, confirmed, onConfirm, error }) {
  const { toast } = useApp();
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);

  const handleFiles = async (fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    if (files.length > 1) toast('Only ONE image is allowed per book - the front cover. Using the first file.', 'error');
    const file = files[0];
    if (!OK_TYPES.includes(file.type)) {
      toast('Please choose a JPG, PNG or WebP image.', 'error');
      return;
    }
    if (file.size > MAX_BYTES) {
      toast('That image is larger than 6 MB. Please choose a smaller one.', 'error');
      return;
    }
    setBusy(true);
    try {
      const data = await readAndShrink(file);
      onChange(data);
      onConfirm(false);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  return (
    <div className="uploader">
      <div className="uploader__label">
        Front cover image <span className="muted">(one image only, optional)</span>
      </div>
      {value ? (
        <div className="uploader__preview">
          <img src={value} alt="Selected front cover preview" />
          <div className="uploader__side">
            <label className="check">
              <input type="checkbox" checked={confirmed} onChange={(e) => onConfirm(e.target.checked)} />
              <span>I confirm this is the <strong>front cover</strong> of the book (not the back cover or inside pages).</span>
            </label>
            <div className="actions-row">
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => inputRef.current?.click()}>Replace</button>
              <button type="button" className="btn btn--danger-ghost btn--sm" onClick={() => { onChange(null); onConfirm(false); }}>
                <Icon name="trash" size={14} /> Remove
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div
          className={`dropzone ${drag ? 'is-drag' : ''}`}
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); handleFiles(e.dataTransfer.files); }}
        >
          <Icon name="upload" size={26} />
          <p>{busy ? 'Preparing image...' : 'Drag the front cover here, or'}</p>
          <button type="button" className="btn btn--ghost btn--sm" onClick={() => inputRef.current?.click()} disabled={busy}>
            Choose front cover
          </button>
          <small className="muted">JPG, PNG or WebP. No cover? A tasteful placeholder cover is generated for you.</small>
        </div>
      )}
      {/* single file input: no "multiple" attribute, so a second image cannot be picked */}
      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={(e) => handleFiles(e.target.files)} />
      {error && <p className="field__error">{error}</p>}
    </div>
  );
}
