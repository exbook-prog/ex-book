import { Link, useLocation } from 'react-router-dom';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';

export default function RequireLogin({ children, message = 'Log in to continue.' }) {
  const { me } = useApp();
  const location = useLocation();
  if (me) return children;
  return (
    <div className="container page">
      <div className="card gate">
        <Icon name="lock" size={34} />
        <h2>Please log in</h2>
        <p>{message}</p>
        <Link className="btn btn--primary" to="/login" state={{ from: location.pathname + location.search }}>
          Log in (demo)
        </Link>
        <p className="muted small">The demo needs no password. It only stores a name and city in your browser.</p>
      </div>
    </div>
  );
}
