import { Link } from 'react-router-dom';
import Logo from './Logo.jsx';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div>
          <Logo light />
          <p className="footer__tag">Your Book. Their Need. A Perfect Exchange.</p>
          <p className="footer__small">
            An Indian marketplace to buy, sell and exchange books, from Class 9 to 12 textbooks to storybooks and novels.
          </p>
        </div>
        <div>
          <h4>Marketplace</h4>
          <ul>
            <li><Link to="/browse">Browse Books</Link></li>
            <li><Link to="/buy">Buy Books</Link></li>
            <li><Link to="/sell">Sell a Book</Link></li>
            <li><Link to="/exchange">Exchange Chains</Link></li>
          </ul>
        </div>
        <div>
          <h4>Categories</h4>
          <ul>
            <li><Link to="/browse?cat=class-10">Class 10 Textbooks</Link></li>
            <li><Link to="/browse?cat=class-12">Class 12 Textbooks</Link></li>
            <li><Link to="/browse?cat=novels">Novels</Link></li>
            <li><Link to="/browse?cat=childrens">Children&apos;s Books</Link></li>
          </ul>
        </div>
        <div>
          <h4>Your account</h4>
          <ul>
            <li><Link to="/dashboard">Dashboard</Link></li>
            <li><Link to="/my-listings">My Listings</Link></li>
            <li><Link to="/messages">Messages</Link></li>
            <li><Link to="/exchange#calculator">50-50 Calculator</Link></li>
          </ul>
        </div>
      </div>
      <div className="container footer__legal">
        <p>
          <strong>Demo version.</strong> All books, people and messages are sample data stored only in your browser. No payments or
          delivery addresses are collected. Only city-level locations are ever shown.
        </p>
        <p>&copy; {new Date().getFullYear()} Ex-Book. Made for readers across India.</p>
      </div>
    </footer>
  );
}
