import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { BookGrid } from './BookCard.jsx';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { BOARDS, CATEGORIES, CONDITIONS, STATES, STATE_NAMES, SUBJECTS } from '../data/taxonomy.js';
import { EMPTY_FILTERS, countActive, filterBooks, filtersFromParams } from '../utils/filters.js';
import { plural } from '../utils/format.js';

const PAGE = 12;

export default function BookExplorer({ mode = 'all', title, intro }) {
  const { listings, myFavs, me } = useApp();
  const [params, setParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);
  const [visible, setVisible] = useState(PAGE);
  const f = useMemo(() => filtersFromParams(params), [params]);
  const [qDraft, setQDraft] = useState(f.q);

  useEffect(() => setQDraft(f.q), [f.q]);
  useEffect(() => setVisible(PAGE), [params]);

  const update = (patch) => {
    const next = { ...f, ...patch };
    const sp = new URLSearchParams();
    Object.entries(next).forEach(([k, v]) => {
      if (v !== '' && v != null && !(k === 'sort' && v === 'newest')) sp.set(k, v);
    });
    setParams(sp, { replace: true });
  };

  const results = useMemo(() => filterBooks(listings, f, { mode, favs: myFavs }), [listings, f, mode, myFavs]);

  const cityOptions = useMemo(() => {
    const set = new Set(f.state ? STATES[f.state] || [] : Object.values(STATES).flat());
    listings.forEach((l) => {
      if (!f.state || l.state === f.state) set.add(l.city);
    });
    return [...set].sort();
  }, [f.state, listings]);

  const active = countActive(f);
  const sortOptions =
    mode === 'buy'
      ? [['newest', 'Newest first'], ['price-asc', 'Price: low to high'], ['price-desc', 'Price: high to low'], ['title', 'Title A-Z']]
      : [['newest', 'Newest first'], ['price-asc', 'Value: low to high'], ['price-desc', 'Value: high to low'], ['title', 'Title A-Z']];

  return (
    <div className="container page">
      <header className="page-head">
        <p className="eyebrow">{mode === 'buy' ? 'Buy books' : 'Browse books'}</p>
        <h1>{title}</h1>
        <p className="muted">{intro}</p>
      </header>

      <form
        className="searchbar searchbar--page"
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          update({ q: qDraft.trim() });
        }}
      >
        <Icon name="search" />
        <input
          type="search"
          value={qDraft}
          onChange={(e) => setQDraft(e.target.value)}
          placeholder="Search by title, author, class, subject or city"
          aria-label="Search books"
        />
        <button className="btn btn--primary" type="submit">Search</button>
      </form>

      <div className="explorer">
        <button type="button" className="btn btn--ghost explorer__toggle" onClick={() => setShowFilters((s) => !s)} aria-expanded={showFilters}>
          <Icon name="filter" size={16} /> Filters{active ? ` (${active})` : ''}
        </button>

        <aside className={`filters card ${showFilters ? 'is-open' : ''}`} aria-label="Filters">
          <div className="filters__head">
            <h2>Filters</h2>
            {active > 0 && (
              <button type="button" className="link-btn" onClick={() => setParams(new URLSearchParams(), { replace: true })}>
                Clear all
              </button>
            )}
          </div>

          <label className="field">
            <span>Category</span>
            <select value={f.cat} onChange={(e) => update({ cat: e.target.value })}>
              <option value="">All categories</option>
              {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </label>
          <label className="field">
            <span>Subject</span>
            <select value={f.subject} onChange={(e) => update({ subject: e.target.value })}>
              <option value="">All subjects</option>
              {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>
          <label className="field">
            <span>Education board</span>
            <select value={f.board} onChange={(e) => update({ board: e.target.value })}>
              <option value="">CBSE, ICSE and State</option>
              {BOARDS.map((b) => <option key={b}>{b}</option>)}
            </select>
          </label>
          {mode !== 'buy' && (
            <label className="field">
              <span>Listing type</span>
              <select value={f.type} onChange={(e) => update({ type: e.target.value })}>
                <option value="">Sale and exchange</option>
                <option value="sell">Available to buy</option>
                <option value="exchange">Available to exchange</option>
              </select>
            </label>
          )}
          <label className="field">
            <span>Condition</span>
            <select value={f.cond} onChange={(e) => update({ cond: e.target.value })}>
              <option value="">Any condition</option>
              {CONDITIONS.map((c) => <option key={c.id}>{c.id}</option>)}
            </select>
          </label>

          <fieldset className="field-group">
            <legend>{mode === 'buy' ? 'Price (₹)' : 'Price or swap value (₹)'}</legend>
            <div className="input-row">
              <input type="number" min="0" inputMode="numeric" placeholder="Min" value={f.min} onChange={(e) => update({ min: e.target.value })} aria-label="Minimum price" />
              <input type="number" min="0" inputMode="numeric" placeholder="Max" value={f.max} onChange={(e) => update({ max: e.target.value })} aria-label="Maximum price" />
            </div>
          </fieldset>

          <fieldset className="field-group">
            <legend>Location</legend>
            <label className="field">
              <span>State / UT</span>
              <select value={f.state} onChange={(e) => update({ state: e.target.value, city: '' })}>
                <option value="">All of India</option>
                {STATE_NAMES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </label>
            <label className="field">
              <span>City</span>
              <select value={f.city} onChange={(e) => update({ city: e.target.value })}>
                <option value="">All cities</option>
                {cityOptions.map((c) => <option key={c}>{c}</option>)}
              </select>
            </label>
            <label className="field">
              <span>PIN code (first digits)</span>
              <input inputMode="numeric" maxLength={6} value={f.pin} placeholder="e.g. 110 or 560034" onChange={(e) => update({ pin: e.target.value.replace(/\D/g, '').slice(0, 6) })} />
            </label>
            <small className="muted">Listings show the city only. Exact addresses are never shared.</small>
          </fieldset>

          {me && (
            <label className="check">
              <input type="checkbox" checked={f.fav === '1'} onChange={(e) => update({ fav: e.target.checked ? '1' : '' })} />
              <span>Only my saved books</span>
            </label>
          )}
        </aside>

        <section className="explorer__results" aria-live="polite">
          <div className="results-bar">
            <p>
              <strong>{plural(results.length, 'book')}</strong>
              {f.q && <> for “{f.q}”</>}
            </p>
            <label className="field field--inline">
              <span>Sort</span>
              <select value={f.sort} onChange={(e) => update({ sort: e.target.value })}>
                {sortOptions.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </label>
          </div>
          <BookGrid books={results.slice(0, visible)} empty="No books match these filters. Try clearing a filter or searching a different city." />
          {visible < results.length && (
            <div className="center">
              <button type="button" className="btn btn--ghost" onClick={() => setVisible((v) => v + PAGE)}>
                Show more books ({results.length - visible} left)
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export { EMPTY_FILTERS };
