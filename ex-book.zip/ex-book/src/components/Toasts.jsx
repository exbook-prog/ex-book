import { useApp } from '../context/AppContext.jsx';
import Icon from './Icon.jsx';

export default function Toasts() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="toasts" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast--${t.type}`}>
          <span>{t.msg}</span>
          <button type="button" onClick={() => dismissToast(t.id)} aria-label="Dismiss message">
            <Icon name="x" size={16} />
          </button>
        </div>
      ))}
    </div>
  );
}
