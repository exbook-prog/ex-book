import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import BookCover from './BookCover.jsx';
import CoverUploader from './CoverUploader.jsx';
import PriceBreakdown from './PriceBreakdown.jsx';
import Icon from './Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import {
  CATEGORIES,
  CATEGORY_BY_ID,
  BOARDS,
  CONDITIONS,
  LISTING_TYPES,
  STATES,
  STATE_NAMES,
  SUBJECTS,
  SUBJECTS_BY_CLASS,
  PIN_RE,
  isTextbookCategory,
} from '../data/taxonomy.js';
import { inr } from '../utils/format.js';

function Field({ name, label, hint, children, error, required = true }) {
  return (
    <div className={`field ${error ? 'field--error' : ''}`} data-invalid={error ? 'true' : undefined}>
      <label htmlFor={`f-${name}`}>
        <span>
          {label}
          {required && <i aria-hidden="true"> *</i>}
        </span>
      </label>
      {children}
      {hint && !error && <small className="muted">{hint}</small>}
      {error && (
        <p className="field__error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

const blank = (me) => ({
  title: '',
  author: '',
  category: '',
  subject: '',
  board: '',
  condition: 'Good',
  type: 'sell',
  price: '',
  exchangeValue: '',
  state: me?.state || '',
  city: me?.city || '',
  pin: me?.pin || '',
  description: '',
  wants: '',
  cover: null,
  coverConfirmed: false,
});

function validate(v) {
  const e = {};
  if (v.title.trim().length < 2) e.title = 'Enter the book title.';
  if (v.title.trim().length > 120) e.title = 'Keep the title under 120 characters.';
  if (v.author.trim().length < 2) e.author = 'Enter the author or publisher.';
  if (!v.category) e.category = 'Choose a category.';
  if (isTextbookCategory(v.category)) {
    if (!v.subject) e.subject = 'Choose the subject.';
    if (!v.board) e.board = 'Choose the education board.';
  }
  if (!v.condition) e.condition = 'Choose the condition.';
  const sells = v.type === 'sell' || v.type === 'both';
  const swaps = v.type === 'exchange' || v.type === 'both';
  const price = Number(v.price);
  const ev = Number(v.exchangeValue);
  if (sells && !(price >= 1 && price <= 50000)) e.price = 'Enter a selling price between ₹1 and ₹50,000.';
  if (swaps && !(ev >= 1 && ev <= 50000)) e.exchangeValue = 'Enter the expected exchange value between ₹1 and ₹50,000.';
  if (!v.state) e.state = 'Choose a state.';
  if (v.city.trim().length < 2) e.city = 'Enter the city.';
  if (!PIN_RE.test(v.pin)) e.pin = 'Enter a valid 6-digit PIN code.';
  if (v.cover && !v.coverConfirmed) e.cover = 'Please confirm the image is the front cover, or remove it.';
  return e;
}

export default function ListingForm({ initial = null }) {
  const { me, addListing, updateListing, toast } = useApp();
  const navigate = useNavigate();
  const editing = Boolean(initial);
  const [v, setV] = useState(() =>
    initial
      ? {
          ...blank(me),
          ...initial,
          price: initial.price ?? '',
          exchangeValue: initial.exchangeValue ?? '',
          subject: initial.subject || '',
          board: initial.board || '',
          description: initial.description || '',
          wants: '',
          coverConfirmed: Boolean(initial.cover),
        }
      : blank(me),
  );
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const set = (patch) => {
    const next = { ...v, ...patch };
    setV(next);
    if (submitted) setErrors(validate(next));
  };

  const cat = CATEGORY_BY_ID[v.category];
  const textbook = isTextbookCategory(v.category);
  const sells = v.type === 'sell' || v.type === 'both';
  const swaps = v.type === 'exchange' || v.type === 'both';
  const cities = useMemo(() => STATES[v.state] || [], [v.state]);
  const subjects = textbook ? SUBJECTS_BY_CLASS[cat.classLevel] || SUBJECTS : [];

  const onCategory = (id) => {
    const isTb = isTextbookCategory(id);
    set({ category: id, subject: isTb ? (SUBJECTS_BY_CLASS[CATEGORY_BY_ID[id].classLevel] || []).includes(v.subject) ? v.subject : '' : '', board: isTb ? v.board : '' });
  };

  const submit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    const errs = validate(v);
    setErrors(errs);
    if (Object.keys(errs).length) {
      toast('Please fix the highlighted fields.', 'error');
      const first = document.querySelector('[data-invalid="true"]');
      first?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    const data = {
      title: v.title.trim(),
      author: v.author.trim(),
      category: v.category,
      subject: textbook ? v.subject : null,
      board: textbook ? v.board : null,
      condition: v.condition,
      type: v.type,
      price: sells ? Number(v.price) : null,
      exchangeValue: swaps ? Number(v.exchangeValue) : null,
      state: v.state,
      city: v.city.trim(),
      pin: v.pin,
      description: v.description.trim(),
      cover: v.cover || null, // exactly one front-cover image (or none)
    };
    const wants = swaps ? v.wants.split(',').map((w) => w.trim()).filter((w) => w.length >= 2) : [];
    if (editing) {
      updateListing(initial.id, data, wants);
      toast('Listing updated.', 'success');
      navigate(`/book/${initial.id}`);
    } else {
      const id = addListing(data, wants);
      toast('Your book is listed!', 'success');
      navigate(`/book/${id}`);
    }
  };

  const previewBook = {
    ...v,
    id: 'preview',
    title: v.title || 'Your book title',
    author: v.author || 'Author name',
    classLevel: cat?.classLevel || null,
    price: sells && v.price !== '' ? Number(v.price) : null,
    exchangeValue: swaps && v.exchangeValue !== '' ? Number(v.exchangeValue) : null,
    subject: textbook ? v.subject : null,
    board: textbook ? v.board : null,
  };

  return (
    <form className="listing-form" onSubmit={submit} noValidate>
      <div className="listing-form__main">
        <fieldset className="card form-card">
          <legend>1. About the book</legend>
          <Field error={errors.title} name="title" label="Book title">
            <input id="f-title" value={v.title} maxLength={120} onChange={(e) => set({ title: e.target.value })} placeholder="e.g. Concepts of Physics Vol 1" />
          </Field>
          <Field error={errors.author} name="author" label="Author / publisher">
            <input id="f-author" value={v.author} maxLength={100} onChange={(e) => set({ author: e.target.value })} placeholder="e.g. H.C. Verma" />
          </Field>
          <Field error={errors.category} name="category" label="Category">
            <select id="f-category" value={v.category} onChange={(e) => onCategory(e.target.value)}>
              <option value="">Select a category</option>
              <optgroup label="Textbooks">
                {CATEGORIES.filter((c) => c.kind === 'textbook').map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
              </optgroup>
              <optgroup label="Story & general books">
                {CATEGORIES.filter((c) => c.kind === 'general').map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
              </optgroup>
            </select>
          </Field>
          {textbook && (
            <div className="form-row form-row--3">
              <div className="field">
                <label htmlFor="f-class"><span>Class</span></label>
                <input id="f-class" value={`Class ${cat.classLevel}`} readOnly aria-readonly="true" />
                <small className="muted">Set by the category.</small>
              </div>
              <Field error={errors.subject} name="subject" label="Subject">
                <select id="f-subject" value={v.subject} onChange={(e) => set({ subject: e.target.value })}>
                  <option value="">Select</option>
                  {subjects.map((s) => <option key={s}>{s}</option>)}
                </select>
              </Field>
              <Field error={errors.board} name="board" label="Education board">
                <select id="f-board" value={v.board} onChange={(e) => set({ board: e.target.value })}>
                  <option value="">Select</option>
                  {BOARDS.map((b) => <option key={b}>{b}</option>)}
                </select>
              </Field>
            </div>
          )}
          <Field error={errors.condition} name="condition" label="Book condition">
            <div className="segmented" role="radiogroup" aria-label="Book condition">
              {CONDITIONS.map((c) => (
                <button key={c.id} type="button" role="radio" aria-checked={v.condition === c.id} className={v.condition === c.id ? 'is-active' : ''} onClick={() => set({ condition: c.id })} title={c.hint}>
                  {c.id}
                </button>
              ))}
            </div>
          </Field>
          <Field error={errors.description} name="description" label="Description" required={false} hint="Mention marks, highlighting or missing pages. Do not add phone numbers or addresses.">
            <textarea id="f-description" rows={3} maxLength={400} value={v.description} onChange={(e) => set({ description: e.target.value })} />
          </Field>
        </fieldset>

        <fieldset className="card form-card">
          <legend>2. Sell, exchange or both</legend>
          <div className="segmented segmented--cards" role="radiogroup" aria-label="Listing type">
            {LISTING_TYPES.map((t) => (
              <button key={t.id} type="button" role="radio" aria-checked={v.type === t.id} className={v.type === t.id ? 'is-active' : ''} onClick={() => set({ type: t.id })}>
                <strong>{t.label}</strong>
                <small>{t.hint}</small>
              </button>
            ))}
          </div>
          <div className="form-row">
            {sells && (
              <Field error={errors.price} name="price" label="Selling price (₹)">
                <input id="f-price" type="number" inputMode="numeric" min="1" max="50000" value={v.price} onChange={(e) => set({ price: e.target.value })} placeholder="e.g. 150" />
              </Field>
            )}
            {swaps && (
              <Field error={errors.exchangeValue} name="exchangeValue" label="Expected exchange value (₹)" hint="Used for the 50-50 price difference in swaps.">
                <input id="f-exchangeValue" type="number" inputMode="numeric" min="1" max="50000" value={v.exchangeValue} onChange={(e) => set({ exchangeValue: e.target.value })} placeholder="e.g. 200" />
              </Field>
            )}
          </div>
          {swaps && (
            <Field error={errors.wants} name="wants" label="Books you would like in exchange" required={false} hint='Separate with commas, e.g. "Class 10 Science, Harry Potter". Saved to your wants so Ex-Book can look for chains.'>
              <input id="f-wants" value={v.wants} maxLength={200} onChange={(e) => set({ wants: e.target.value })} placeholder="Class 10 Science, Harry Potter" />
            </Field>
          )}
        </fieldset>

        <fieldset className="card form-card">
          <legend>3. Location</legend>
          <div className="form-row form-row--3">
            <Field error={errors.state} name="state" label="State / UT">
              <select id="f-state" value={v.state} onChange={(e) => set({ state: e.target.value, city: '' })}>
                <option value="">Select</option>
                {STATE_NAMES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field error={errors.city} name="city" label="City">
              <input id="f-city" list="city-options" value={v.city} maxLength={60} onChange={(e) => set({ city: e.target.value })} placeholder="Start typing" />
              <datalist id="city-options">{cities.map((c) => <option key={c} value={c} />)}</datalist>
            </Field>
            <Field error={errors.pin} name="pin" label="PIN code">
              <input id="f-pin" inputMode="numeric" maxLength={6} value={v.pin} onChange={(e) => set({ pin: e.target.value.replace(/\D/g, '').slice(0, 6) })} placeholder="6 digits" />
            </Field>
          </div>
          <p className="privacy-note">
            <Icon name="shield" size={16} /> Only your <strong>city and state</strong> are shown publicly. The PIN code is used for nearby-search filters only.
            Ex-Book never asks for or shows your home address.
          </p>
        </fieldset>

        <fieldset className="card form-card">
          <legend>4. Front cover</legend>
          <CoverUploader value={v.cover} onChange={(cover) => set({ cover })} confirmed={v.coverConfirmed} onConfirm={(c) => set({ coverConfirmed: c })} error={errors.cover} />
        </fieldset>

        <div className="form-actions">
          <button type="submit" className="btn btn--primary btn--lg">{editing ? 'Save changes' : 'Publish listing'}</button>
          <button type="button" className="btn btn--ghost btn--lg" onClick={() => navigate(-1)}>Cancel</button>
        </div>
      </div>

      <aside className="listing-form__preview" aria-label="Live preview">
        <div className="card preview">
          <p className="eyebrow">Live preview</p>
          <div className="preview__cover"><BookCover book={previewBook} size="lg" /></div>
          <h3>{previewBook.title}</h3>
          <p className="muted">{previewBook.author}</p>
          <p className="preview__meta">
            {previewBook.condition}{cat ? ` · ${cat.short}` : ''}{previewBook.board ? ` · ${previewBook.board}` : ''}
          </p>
          <p className="preview__price">
            {previewBook.price != null && <strong>{inr(previewBook.price)}</strong>}
            {previewBook.exchangeValue != null && <span> Swap value {inr(previewBook.exchangeValue)}</span>}
          </p>
          <p className="muted small"><Icon name="pin" size={14} /> {v.city || 'Your city'}{v.state ? `, ${v.state}` : ''}</p>
          {swaps && previewBook.exchangeValue != null && (
            <details className="details">
              <summary>How the 50-50 rule works for this book</summary>
              <PriceBreakdown valueA={previewBook.exchangeValue} valueB={previewBook.exchangeValue + 150} labelA="You" labelB="Other reader" compact />
              <p className="muted small">Example if the other reader&apos;s book is worth ₹150 more.</p>
            </details>
          )}
        </div>
      </aside>
    </form>
  );
}
