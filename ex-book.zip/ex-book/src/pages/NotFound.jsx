import { Link } from 'react-router-dom';
import Icon from '../components/Icon.jsx';

export default function NotFound() {
  return (
    <div className="container page">
      <div className="card gate">
        <Icon name="book" size={36} />
        <h2>This page is not on our shelves</h2>
        <p>The page you are looking for does not exist or has moved.</p>
        <div className="actions-row">
          <Link to="/" className="btn btn--primary">Go home</Link>
          <Link to="/browse" className="btn btn--ghost">Browse books</Link>
        </div>
      </div>
    </div>
  );
}
