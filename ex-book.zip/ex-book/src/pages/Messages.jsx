import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import BookCover from '../components/BookCover.jsx';
import Icon from '../components/Icon.jsx';
import RequireLogin from '../components/RequireLogin.jsx';
import { useApp } from '../context/AppContext.jsx';
import { formatTime, formatDate, inr, initials } from '../utils/format.js';

function dayLabel(ts) {
  const d = new Date(ts);
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return formatDate(ts);
}

function Chat({ convo }) {
  const { me, getUser, getListing, sendMessage, simulateReply, markRead } = useApp();
  const [text, setText] = useState('');
  const endRef = useRef(null);
  const other = getUser(convo.participants.find((p) => p !== me.id));
  const book = getListing(convo.listingId);

  useEffect(() => {
    markRead(convo.id);
  }, [convo.id, convo.messages.length, markRead]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' });
  }, [convo.messages.length, convo.id]);

  const send = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    sendMessage(convo.id, text);
    setText('');
  };

  let lastDay = '';
  return (
    <section className="chat card" aria-label={`Conversation with ${other?.name}`}>
      <header className="chat__head">
        <Link to="/messages" className="icon-btn chat__back" aria-label="Back to conversations"><Icon name="arrow" className="flip" /></Link>
        <span className="avatar">{initials(other?.name)}</span>
        <div>
          <strong>{other?.name}</strong>
          <small className="muted">{other?.city}, {other?.state}</small>
        </div>
      </header>

      {book ? (
        <Link to={`/book/${book.id}`} className="chat__book">
          <BookCover book={book} size="xs" />
          <span>
            <strong>{book.title}</strong>
            <small>
              {book.author} · {book.price != null ? inr(book.price) : `Swap value ${inr(book.exchangeValue)}`}
            </small>
          </span>
          <Icon name="arrow" size={16} />
        </Link>
      ) : (
        <p className="chat__book muted">This book is no longer listed.</p>
      )}

      <p className="chat__notice">
        <Icon name="info" size={14} /> Demo chat: messages are saved only in this browser. Nothing is delivered to {other?.name.split(' ')[0]}.
      </p>

      <div className="chat__log" tabIndex={0} aria-label="Messages">
        {convo.messages.length === 0 && <p className="muted center">Say hello and ask about the book.</p>}
        {convo.messages.map((m) => {
          const day = dayLabel(m.ts);
          const showDay = day !== lastDay;
          lastDay = day;
          const mine = m.from === me.id;
          return (
            <div key={m.id}>
              {showDay && <div className="chat__day"><span>{day}</span></div>}
              <div className={`bubble ${mine ? 'bubble--me' : 'bubble--them'}`}>
                <p>{m.text}</p>
                <time>{formatTime(m.ts)}{m.simulated ? ' · simulated' : mine ? ' · saved on this device' : ''}</time>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      <form className="chat__form" onSubmit={send}>
        <input value={text} onChange={(e) => setText(e.target.value)} maxLength={1000} placeholder="Type a message" aria-label="Type a message" />
        <button type="submit" className="btn btn--primary" disabled={!text.trim()}>
          <Icon name="send" size={16} /> Send
        </button>
      </form>
      <div className="chat__demo">
        <button type="button" className="link-btn" onClick={() => simulateReply(convo.id)}>
          Demo: add a simulated reply from {other?.name.split(' ')[0]}
        </button>
        <small className="muted">Never share OTPs, passwords, card numbers or your home address in chat.</small>
      </div>
    </section>
  );
}

export default function Messages() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { me, myConversations, getUser, getListing } = useApp();

  const convos = [...myConversations].sort((a, b) => (b.messages.at(-1)?.ts || 0) - (a.messages.at(-1)?.ts || 0));
  const active = id ? convos.find((c) => c.id === id) : null;

  return (
    <RequireLogin message="Log in to chat with buyers and sellers.">
      <div className="container page page--wide">
        <header className="page-head">
          <p className="eyebrow">Inbox</p>
          <h1>Messages</h1>
        </header>
        <div className={`messages ${active ? 'has-active' : ''}`}>
          <aside className="convos card" aria-label="Conversations">
            {convos.length === 0 ? (
              <div className="empty empty--small">
                <Icon name="message" size={30} />
                <p>No conversations yet. Open a book and choose “Message seller”.</p>
                <Link to="/browse" className="btn btn--primary btn--sm">Browse books</Link>
              </div>
            ) : (
              <ul>
                {convos.map((c) => {
                  const other = getUser(c.participants.find((p) => p !== me.id));
                  const book = getListing(c.listingId);
                  const last = c.messages.at(-1);
                  const unread = c.unread?.[me.id] || 0;
                  return (
                    <li key={c.id}>
                      <button type="button" className={`convo ${c.id === id ? 'is-active' : ''}`} onClick={() => navigate(`/messages/${c.id}`)}>
                        <span className="avatar">{initials(other?.name)}</span>
                        <span className="convo__body">
                          <span className="convo__top">
                            <strong>{other?.name}</strong>
                            {last && <time>{formatTime(last.ts)}</time>}
                          </span>
                          <small className="convo__book">{book ? book.title : 'Book removed'}</small>
                          <span className="convo__last">{last ? last.text : 'No messages yet'}</span>
                        </span>
                        {unread > 0 && <span className="dot">{unread}</span>}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </aside>
          <div className="messages__pane">
            {active ? (
              <Chat key={active.id} convo={active} />
            ) : (
              <div className="card empty">
                <Icon name="message" size={36} />
                <p>Select a conversation to read and reply.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </RequireLogin>
  );
}
