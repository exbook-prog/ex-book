import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Icon from '../components/Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { STATES, STATE_NAMES } from '../data/taxonomy.js';

export default function Login() {
  const { me, login, loginDemo, toast } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || '/dashboard';

  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [stateName, setStateName] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (me) navigate(from, { replace: true });
  }, [me, from, navigate]);

  const submit = (e) => {
    e.preventDefault();
    const err = {};
    if (name.trim().length < 2) err.name = 'Enter your name (at least 2 letters).';
    if (!stateName) err.stateName = 'Choose your state or union territory.';
    if (city.trim().length < 2) err.city = 'Enter your city.';
    setErrors(err);
    if (Object.keys(err).length) return;
    const user = login({ name, city, stateName });
    toast(`Welcome to Ex-Book, ${user.name.split(' ')[0]}!`, 'success');
  };

  const demo = () => {
    loginDemo();
    toast('Signed in as the demo reader, Aarav Sharma.', 'success');
  };

  return (
    <div className="container page">
      <div className="login">
        <section className="card login__card">
          <p className="eyebrow">Welcome</p>
          <h1>Log in to Ex-Book</h1>
          <p className="muted">
            This is a demo, so there is no password and no server. Your name and city are kept only in this browser.
          </p>

          <button type="button" className="btn btn--gold btn--lg btn--block" onClick={demo}>
            <Icon name="user" size={18} /> Continue as demo reader (Aarav Sharma)
          </button>
          <p className="muted small center">Comes with listings, requests, chats and an exchange chain already set up.</p>

          <div className="divider"><span>or create your own demo profile</span></div>

          <form onSubmit={submit} noValidate>
            <label className="field">
              <span>Your name</span>
              <input value={name} onChange={(e) => setName(e.target.value)} maxLength={60} autoComplete="name" placeholder="e.g. Kavya Rao" />
              {errors.name && <small className="field__error">{errors.name}</small>}
            </label>
            <div className="form-row">
              <label className="field">
                <span>State / UT</span>
                <select value={stateName} onChange={(e) => { setStateName(e.target.value); setCity(''); }}>
                  <option value="">Choose</option>
                  {STATE_NAMES.map((s) => <option key={s}>{s}</option>)}
                </select>
                {errors.stateName && <small className="field__error">{errors.stateName}</small>}
              </label>
              <label className="field">
                <span>City</span>
                <input value={city} onChange={(e) => setCity(e.target.value)} maxLength={50} list="login-cities" placeholder="Start typing" />
                <datalist id="login-cities">
                  {(STATES[stateName] || []).map((c) => <option key={c} value={c} />)}
                </datalist>
                {errors.city && <small className="field__error">{errors.city}</small>}
              </label>
            </div>
            <button type="submit" className="btn btn--primary btn--lg btn--block">Create profile and log in</button>
          </form>

          <p className="privacy-note">
            <Icon name="shield" size={16} /> Please do not enter a home address, phone number or any payment detail anywhere on this demo.
          </p>
          <p className="muted small center"><Link to="/">Back to home</Link></p>
        </section>
      </div>
    </div>
  );
}
