import { useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import BookCover from '../components/BookCover.jsx';
import { BookGrid, TypeBadges } from '../components/BookCard.jsx';
import Modal from '../components/Modal.jsx';
import Icon from '../components/Icon.jsx';
import PriceBreakdown from '../components/PriceBreakdown.jsx';
import { useApp } from '../context/AppContext.jsx';
import { CATEGORY_BY_ID } from '../data/taxonomy.js';
import { inr, formatDate, initials } from '../utils/format.js';

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const app = useApp();
  const { me, getListing, getUser, listings, myFavs, toggleFav, requestPurchase, requestExchange, startConversation, deleteListing, toast } = app;
  const [buyOpen, setBuyOpen] = useState(false);
  const [swapOpen, setSwapOpen] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [offerId, setOfferId] = useState('');

  const book = getListing(id);
  const seller = book ? getUser(book.ownerId) : null;
  const mine = me && book && book.ownerId === me.id;
  const saved = book ? myFavs.includes(book.id) : false;

  const myOffers = useMemo(
    () => (me ? listings.filter((l) => l.ownerId === me.id && l.status === 'active' && (l.type === 'exchange' || l.type === 'both') && l.exchangeValue > 0) : []),
    [listings, me],
  );
  const similar = useMemo(
    () => (book ? listings.filter((l) => l.status === 'active' && l.id !== book.id && l.category === book.category).slice(0, 4) : []),
    [listings, book],
  );

  if (!book) {
    return (
      <div className="container page">
        <div className="card gate">
          <Icon name="book" size={34} />
          <h2>Book not found</h2>
          <p>This listing may have been removed or sold.</p>
          <Link to="/browse" className="btn btn--primary">Browse books</Link>
        </div>
      </div>
    );
  }

  const cat = CATEGORY_BY_ID[book.category];
  const needLogin = (action) => {
    toast(`Log in to ${action}.`);
    navigate('/login', { state: { from: `/book/${book.id}` } });
  };
  const canBuy = (book.type === 'sell' || book.type === 'both') && book.price != null && book.status === 'active';
  const canSwap = (book.type === 'exchange' || book.type === 'both') && book.exchangeValue != null && book.status === 'active';
  const offered = myOffers.find((o) => o.id === offerId);

  const onChat = () => {
    if (!me) return needLogin('message the seller');
    const cid = startConversation(book);
    navigate(`/messages/${cid}`);
  };
  const onBuy = () => (me ? setBuyOpen(true) : needLogin('request this book'));
  const onSwap = () => (me ? setSwapOpen(true) : needLogin('propose an exchange'));
  const onFav = () => {
    if (!me) return needLogin('save books');
    toggleFav(book.id);
    toast(saved ? 'Removed from saved books.' : 'Saved to your books.');
  };

  const submitBuy = (e) => {
    e.preventDefault();
    const r = requestPurchase(book, message.trim().slice(0, 300) || 'Hi, is this book still available?');
    setBuyOpen(false);
    setMessage('');
    toast(r ? 'Purchase request sent. Track it under My Purchases.' : 'You already have a pending request for this book.', r ? 'success' : 'info');
  };
  const submitSwap = (e) => {
    e.preventDefault();
    if (!offered) return toast('Choose which of your books to offer.', 'error');
    const r = requestExchange(offered, book, message.trim().slice(0, 300) || 'Would you like to swap?');
    setSwapOpen(false);
    setMessage('');
    toast(r ? 'Exchange proposal sent. Track it under Exchange Requests.' : 'You already proposed this swap.', r ? 'success' : 'info');
  };

  const rows = [
    ['Author', book.author],
    ['Category', cat?.label],
    book.classLevel && ['Class', `Class ${book.classLevel}`],
    book.subject && ['Subject', book.subject],
    book.board && ['Board', book.board],
    ['Condition', book.condition],
    ['Location', `${book.city}, ${book.state}`],
    ['Listed on', formatDate(book.createdAt)],
  ].filter(Boolean);

  return (
    <div className="container page">
      <nav className="crumbs" aria-label="Breadcrumb">
        <Link to="/browse">Browse</Link> / <Link to={`/browse?cat=${book.category}`}>{cat?.label}</Link> / <span>{book.title}</span>
      </nav>

      <div className="detail">
        <div className="detail__cover">
          <BookCover book={book} size="xl" />
        </div>

        <div className="detail__info">
          <TypeBadges book={book} />
          <h1>{book.title}</h1>
          <p className="detail__author">by {book.author}</p>
          {book.status !== 'active' && <p className="alert alert--warn">This listing is {book.status === 'paused' ? 'paused' : book.status}.</p>}

          <div className="detail__prices">
            {book.price != null && (
              <div>
                <span>Selling price</span>
                <strong>{inr(book.price)}</strong>
              </div>
            )}
            {book.exchangeValue != null && (
              <div>
                <span>Exchange value</span>
                <strong>{inr(book.exchangeValue)}</strong>
              </div>
            )}
          </div>

          {book.description && <p className="detail__desc">{book.description}</p>}

          {mine ? (
            <div className="actions-row">
              <Link to={`/sell?edit=${book.id}`} className="btn btn--primary"><Icon name="edit" size={16} /> Edit listing</Link>
              <button type="button" className="btn btn--danger-ghost" onClick={() => setDelOpen(true)}><Icon name="trash" size={16} /> Delete</button>
              <Link to="/my-listings" className="btn btn--ghost">View requests</Link>
            </div>
          ) : (
            <div className="actions-row">
              {canBuy && <button type="button" className="btn btn--primary btn--lg" onClick={onBuy}><Icon name="tag" size={18} /> Request to buy</button>}
              {canSwap && <button type="button" className="btn btn--gold btn--lg" onClick={onSwap}><Icon name="repeat" size={18} /> Propose exchange</button>}
              <button type="button" className="btn btn--ghost btn--lg" onClick={onChat}><Icon name="message" size={18} /> Message seller</button>
              <button type="button" className={`btn btn--ghost btn--lg ${saved ? 'is-on' : ''}`} onClick={onFav} aria-pressed={saved}>
                <Icon name="heart" size={18} filled={saved} /> {saved ? 'Saved' : 'Save'}
              </button>
            </div>
          )}

          <dl className="facts">
            {rows.map(([k, v]) => (
              <div key={k}><dt>{k}</dt><dd>{v}</dd></div>
            ))}
          </dl>

          {seller && (
            <div className="seller card">
              <span className="avatar avatar--lg">{initials(seller.name)}</span>
              <div>
                <strong>{seller.name}</strong>
                <p className="muted small">Member since {formatDate(seller.joined)} · <Icon name="pin" size={13} /> {seller.city}, {seller.state}</p>
              </div>
            </div>
          )}
          <p className="privacy-note">
            <Icon name="shield" size={16} /> Only the city is shown. Agree on handover or shipping in chat, and never share OTPs, passwords or card details.
          </p>
        </div>
      </div>

      {similar.length > 0 && (
        <section className="section section--tight">
          <div className="section__head"><h2>More in {cat?.label}</h2></div>
          <BookGrid books={similar} />
        </section>
      )}

      {buyOpen && (
        <Modal title="Request to buy" onClose={() => setBuyOpen(false)}>
          <form onSubmit={submitBuy}>
            <p><strong>{book.title}</strong> · {inr(book.price)}</p>
            <label className="field">
              <span>Message to {seller?.name.split(' ')[0]} (optional)</span>
              <textarea rows={3} maxLength={300} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Hi, is this still available?" />
            </label>
            <p className="alert alert--info"><Icon name="info" size={16} /><span>No payment is taken here and no delivery address is collected. If the seller accepts, you agree on handover and payment in Messages.</span></p>
            <div className="modal__actions">
              <button type="button" className="btn btn--ghost" onClick={() => setBuyOpen(false)}>Cancel</button>
              <button type="submit" className="btn btn--primary">Send request</button>
            </div>
          </form>
        </Modal>
      )}

      {swapOpen && (
        <Modal title="Propose an exchange" onClose={() => setSwapOpen(false)} wide>
          <form onSubmit={submitSwap}>
            <p>You want <strong>{book.title}</strong> (value {inr(book.exchangeValue)}).</p>
            {myOffers.length === 0 ? (
              <p className="alert alert--warn">
                <Icon name="alert" size={16} />
                <span>You have no active exchange listings yet. <Link to="/sell">List a book for exchange</Link> first.</span>
              </p>
            ) : (
              <>
                <label className="field">
                  <span>Which of your books will you offer?</span>
                  <select value={offerId} onChange={(e) => setOfferId(e.target.value)}>
                    <option value="">Choose a book</option>
                    {myOffers.map((o) => <option key={o.id} value={o.id}>{o.title} ({inr(o.exchangeValue)})</option>)}
                  </select>
                </label>
                {offered && (
                  <PriceBreakdown valueA={offered.exchangeValue} valueB={book.exchangeValue} labelA={`You (${offered.title})`} labelB={`${seller?.name.split(' ')[0]} (${book.title})`} />
                )}
                <label className="field">
                  <span>Message (optional)</span>
                  <textarea rows={2} maxLength={300} value={message} onChange={(e) => setMessage(e.target.value)} />
                </label>
              </>
            )}
            <div className="modal__actions">
              <button type="button" className="btn btn--ghost" onClick={() => setSwapOpen(false)}>Cancel</button>
              <button type="submit" className="btn btn--gold" disabled={!myOffers.length}>Send proposal</button>
            </div>
          </form>
        </Modal>
      )}

      {delOpen && (
        <Modal title="Delete this listing?" onClose={() => setDelOpen(false)}>
          <p>This removes <strong>{book.title}</strong> and cancels pending requests for it. This cannot be undone.</p>
          <div className="modal__actions">
            <button type="button" className="btn btn--ghost" onClick={() => setDelOpen(false)}>Keep it</button>
            <button type="button" className="btn btn--danger" onClick={() => { deleteListing(book.id); toast('Listing deleted.'); navigate('/my-listings'); }}>Delete</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
