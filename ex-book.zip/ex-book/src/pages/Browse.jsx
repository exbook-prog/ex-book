import BookExplorer from '../components/BookExplorer.jsx';

export function Browse() {
  return (
    <BookExplorer
      mode="all"
      title="Browse every book"
      intro="Textbooks for Classes 9 to 12 (CBSE, ICSE and State Boards), storybooks, novels and more, to buy or to exchange."
    />
  );
}

export function Buy() {
  return (
    <BookExplorer
      mode="buy"
      title="Buy books"
      intro="Books with a selling price. Filter by class, board, price and city, then send a purchase request."
    />
  );
}
