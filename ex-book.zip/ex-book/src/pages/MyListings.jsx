import ListingManager from '../components/ListingManager.jsx';
import RequireLogin from '../components/RequireLogin.jsx';

export default function MyListings() {
  return (
    <RequireLogin message="Log in to see and manage your listings.">
      <div className="container page">
        <header className="page-head">
          <p className="eyebrow">Your shelf</p>
          <h1>My Listings</h1>
          <p className="muted">Edit or delete a listing, change its price, pause it, and respond to purchase requests.</p>
        </header>
        <ListingManager />
      </div>
    </RequireLogin>
  );
}
