import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ChainView from '../components/ChainView.jsx';
import PriceCalculator from '../components/PriceCalculator.jsx';
import WantsEditor from '../components/WantsEditor.jsx';
import Icon from '../components/Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { findChains, generateLabCommunity } from '../utils/matching.js';
import { buildChainRecord } from '../utils/chainFlow.js';
import { createLabPool } from '../data/seed.js';
import { inr, plural } from '../utils/format.js';

const PRESETS = [4, 8, 15, 25, 50];

function ChainCard({ chain, active, meId, onClick }) {
  const cities = new Set(chain.participants.map((p) => p.userId)).size;
  const includesMe = meId && chain.participants.some((p) => p.userId === meId);
  return (
    <button type="button" className={`chain-card ${active ? 'is-active' : ''}`} onClick={onClick} aria-pressed={active}>
      <span className="chain-card__size">{chain.size}</span>
      <span className="chain-card__body">
        <strong>{chain.size}-person chain</strong>
        <small>
          {chain.code} · {plural(cities, 'reader')} · largest link difference {inr(chain.maxLinkDifference)}
        </small>
        <small>Ex-Book share {inr(chain.totalCommission)}</small>
      </span>
      {includesMe && <span className="pill pill--green">Includes you</span>}
    </button>
  );
}

/** Real matcher on the sample community (and on the user's own listings and wants). */
function CommunityFinder() {
  const { users, listings, me, proposeChain, toast } = useApp();
  const navigate = useNavigate();
  const [onlyMine, setOnlyMine] = useState(Boolean(me));
  const [maxLen, setMaxLen] = useState(60);
  const [maxGap, setMaxGap] = useState('');
  const [sort, setSort] = useState('size-desc');
  const [picked, setPicked] = useState(null);

  const mineOnly = Boolean(me) && onlyMine;
  const result = useMemo(
    () =>
      findChains(users, listings, {
        minLen: 2,
        maxLen,
        maxGap: maxGap === '' ? Infinity : Number(maxGap),
        mustInclude: mineOnly ? me.id : null,
        sort,
        limit: 30,
      }),
    [users, listings, maxLen, maxGap, mineOnly, me, sort],
  );

  const chains = result.chains;
  const selected = chains.find((c) => c.code === picked) || chains[0] || null;
  const record = useMemo(() => (selected ? buildChainRecord(selected, users, listings) : null), [selected, users, listings]);

  const propose = () => {
    if (!me) {
      toast('Log in to propose a chain.');
      navigate('/login', { state: { from: '/exchange' } });
      return;
    }
    proposeChain(selected, { users, listings });
    toast('Chain proposed. Every participant now has to approve it.', 'success');
    navigate('/dashboard/chains');
  };

  const myListingCount = me ? listings.filter((l) => l.ownerId === me.id && l.status === 'active' && (l.type === 'exchange' || l.type === 'both')).length : 0;

  return (
    <section className="section container" id="find">
      <div className="section__head">
        <div>
          <p className="eyebrow">Live matcher</p>
          <h2>Find an exchange chain</h2>
          <p className="muted">
            The matcher links readers who own a book someone else wants. It only shows chains that truly exist in the listings below.
          </p>
        </div>
      </div>

      <div className="card controls">
        {me && (
          <label className="check">
            <input type="checkbox" checked={onlyMine} onChange={(e) => setOnlyMine(e.target.checked)} />
            <span>Only chains that include me</span>
          </label>
        )}
        <label className="field field--inline">
          <span>Longest chain</span>
          <select value={maxLen} onChange={(e) => setMaxLen(Number(e.target.value))}>
            {[3, 4, 6, 8, 12, 20, 60].map((n) => <option key={n} value={n}>{n === 60 ? 'No limit' : `${n} readers`}</option>)}
          </select>
        </label>
        <label className="field field--inline">
          <span>Max value gap per link</span>
          <select value={maxGap} onChange={(e) => setMaxGap(e.target.value)}>
            <option value="">Any gap</option>
            <option value="50">₹50</option>
            <option value="100">₹100</option>
            <option value="200">₹200</option>
          </select>
        </label>
        <label className="field field--inline">
          <span>Sort</span>
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="size-desc">Largest first</option>
            <option value="size-asc">Smallest first</option>
            <option value="gap-asc">Smallest price gaps first</option>
          </select>
        </label>
      </div>

      {chains.length === 0 ? (
        <div className="card empty">
          <Icon name="alert" size={32} />
          <h3>No compatible chain exists right now</h3>
          <p className="muted">
            {mineOnly
              ? 'There is no circle where you receive a book you want and give a book someone else wants. We never promise a chain that does not exist.'
              : 'No circle of readers matches these settings. Try removing a filter.'}
          </p>
          {mineOnly && myListingCount === 0 && (
            <p>
              You have no active exchange listings yet. <Link to="/sell">List a book for exchange</Link> and add the books you want below.
            </p>
          )}
          {mineOnly && <p className="muted small">Tip: add more wants (a title or a class and subject) to widen your chances.</p>}
        </div>
      ) : (
        <div className="finder">
          <div className="finder__list" role="list" aria-label="Chains found">
            <p className="muted small">
              {plural(chains.length, 'chain')} found{result.truncated ? ' (showing the best matches)' : ''}.
            </p>
            {chains.map((c) => (
              <ChainCard key={c.code} chain={c} meId={me?.id} active={selected?.code === c.code} onClick={() => setPicked(c.code)} />
            ))}
          </div>
          <div className="finder__view">
            {record && <ChainView key={record.code} chain={record} onPropose={propose} />}
          </div>
        </div>
      )}

      <div className="card wants-card">
        <h3>{me ? 'Your wants' : 'Tell us what you would like to receive'}</h3>
        {me ? (
          <>
            <p className="muted">
              A chain needs to know which books you would accept. Add titles or keywords; the matcher uses them together with your
              exchange listings.
            </p>
            <WantsEditor />
          </>
        ) : (
          <p className="muted">
            <Link to="/login" state={{ from: '/exchange' }}>Log in</Link> to add the books you want and see chains built around you.
          </p>
        )}
      </div>
    </section>
  );
}

/** Simulated community used to show chains of 4, 8, 15, 25, 50 or more readers. */
function ChainLab() {
  const { me, proposeChain, toast } = useApp();
  const navigate = useNavigate();
  const pool = useMemo(() => createLabPool(), []);
  const [n, setN] = useState(8);
  const [broken, setBroken] = useState(false);

  const lab = useMemo(() => generateLabCommunity(n, pool), [n, pool]);
  const listings = useMemo(() => (broken ? lab.listings.filter((l) => l.id !== 'lab-b1') : lab.listings), [broken, lab]);
  const result = useMemo(() => findChains(lab.users, listings, { limit: 5, minLen: 2 }), [lab, listings]);
  const found = result.chains[0] || null;
  const record = useMemo(
    () => (found ? buildChainRecord(found, lab.users, listings, { simulated: true }) : null),
    [found, lab, listings],
  );

  const setSize = (value) => {
    const v = Math.max(2, Math.min(60, Math.round(Number(value) || 2)));
    setN(v);
  };

  const propose = () => {
    if (!me) {
      toast('Log in to save a simulated chain to your dashboard.');
      navigate('/login', { state: { from: '/exchange' } });
      return;
    }
    proposeChain(found, { users: lab.users, listings, simulated: true });
    toast('Simulated chain saved to your dashboard.', 'success');
    navigate('/dashboard/chains');
  };

  return (
    <section className="section section--cream" id="lab">
      <div className="container">
        <div className="section__head">
          <div>
            <p className="eyebrow">Chain Lab</p>
            <h2>Try chains of 4, 8, 15, 25, 50 or more readers</h2>
            <p className="muted">
              The lab builds a pretend community, runs the same matcher on it, and shows the complete ring. A few extra readers always
              want books nobody has, so you can see that not everyone is matched.
            </p>
          </div>
        </div>

        <div className="card controls">
          <div className="chips" role="group" aria-label="Chain size presets">
            {PRESETS.map((p) => (
              <button key={p} type="button" className={`chip ${n === p ? 'is-active' : ''}`} onClick={() => setSize(p)} aria-pressed={n === p}>
                {p} readers
              </button>
            ))}
          </div>
          <label className="field field--inline">
            <span>Or any size (2 to 60)</span>
            <input type="number" min="2" max="60" value={n} onChange={(e) => setSize(e.target.value)} />
          </label>
          <label className="check">
            <input type="checkbox" checked={broken} onChange={(e) => setBroken(e.target.checked)} />
            <span>Remove one reader&apos;s book (test what happens when a link is missing)</span>
          </label>
        </div>

        <div className="stats stats--3">
          <div><span>Readers in the pretend community</span><strong>{lab.users.length}</strong></div>
          <div><span>Ring size requested</span><strong>{lab.ringSize}</strong></div>
          <div><span>Matched in the chain</span><strong>{found ? found.size : 0}</strong></div>
        </div>
        {lab.ringSize !== n && (
          <p className="alert alert--warn">
            <Icon name="alert" size={16} />
            <span>The sample book pool only has enough different titles for a ring of {lab.ringSize}, so the lab used that size.</span>
          </p>
        )}

        {broken && record && (
          <p className="alert alert--warn">
            <Icon name="alert" size={16} />
            <span>
              The original {lab.ringSize}-person ring is broken because one book is missing. The matcher found a different{' '}
              {found.size}-person chain that uses other compatible books. It only ever shows chains that really exist.
            </span>
          </p>
        )}

        {record ? (
          <>
            <p className="muted">
              {found.size} readers matched. {lab.users.length - found.size} other readers were left out because nobody could give them a
              book they want.
            </p>
            <ChainView key={`${record.code}-${n}`} chain={record} onPropose={propose} />
          </>
        ) : (
          <div className="card empty">
            <Icon name="alert" size={32} />
            <h3>No chain can be formed</h3>
            <p className="muted">
              With one book missing, the circle is broken: someone no longer receives the book they want. Ex-Book does not guarantee a
              chain when compatible matches do not exist. Untick the box to restore it.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

export default function Exchange() {
  return (
    <>
      <section className="hero hero--compact">
        <div className="container">
          <p className="eyebrow eyebrow--gold">Large multi-person exchange</p>
          <h1>Circular exchange chains</h1>
          <p className="hero__lead">
            Each reader gives one book and receives one book, in a circle of any size when compatible matches exist. Every participant
            must approve before anything is confirmed.
          </p>
          <p className="chain-example">A → B → C → D → E → F → G → H → A</p>
          <div className="hero__cta">
            <Link to="/exchange#find" className="btn btn--gold">Find my chain</Link>
            <Link to="/exchange#lab" className="btn btn--outline-light">Open the Chain Lab</Link>
            <Link to="/exchange#calculator" className="btn btn--outline-light">50-50 calculator</Link>
          </div>
        </div>
      </section>

      <section className="section container">
        <ol className="steps">
          <li className="step card"><span className="step__num">1</span><Icon name="book" size={26} /><h3>List and say what you want</h3><p>Add a book for exchange and the titles you would accept in return.</p></li>
          <li className="step card"><span className="step__num">2</span><Icon name="search" size={26} /><h3>The matcher finds circles</h3><p>It links people whose books match each other&apos;s wants, in any size.</p></li>
          <li className="step card"><span className="step__num">3</span><Icon name="users" size={26} /><h3>Everyone approves</h3><p>You see the full chain. It starts only when all participants say yes.</p></li>
          <li className="step card"><span className="step__num">4</span><Icon name="truck" size={26} /><h3>Ship and confirm</h3><p>Track delivery per book. If someone cancels, dispatched books are returned.</p></li>
        </ol>
      </section>

      <CommunityFinder />
      <ChainLab />

      <section className="section container" id="calc-section">
        <div className="section__head">
          <div>
            <p className="eyebrow">Fair differences</p>
            <h2>50-50 price difference calculator</h2>
          </div>
        </div>
        <PriceCalculator />
      </section>
    </>
  );
}
