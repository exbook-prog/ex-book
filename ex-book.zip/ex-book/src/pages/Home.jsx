import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../components/Icon.jsx';
import BookCover from '../components/BookCover.jsx';
import { BookGrid } from '../components/BookCard.jsx';
import ChainDiagram from '../components/ChainDiagram.jsx';
import { useApp } from '../context/AppContext.jsx';
import { CATEGORIES } from '../data/taxonomy.js';

const STEPS = [
  { icon: 'upload', title: 'List your book', text: 'Add the title, class and board, condition, price and city. One front-cover photo, or we draw a placeholder.' },
  { icon: 'search', title: 'Find what you need', text: 'Search and filter by class, subject, board, price and city. Save favourites and chat with the owner.' },
  { icon: 'repeat', title: 'Buy, swap or join a chain', text: 'Send a purchase request, propose a swap, or let Ex-Book find a circle where everyone gets a book they want.' },
  { icon: 'truck', title: 'Ship and confirm', text: 'Everyone approves before it starts. Track delivery, and confirm each book when it arrives.' },
];

const DEMO_RING = Array.from({ length: 12 }, (_, i) => ({
  name: ['Aarav', 'Priya', 'Rohan', 'Ananya', 'Karthik', 'Meera', 'Debashis', 'Sneha', 'Vikram', 'Divya', 'Harpreet', 'Neha'][i],
  city: '',
  giveTitle: '',
  approval: i % 3 === 0 ? 'approved' : 'pending',
}));

export default function Home() {
  const { listings } = useApp();
  const navigate = useNavigate();
  const [q, setQ] = useState('');

  const active = useMemo(() => listings.filter((l) => l.status === 'active'), [listings]);
  const featured = useMemo(() => active.filter((l) => l.featured).slice(0, 8), [active]);
  const hero = featured.slice(0, 3);
  const counts = useMemo(() => {
    const c = {};
    active.forEach((l) => {
      c[l.category] = (c[l.category] || 0) + 1;
    });
    return c;
  }, [active]);
  const cityCount = useMemo(() => new Set(active.map((l) => l.city)).size, [active]);

  const search = (e) => {
    e.preventDefault();
    navigate(q.trim() ? `/browse?q=${encodeURIComponent(q.trim())}` : '/browse');
  };

  return (
    <>
      <section className="hero">
        <div className="container hero__inner">
          <div className="hero__copy">
            <p className="eyebrow eyebrow--gold">Your Book. Their Need. A Perfect Exchange.</p>
            <h1>Every Book Deserves a New Reader.</h1>
            <p className="hero__lead">
              Buy, sell and swap textbooks for Classes 9 to 12, storybooks and novels across India, or join a circular exchange where
              dozens of readers each receive the book they wanted.
            </p>
            <form className="searchbar" role="search" onSubmit={search}>
              <Icon name="search" />
              <input
                type="search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search a title, author, class or subject"
                aria-label="Search books"
              />
              <button type="submit" className="btn btn--gold">Search</button>
            </form>
            <div className="hero__cta">
              <Link to="/browse" className="btn btn--gold btn--lg">Browse Books</Link>
              <Link to="/sell" className="btn btn--outline-light btn--lg">List Your Book</Link>
            </div>
            <ul className="hero__facts">
              <li><strong>{active.length}</strong> books listed</li>
              <li><strong>{cityCount}</strong> cities</li>
              <li><strong>Classes 9-12</strong> CBSE · ICSE · State</li>
            </ul>
          </div>
          <div className="hero__stack" aria-hidden="true">
            {hero.map((b, i) => (
              <div key={b.id} className={`hero__book hero__book--${i + 1}`}>
                <BookCover book={b} size="lg" />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section container">
        <div className="section__head">
          <div>
            <p className="eyebrow">Hand-picked</p>
            <h2>Featured Books</h2>
          </div>
          <Link to="/browse" className="link-arrow">See all books <Icon name="arrow" size={16} /></Link>
        </div>
        <BookGrid books={featured} />
      </section>

      <section className="section section--cream">
        <div className="container">
          <div className="section__head">
            <div>
              <p className="eyebrow">Shelves</p>
              <h2>Popular Categories</h2>
            </div>
          </div>
          <div className="cat-grid">
            {CATEGORIES.map((c) => (
              <Link key={c.id} to={`/browse?cat=${c.id}`} className="cat-tile">
                <span className="cat-tile__icon"><Icon name={c.icon} size={22} /></span>
                <strong>{c.label}</strong>
                <small>{counts[c.id] || 0} books</small>
              </Link>
            ))}
          </div>
          <div className="board-row">
            <span>Boards:</span>
            <Link to="/browse?board=CBSE" className="chip">CBSE</Link>
            <Link to="/browse?board=ICSE" className="chip">ICSE</Link>
            <Link to="/browse?board=State%20Board" className="chip">State Boards</Link>
            <span className="board-row__sep" />
            <span>Subjects:</span>
            {['Mathematics', 'Science', 'English', 'Social Science', 'Physics', 'Chemistry', 'Biology', 'Commerce', 'Humanities'].map((s) => (
              <Link key={s} to={`/browse?subject=${encodeURIComponent(s)}`} className="chip chip--ghost">{s}</Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section container">
        <div className="section__head">
          <div>
            <p className="eyebrow">Simple and safe</p>
            <h2>How It Works</h2>
          </div>
        </div>
        <ol className="steps">
          {STEPS.map((s, i) => (
            <li key={s.title} className="step card">
              <span className="step__num">{i + 1}</span>
              <Icon name={s.icon} size={26} />
              <h3>{s.title}</h3>
              <p>{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="section chains-band">
        <div className="container chains-band__inner">
          <div className="chains-band__copy">
            <p className="eyebrow eyebrow--gold">Our signature feature</p>
            <h2>Large Exchange Chains</h2>
            <p>
              You have a book someone needs, but they do not have the one you want. A chain solves that. Ex-Book looks for a circle of
              readers where <strong>each person gives one book and receives one book</strong>.
            </p>
            <p className="chain-example">A → B → C → D → E → F → G → H → A</p>
            <ul className="tick-list">
              <li>Not limited to three people: 4, 8, 15, 25, 50 or more when compatible matches exist.</li>
              <li>You see the complete proposed chain, and every participant must approve before it is confirmed.</li>
              <li>Each link gets a fair 50-50 price difference: the lower-value book&apos;s owner pays, half to the other owner and half to Ex-Book.</li>
              <li>No match, no chain. We never promise one when compatible books do not exist.</li>
            </ul>
            <div className="hero__cta">
              <Link to="/exchange" className="btn btn--gold btn--lg">Find an exchange chain</Link>
              <Link to="/exchange#calculator" className="btn btn--outline-light btn--lg">Try the 50-50 calculator</Link>
            </div>
          </div>
          <div className="chains-band__viz">
            <ChainDiagram participants={DEMO_RING} size={420} />
            <p className="muted small center">A 12-reader chain: each arrow is one book travelling to the next reader.</p>
          </div>
        </div>
      </section>

      <section className="section container">
        <div className="trust">
          <div><Icon name="shield" size={26} /><h3>City-level locations only</h3><p>We never show home addresses. Listings show a city and state.</p></div>
          <div><Icon name="lock" size={26} /><h3>No payment details collected</h3><p>The demo never asks for card numbers or delivery addresses.</p></div>
          <div><Icon name="users" size={26} /><h3>Approval by everyone</h3><p>A chain only starts when every single participant says yes.</p></div>
        </div>
        <div className="cta-band">
          <div>
            <h2>Got a book gathering dust?</h2>
            <p>List it in a minute, and let it find its next reader.</p>
          </div>
          <Link to="/sell" className="btn btn--gold btn--lg">List Your Book</Link>
        </div>
      </section>
    </>
  );
}
