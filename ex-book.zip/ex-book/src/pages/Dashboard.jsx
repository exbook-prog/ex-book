import { useMemo, useState } from 'react';
import { Link, NavLink, useNavigate, useParams } from 'react-router-dom';
import RequireLogin from '../components/RequireLogin.jsx';
import ListingManager, { SaleRequestRow, StatusPill } from '../components/ListingManager.jsx';
import ChainView from '../components/ChainView.jsx';
import PriceBreakdown from '../components/PriceBreakdown.jsx';
import WantsEditor from '../components/WantsEditor.jsx';
import { BookGrid } from '../components/BookCard.jsx';
import Icon from '../components/Icon.jsx';
import { useApp } from '../context/AppContext.jsx';
import { PIN_RE, STATE_NAMES } from '../data/taxonomy.js';
import { formatDate, inr, initials, timeAgo } from '../utils/format.js';

const SECTIONS = [
  { id: 'profile', label: 'My Profile', icon: 'user' },
  { id: 'listings', label: 'My Listings', icon: 'book' },
  { id: 'purchases', label: 'My Purchases', icon: 'tag' },
  { id: 'sales', label: 'My Sales', icon: 'clipboard' },
  { id: 'exchange-requests', label: 'Exchange Requests', icon: 'repeat' },
  { id: 'chains', label: 'My Exchange Chains', icon: 'users' },
  { id: 'messages', label: 'Messages', icon: 'message' },
  { id: 'saved', label: 'Saved Books', icon: 'heart' },
  { id: 'notifications', label: 'Notifications', icon: 'bell' },
];

function Empty({ icon = 'book', text, to, cta }) {
  return (
    <div className="empty">
      <Icon name={icon} size={34} />
      <p>{text}</p>
      {to && <Link to={to} className="btn btn--primary">{cta}</Link>}
    </div>
  );
}

/* ---------------- Profile ---------------- */
function Profile() {
  const { me, listings, purchases, chains, updateProfile, resetDemo, toast } = useApp();
  const [form, setForm] = useState({ name: me.name, city: me.city, state: me.state, pin: me.pin || '', bio: me.bio || '' });
  const [errors, setErrors] = useState({});
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));

  const mine = listings.filter((l) => l.ownerId === me.id);
  const stats = [
    ['Active listings', mine.filter((l) => l.status === 'active').length],
    ['Books sold', mine.filter((l) => l.status === 'sold').length],
    ['Books exchanged', mine.filter((l) => l.status === 'exchanged').length],
    ['Purchase requests sent', purchases.filter((p) => p.buyerId === me.id).length],
    ['Chains joined', chains.filter((c) => c.participants.some((p) => p.userId === me.id)).length],
  ];

  const save = (e) => {
    e.preventDefault();
    const err = {};
    if (form.name.trim().length < 2) err.name = 'Enter your name.';
    if (form.city.trim().length < 2) err.city = 'Enter your city.';
    if (!form.state) err.state = 'Choose a state or UT.';
    if (form.pin && !PIN_RE.test(form.pin)) err.pin = 'A PIN code has 6 digits and does not start with 0.';
    setErrors(err);
    if (Object.keys(err).length) return;
    updateProfile({ name: form.name.trim(), city: form.city.trim(), state: form.state, pin: form.pin, bio: form.bio.trim() });
    toast('Profile saved.', 'success');
  };

  return (
    <>
      <div className="profile-head card">
        <span className="avatar avatar--xl">{initials(me.name)}</span>
        <div>
          <h2>{me.name}</h2>
          <p className="muted">{me.city}, {me.state} · Member since {formatDate(me.joined)}</p>
        </div>
      </div>
      <div className="stat-grid">
        {stats.map(([k, v]) => (
          <div key={k} className="card stat"><strong>{v}</strong><span>{k}</span></div>
        ))}
      </div>

      <form className="card form-card" onSubmit={save} noValidate>
        <h3>Edit profile</h3>
        <label className="field">
          <span>Name</span>
          <input value={form.name} maxLength={60} onChange={(e) => set({ name: e.target.value })} />
          {errors.name && <small className="field__error">{errors.name}</small>}
        </label>
        <div className="form-row form-row--3">
          <label className="field">
            <span>State / UT</span>
            <select value={form.state} onChange={(e) => set({ state: e.target.value })}>
              <option value="">Choose</option>
              {STATE_NAMES.map((s) => <option key={s}>{s}</option>)}
            </select>
            {errors.state && <small className="field__error">{errors.state}</small>}
          </label>
          <label className="field">
            <span>City</span>
            <input value={form.city} maxLength={50} onChange={(e) => set({ city: e.target.value })} />
            {errors.city && <small className="field__error">{errors.city}</small>}
          </label>
          <label className="field">
            <span>PIN code (optional)</span>
            <input value={form.pin} inputMode="numeric" maxLength={6} onChange={(e) => set({ pin: e.target.value.replace(/\D/g, '') })} />
            {errors.pin && <small className="field__error">{errors.pin}</small>}
          </label>
        </div>
        <label className="field">
          <span>About you (optional)</span>
          <textarea rows={3} maxLength={200} value={form.bio} onChange={(e) => set({ bio: e.target.value })} />
        </label>
        <p className="privacy-note">
          <Icon name="shield" size={16} /> Other readers only see your name, city and state. Your PIN is used for filtering and is never shown as an address.
        </p>
        <div className="form-actions">
          <button type="submit" className="btn btn--primary">Save profile</button>
        </div>
      </form>

      <div className="card form-card">
        <h3>Books I would like to receive</h3>
        <WantsEditor />
      </div>

      <div className="card form-card">
        <h3>Demo data</h3>
        <p className="muted">Everything here is stored only in this browser. Reset to bring back the original sample books, people and chains.</p>
        <button
          type="button"
          className="btn btn--danger-ghost"
          onClick={() => {
            if (window.confirm('Reset all demo data in this browser? Your changes will be lost.')) {
              resetDemo();
              toast('Demo data reset.');
            }
          }}
        >
          Reset demo data
        </button>
      </div>
    </>
  );
}

/* ---------------- Purchases (as buyer) ---------------- */
function Purchases() {
  const { me, purchases, getUser, getListing, respondPurchase, startConversation, toast } = useApp();
  const navigate = useNavigate();
  const mine = purchases.filter((p) => p.buyerId === me.id);
  if (!mine.length) return <Empty icon="tag" text="You have not requested any books yet." to="/buy" cta="Browse books to buy" />;
  return (
    <ul className="req-list req-list--cards">
      {mine.map((p) => {
        const seller = getUser(p.sellerId);
        const book = getListing(p.listingId);
        return (
          <li key={p.id} className="req card">
            <div className="req__main">
              {book ? <Link to={`/book/${book.id}`}><strong>{p.title}</strong></Link> : <strong>{p.title}</strong>} · {inr(p.price)}
              <small>Seller {seller?.name || 'a reader'} ({seller?.city}) · {timeAgo(p.createdAt)} · “{p.message}”</small>
            </div>
            <div className="req__side">
              <StatusPill status={p.status} />
              {p.status === 'pending' && (
                <button type="button" className="btn btn--ghost btn--xs" onClick={() => { respondPurchase(p.id, 'cancelled'); toast('Request cancelled.'); }}>
                  Cancel request
                </button>
              )}
              {['pending', 'accepted'].includes(p.status) && book && (
                <button type="button" className="btn btn--ghost btn--xs" onClick={() => navigate(`/messages/${startConversation(book)}`)}>
                  Message seller
                </button>
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

/* ---------------- Sales (as seller) ---------------- */
function Sales() {
  const { me, purchases, listings } = useApp();
  const reqs = purchases.filter((p) => p.sellerId === me.id);
  const sold = listings.filter((l) => l.ownerId === me.id && l.status === 'sold');
  if (!reqs.length) return <Empty icon="clipboard" text="No purchase requests for your books yet." to="/sell" cta="List a book" />;
  return (
    <>
      <p className="muted">{sold.length} sold so far. Accept a request, agree on handover in Messages, then mark it as sold.</p>
      <ul className="req-list req-list--cards">
        {reqs.map((r) => <SaleRequestRow key={r.id} req={r} />)}
      </ul>
    </>
  );
}

/* ---------------- One-to-one exchange requests ---------------- */
function ExchangeRequests() {
  const { me, exchangeRequests, getUser, getListing, respondExchange, toast } = useApp();
  const mine = exchangeRequests.filter((x) => x.fromUserId === me.id || x.toUserId === me.id);
  if (!mine.length) {
    return <Empty icon="repeat" text="No exchange requests yet. Open a book marked Exchange and choose Propose exchange." to="/browse?type=exchange" cta="Find books to exchange" />;
  }
  return (
    <ul className="req-list req-list--cards">
      {mine.map((x) => {
        const incoming = x.toUserId === me.id;
        const other = getUser(incoming ? x.fromUserId : x.toUserId);
        const offered = getListing(x.offeredId);
        const target = getListing(x.targetId);
        const firstName = other?.name.split(' ')[0] || 'Reader';
        return (
          <li key={x.id} className="req card req--column">
            <div className="req__main">
              <span className={`pill pill--${incoming ? 'gold' : 'neutral'}`}>{incoming ? 'Incoming' : 'Sent by you'}</span>{' '}
              <strong>{incoming ? `${firstName} offers` : `You offer`}</strong>{' '}
              <em>{offered?.title || 'a book that is no longer listed'}</em> for{' '}
              <em>{target?.title || 'a book that is no longer listed'}</em>
              <small>{timeAgo(x.createdAt)} · “{x.message}”</small>
            </div>
            {offered && target && (
              <PriceBreakdown
                compact
                valueA={offered.exchangeValue}
                valueB={target.exchangeValue}
                labelA={incoming ? firstName : 'You'}
                labelB={incoming ? 'You' : firstName}
              />
            )}
            <div className="req__side">
              <StatusPill status={x.status} />
              {x.status === 'pending' && incoming && (
                <>
                  <button type="button" className="btn btn--primary btn--xs" onClick={() => { respondExchange(x.id, 'accepted'); toast('Exchange accepted. Arrange the swap in Messages.', 'success'); }}>Accept</button>
                  <button type="button" className="btn btn--ghost btn--xs" onClick={() => respondExchange(x.id, 'declined')}>Decline</button>
                </>
              )}
              {x.status === 'pending' && !incoming && (
                <button type="button" className="btn btn--ghost btn--xs" onClick={() => { respondExchange(x.id, 'cancelled'); toast('Proposal withdrawn.'); }}>Withdraw</button>
              )}
              {x.status === 'accepted' && (
                <button type="button" className="btn btn--gold btn--xs" onClick={() => { respondExchange(x.id, 'completed'); toast('Marked as exchanged.', 'success'); }}>Mark as exchanged</button>
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

/* ---------------- Chains ---------------- */
function Chains() {
  const { myChains } = useApp();
  const sorted = useMemo(() => [...myChains].sort((a, b) => b.createdAt - a.createdAt), [myChains]);
  if (!sorted.length) {
    return <Empty icon="users" text="You are not part of any exchange chain yet. Find one on the Exchange page." to="/exchange" cta="Find an exchange chain" />;
  }
  return (
    <div className="stack">
      {sorted.map((c) => <ChainView key={c.id} chain={c} saved />)}
    </div>
  );
}

/* ---------------- Messages shortcut ---------------- */
function MessagesSummary() {
  const { me, myConversations, getUser, getListing } = useApp();
  const sorted = [...myConversations].sort((a, b) => (b.messages.at(-1)?.ts || 0) - (a.messages.at(-1)?.ts || 0));
  if (!sorted.length) return <Empty icon="message" text="No conversations yet." to="/browse" cta="Browse books" />;
  return (
    <>
      <ul className="plain-rows">
        {sorted.map((c) => {
          const other = getUser(c.participants.find((p) => p !== me.id));
          const book = getListing(c.listingId);
          const last = c.messages.at(-1);
          return (
            <li key={c.id}>
              <Link to={`/messages/${c.id}`} className="row-link">
                <span className="avatar">{initials(other?.name)}</span>
                <span>
                  <strong>{other?.name}</strong>
                  <small>{book?.title || 'Book removed'} · {last ? last.text : 'No messages yet'}</small>
                </span>
                {(c.unread?.[me.id] || 0) > 0 && <span className="dot">{c.unread[me.id]}</span>}
              </Link>
            </li>
          );
        })}
      </ul>
      <Link to="/messages" className="btn btn--primary">Open Messages</Link>
    </>
  );
}

/* ---------------- Saved books ---------------- */
function Saved() {
  const { myFavs, getListing } = useApp();
  const books = myFavs.map((id) => getListing(id)).filter(Boolean);
  return <BookGrid books={books} empty="You have not saved any books yet. Tap the heart on a book to save it." />;
}

/* ---------------- Notifications ---------------- */
function Notifications() {
  const { myNotifications, markAllNotificationsRead, markNotificationRead } = useApp();
  const navigate = useNavigate();
  if (!myNotifications.length) return <Empty icon="bell" text="You are all caught up." />;
  const unread = myNotifications.filter((n) => !n.read).length;
  return (
    <>
      <div className="actions-row">
        <button type="button" className="btn btn--ghost btn--sm" disabled={!unread} onClick={markAllNotificationsRead}>
          Mark all as read{unread ? ` (${unread})` : ''}
        </button>
      </div>
      <ul className="plain-rows">
        {myNotifications.map((n) => (
          <li key={n.id}>
            <button
              type="button"
              className={`row-link row-link--btn ${n.read ? '' : 'is-unread'}`}
              onClick={() => {
                markNotificationRead(n.id);
                if (n.link) navigate(n.link);
              }}
            >
              <span className="row-link__icon"><Icon name="bell" size={16} /></span>
              <span>
                <strong>{n.text}</strong>
                <small>{timeAgo(n.ts)}</small>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </>
  );
}

const VIEWS = {
  profile: Profile,
  listings: ListingManager,
  purchases: Purchases,
  sales: Sales,
  'exchange-requests': ExchangeRequests,
  chains: Chains,
  messages: MessagesSummary,
  saved: Saved,
  notifications: Notifications,
};

export default function Dashboard() {
  const { section = 'profile' } = useParams();
  const { me, purchases, exchangeRequests, myNotifications, myChains, unreadMessages } = useApp();
  const current = SECTIONS.find((s) => s.id === section);
  const View = VIEWS[section];

  const badge = (id) => {
    if (!me) return 0;
    if (id === 'sales') return purchases.filter((p) => p.sellerId === me.id && p.status === 'pending').length;
    if (id === 'exchange-requests') return exchangeRequests.filter((x) => x.toUserId === me.id && x.status === 'pending').length;
    if (id === 'chains') return myChains.filter((c) => c.status === 'awaiting_approval').length;
    if (id === 'messages') return unreadMessages;
    if (id === 'notifications') return myNotifications.filter((n) => !n.read).length;
    return 0;
  };

  return (
    <RequireLogin message="Log in to open your dashboard.">
      <div className="container page page--wide">
        <header className="page-head">
          <p className="eyebrow">Dashboard</p>
          <h1>{current ? current.label : 'Dashboard'}</h1>
        </header>
        <div className="dash">
          <nav className="dash__nav card" aria-label="Dashboard sections">
            {SECTIONS.map((s) => (
              <NavLink key={s.id} to={`/dashboard/${s.id}`} className={({ isActive }) => `dash__link ${isActive ? 'is-active' : ''}`}>
                <Icon name={s.icon} size={18} />
                <span>{s.label}</span>
                {badge(s.id) > 0 && <span className="dot">{badge(s.id)}</span>}
              </NavLink>
            ))}
          </nav>
          <div className="dash__main">
            {View ? (
              <View key={section} />
            ) : (
              <Empty icon="alert" text="That dashboard section does not exist." to="/dashboard" cta="Back to dashboard" />
            )}
          </div>
        </div>
      </div>
    </RequireLogin>
  );
}
