import { Link, useSearchParams } from 'react-router-dom';
import ListingForm from '../components/ListingForm.jsx';
import RequireLogin from '../components/RequireLogin.jsx';
import { useApp } from '../context/AppContext.jsx';

export default function Sell() {
  const { me, getListing } = useApp();
  const [params] = useSearchParams();
  const editId = params.get('edit');
  const existing = editId ? getListing(editId) : null;
  const notAllowed = editId && (!existing || (me && existing.ownerId !== me.id));

  return (
    <RequireLogin message="Log in to list, edit or sell your books.">
      <div className="container page">
        <header className="page-head">
          <p className="eyebrow">{existing ? 'Edit listing' : 'Sell or exchange'}</p>
          <h1>{existing ? 'Edit your listing' : 'List your book'}</h1>
          <p className="muted">
            Each book has <strong>one front-cover image only</strong>. Set a selling price, an exchange value, or both.{' '}
            <Link to="/my-listings">Manage your listings</Link>
          </p>
        </header>
        {notAllowed ? (
          <div className="card gate">
            <h2>You cannot edit this listing</h2>
            <p>It does not exist or belongs to someone else.</p>
            <Link className="btn btn--primary" to="/my-listings">Back to My Listings</Link>
          </div>
        ) : (
          <ListingForm key={existing?.id || 'new'} initial={existing} />
        )}
      </div>
    </RequireLogin>
  );
}
