// Local demo data. Nothing here is real: names, requests and chats are fictional samples.
// Listings are designed so that several circular exchange chains of different sizes exist
// (for example an 8-person ring, a 4-person ring and some larger loops that connect them).

import { CATEGORY_BY_ID } from './taxonomy.js';

export const STORAGE_VERSION = 4;
export const DEMO_USER_ID = 'u1';

const DAY = 86400000;
const HOUR = 3600000;

// id, name, city, state, pin, wants, bio, joinedDaysAgo
const USER_ROWS = [
  ['u1', 'Aarav Sharma', 'New Delhi', 'Delhi', '110016', ["Harry Potter Philosopher's Stone", 'Wings of Fire'], 'Class 12 student who loves fantasy and swapping study books.', 220],
  ['u2', 'Priya Nair', 'Mumbai', 'Maharashtra', '400050', ['Class 10 Mathematics'], 'Reads everything from mythology retellings to thrillers.', 410],
  ['u3', 'Rohan Gowda', 'Bengaluru', 'Karnataka', '560034', ['Palace of Illusions'], 'Collector of classic Indian short stories.', 180],
  ['u4', 'Ananya Iyer', 'Chennai', 'Tamil Nadu', '600020', ['Malgudi Days'], 'Physics teacher, passing books on to the next batch.', 520],
  ['u5', 'Karthik Reddy', 'Hyderabad', 'Telangana', '500034', ['H C Verma Physics', 'The Hobbit'], 'Engineering aspirant and fantasy fan.', 150],
  ['u6', 'Meera Kulkarni', 'Pune', 'Maharashtra', '411038', ['Immortals of Meluha'], 'Science student, mythological fiction reader.', 330],
  ['u7', 'Debashis Sen', 'Kolkata', 'West Bengal', '700019', ['Class 12 Chemistry'], 'Detective-fiction enthusiast.', 260],
  ['u8', 'Sneha Rathore', 'Jaipur', 'Rajasthan', '302017', ['Adventures of Feluda'], 'Book club organiser.', 90],
  ['u9', 'Vikram Patel', 'Ahmedabad', 'Gujarat', '380015', ['Class 10 Biology'], 'Parent clearing out shelves after exams.', 300],
  ['u10', 'Divya Menon', 'Kochi', 'Kerala', '682016', ['Class 9 Science'], 'Primary school librarian.', 70],
  ['u11', 'Harpreet Singh', 'Chandigarh', 'Chandigarh', '160017', ['Wimpy Kid'], 'Weekend trekker, adventure book lover.', 140],
  ['u12', 'Neha Joshi', 'Bhopal', 'Madhya Pradesh', '462016', ['The Hobbit', 'Malgudi Days'], 'Biology student.', 200],
  ['u13', 'Ishita Banerjee', 'Kolkata', 'West Bengal', '700029', ['Lord of the Rings'], 'Literature graduate.', 365],
  ['u14', 'Arjun Mehta', 'Surat', 'Gujarat', '395007', [], 'Commerce tutor selling spare textbooks.', 120],
  ['u15', 'Fatima Khan', 'Lucknow', 'Uttar Pradesh', '226010', [], 'Humanities student.', 85],
  ['u16', 'Gurpreet Kaur', 'Ludhiana', 'Punjab', '141001', [], 'Mother of two avid young readers.', 240],
  ['u17', 'Lakshmi Pillai', 'Thiruvananthapuram', 'Kerala', '695014', [], 'Crime-fiction fan.', 400],
  ['u18', 'Siddharth Rao', 'Visakhapatnam', 'Andhra Pradesh', '530003', [], 'Self-help and non-fiction reader.', 60],
];

export const SEED_USERS = USER_ROWS.map(([id, name, city, state, pin, wants, bio, days]) => ({
  id,
  name,
  city,
  state,
  pin,
  wants,
  bio,
  joined: Date.now() - days * DAY,
}));

// id, owner, title, author, category, subject, board, condition, type, price, exchangeValue, description
const LISTING_ROWS = [
  ['b01', 'u1', 'NCERT Mathematics Class 10', 'NCERT', 'class-10', 'Mathematics', 'CBSE', 'Good', 'both', 90, 120, 'Clean copy with all exercises unsolved. A few highlighted formulas in the margins.'],
  ['b02', 'u1', 'R.D. Sharma Mathematics Class 10', 'R.D. Sharma', 'class-10', 'Mathematics', 'CBSE', 'Like New', 'exchange', null, 220, 'Barely used reference book. Looking to swap for a good novel.'],
  ['b03', 'u1', 'The Blue Umbrella', 'Ruskin Bond', 'childrens', null, null, 'Good', 'sell', 80, null, 'Charming short novel for young readers. Cover slightly rubbed.'],
  ['b04', 'u2', 'The Palace of Illusions', 'Chitra Banerjee Divakaruni', 'fiction', null, null, 'Like New', 'both', 190, 210, 'The Mahabharata retold through Draupadi. Read once, spine intact.'],
  ['b05', 'u2', 'India and the Contemporary World I Class 9', 'NCERT', 'class-9', 'Social Science', 'CBSE', 'Good', 'sell', 65, null, 'History textbook, no torn pages.'],
  ['b06', 'u2', 'Gone Girl', 'Gillian Flynn', 'mystery', null, null, 'Good', 'sell', 160, null, 'Gripping psychological thriller. Pages are crisp.'],
  ['b07', 'u3', 'Malgudi Days', 'R.K. Narayan', 'fiction', null, null, 'Good', 'both', 120, 150, 'Classic collection of short stories set in the fictional town of Malgudi.'],
  ['b08', 'u3', 'Karnataka State Board Mathematics Class 10', 'Karnataka Textbook Society', 'class-10', 'Mathematics', 'State Board', 'Fair', 'sell', 60, null, 'English-medium edition, some pencil work.'],
  ['b09', 'u3', 'Treasure Island', 'Robert Louis Stevenson', 'adventure', null, null, 'Good', 'exchange', null, 130, 'Pirate adventure classic. Happy to swap for a textbook.'],
  ['b10', 'u4', 'Concepts of Physics Vol 1', 'H.C. Verma', 'class-11', 'Physics', 'CBSE', 'Good', 'both', 260, 320, 'Light pencil marks on a few pages. Great for JEE and board prep.'],
  ['b11', 'u4', 'Tamil Nadu State Board Science Class 10', 'SCERT Tamil Nadu', 'class-10', 'Science', 'State Board', 'Good', 'sell', 85, null, 'English-medium textbook in good condition.'],
  ['b12', 'u4', 'Matilda', 'Roald Dahl', 'childrens', null, null, 'Like New', 'sell', 150, null, 'A favourite for ages 8 and up. No scribbles.'],
  ['b13', 'u5', 'The Immortals of Meluha', 'Amish', 'fantasy', null, null, 'Good', 'exchange', null, 199, 'First book of the Shiva Trilogy. Looking for a physics reference.'],
  ['b14', 'u5', 'NCERT Physics Part 1 Class 12', 'NCERT', 'class-12', 'Physics', 'CBSE', 'Good', 'sell', 100, null, 'Neat copy with solved examples tabbed.'],
  ['b15', 'u5', 'Atomic Habits', 'James Clear', 'non-fiction', null, null, 'Like New', 'sell', 280, null, 'Bestselling guide to building habits. Almost new.'],
  ['b16', 'u6', 'NCERT Chemistry Part 1 Class 12', 'NCERT', 'class-12', 'Chemistry', 'CBSE', 'Good', 'exchange', null, 130, 'Reaction mechanisms highlighted, rest of the book clean.'],
  ['b17', 'u6', 'Maharashtra Balbharati Science Class 10', 'Balbharati', 'class-10', 'Science', 'State Board', 'Fair', 'sell', 70, null, 'English-medium edition. Cover is worn.'],
  ['b18', 'u6', 'Sapiens', 'Yuval Noah Harari', 'non-fiction', null, null, 'Good', 'both', 300, 340, 'A brief history of humankind. Minor shelf wear.'],
  ['b19', 'u7', 'The Adventures of Feluda', 'Satyajit Ray', 'mystery', null, null, 'Good', 'exchange', null, 240, 'English translation of the beloved Bengali detective stories.'],
  ['b20', 'u7', 'NCERT Biology Class 12', 'NCERT', 'class-12', 'Biology', 'CBSE', 'Good', 'sell', 110, null, 'Diagrams intact, no missing pages.'],
  ['b21', 'u7', 'The Hound of the Baskervilles', 'Arthur Conan Doyle', 'mystery', null, null, 'Fair', 'sell', 90, null, 'Sherlock Holmes classic. Yellowed pages but readable.'],
  ['b22', 'u8', "Harry Potter and the Philosopher's Stone", 'J.K. Rowling', 'fantasy', null, null, 'Like New', 'exchange', null, 350, 'Paperback in near-perfect condition. Open to swaps only.'],
  ['b23', 'u8', 'Double Entry Book Keeping Class 11', 'T.S. Grewal', 'class-11', 'Commerce', 'CBSE', 'Good', 'sell', 220, null, 'Standard accountancy reference with solved problems.'],
  ['b24', 'u8', 'The Lion, the Witch and the Wardrobe', 'C.S. Lewis', 'fantasy', null, null, 'Good', 'sell', 140, null, 'Chronicles of Narnia book one.'],
  ['b25', 'u9', 'NCERT Science Class 9', 'NCERT', 'class-9', 'Science', 'CBSE', 'Good', 'both', 70, 90, 'Complete textbook, exercises untouched.'],
  ['b26', 'u9', 'Beehive English Class 9', 'NCERT', 'class-9', 'English', 'CBSE', 'Good', 'sell', 55, null, 'Reader with a few underlined poems.'],
  ['b27', 'u9', 'Wings of Fire', 'A.P.J. Abdul Kalam', 'non-fiction', null, null, 'Good', 'both', 150, 180, 'Autobiography of the Missile Man of India.'],
  ['b28', 'u10', 'Diary of a Wimpy Kid', 'Jeff Kinney', 'childrens', null, null, 'Good', 'exchange', null, 140, 'Funny illustrated diary novel for middle-grade readers.'],
  ['b29', 'u10', 'The God of Small Things', 'Arundhati Roy', 'novels', null, null, 'Good', 'sell', 170, null, 'Booker Prize-winning novel. Clean pages.'],
  ['b30', 'u11', 'The Hobbit', 'J.R.R. Tolkien', 'fantasy', null, null, 'Like New', 'exchange', null, 260, "Bilbo's adventure there and back again. Hardly read."],
  ['b31', 'u11', 'Percy Jackson: The Lightning Thief', 'Rick Riordan', 'fantasy', null, null, 'Good', 'sell', 190, null, 'Greek myths meet modern America.'],
  ['b32', 'u12', 'ICSE Biology Class 10 Selina Concise', 'Selina Publishers', 'class-10', 'Biology', 'ICSE', 'Good', 'exchange', null, 150, 'ICSE biology reference with chapter summaries.'],
  ['b33', 'u12', 'Murder on the Orient Express', 'Agatha Christie', 'mystery', null, null, 'Good', 'sell', 170, null, 'Poirot at his best. Soft cover.'],
  ['b34', 'u13', 'The White Tiger', 'Aravind Adiga', 'novels', null, null, 'Good', 'exchange', null, 200, 'Man Booker Prize winner. Looking for a rare fantasy epic.'],
  ['b35', 'u13', 'Train to Pakistan', 'Khushwant Singh', 'novels', null, null, 'Fair', 'sell', 90, null, 'Partition-era classic. Cover creased.'],
  ['b36', 'u13', "Chanakya's Chant", 'Ashwin Sanghi', 'novels', null, null, 'Good', 'sell', 180, null, 'Dual-timeline political thriller.'],
  ['b37', 'u14', 'NCERT Accountancy Part 1 Class 12', 'NCERT', 'class-12', 'Commerce', 'CBSE', 'Good', 'sell', 95, null, 'Partnership accounts chapters flagged.'],
  ['b38', 'u14', 'Business Studies Class 12', 'NCERT', 'class-12', 'Commerce', 'CBSE', 'Good', 'sell', 85, null, 'Clean textbook, no marginalia.'],
  ['b39', 'u14', 'NCERT Chemistry Part 1 Class 11', 'NCERT', 'class-11', 'Chemistry', 'CBSE', 'Good', 'sell', 100, null, 'Organic chemistry chapters have light notes.'],
  ['b40', 'u14', 'NCERT Mathematics Class 11', 'NCERT', 'class-11', 'Mathematics', 'CBSE', 'Fair', 'sell', 85, null, 'Cover taped, interior intact.'],
  ['b41', 'u15', 'Indian Constitution at Work Class 11', 'NCERT', 'class-11', 'Humanities', 'CBSE', 'Good', 'sell', 80, null, 'Political science textbook, very clean.'],
  ['b42', 'u15', 'First Flight English Class 10', 'NCERT', 'class-10', 'English', 'CBSE', 'Good', 'sell', 60, null, 'Prose and poetry reader.'],
  ['b43', 'u15', 'Contemporary India II Class 10', 'NCERT', 'class-10', 'Social Science', 'CBSE', 'Good', 'sell', 65, null, 'Geography textbook with all maps intact.'],
  ['b44', 'u15', 'The Jungle Book', 'Rudyard Kipling', 'childrens', null, null, 'Good', 'sell', 110, null, "Mowgli's stories with illustrations."],
  ['b45', 'u16', 'Panchatantra: Classic Tales', 'Vishnu Sharma (traditional)', 'storybooks', null, null, 'Good', 'sell', 100, null, 'Colourful retelling of the ancient fables.'],
  ['b46', 'u16', 'Five on a Treasure Island', 'Enid Blyton', 'adventure', null, null, 'Good', 'both', 120, 150, 'The first Famous Five adventure.'],
  ['b47', 'u16', "Charlotte's Web", 'E.B. White', 'childrens', null, null, 'Like New', 'sell', 140, null, 'A gentle story of friendship, almost new.'],
  ['b48', 'u16', 'Flamingo English Class 12', 'NCERT', 'class-12', 'English', 'CBSE', 'Good', 'sell', 70, null, 'Prose and poetry, some underlining.'],
  ['b49', 'u17', 'The Girl with the Dragon Tattoo', 'Stieg Larsson', 'mystery', null, null, 'Good', 'sell', 190, null, 'Nordic noir bestseller.'],
  ['b50', 'u17', 'The Alchemist', 'Paulo Coelho', 'fiction', null, null, 'Like New', 'both', 160, 190, 'A fable about following your dreams.'],
  ['b51', 'u17', 'The Discovery of India', 'Jawaharlal Nehru', 'non-fiction', null, null, 'Fair', 'sell', 200, null, 'Older edition with yellowed pages.'],
  ['b52', 'u17', 'The Room on the Roof', 'Ruskin Bond', 'novels', null, null, 'Good', 'sell', 110, null, "Ruskin Bond's first novel, set in Dehradun."],
  ['b53', 'u18', 'Ikigai', 'Hector Garcia and Francesc Miralles', 'non-fiction', null, null, 'Like New', 'sell', 220, null, 'The Japanese secret to a long and happy life.'],
  ['b54', 'u18', 'Democratic Politics Class 9', 'NCERT', 'class-9', 'Social Science', 'CBSE', 'Good', 'sell', 60, null, 'Civics textbook in good shape.'],
  ['b55', 'u18', 'Andhra Pradesh State Board Physical Science Class 10', 'SCERT Andhra Pradesh', 'class-10', 'Science', 'State Board', 'Fair', 'sell', 70, null, 'English-medium physical science text.'],
  ['b56', 'u18', "Tales of Birbal", 'Traditional (retold)', 'storybooks', null, null, 'Good', 'sell', 70, null, 'Witty tales from Akbar\'s court for young readers.'],
];

const FEATURED = new Set(['b22', 'b04', 'b10', 'b27', 'b30', 'b50', 'b18', 'b01']);

export function createSeedListings() {
  const userById = Object.fromEntries(SEED_USERS.map((u) => [u.id, u]));
  return LISTING_ROWS.map(
    ([id, ownerId, title, author, category, subject, board, condition, type, price, exchangeValue, description], i) => {
      const owner = userById[ownerId];
      return {
        id,
        ownerId,
        title,
        author,
        category,
        classLevel: CATEGORY_BY_ID[category].classLevel || null,
        subject,
        board,
        condition,
        type,
        price,
        exchangeValue,
        description,
        city: owner.city,
        state: owner.state,
        pin: owner.pin,
        cover: null, // ONE front cover per book; null shows a generated placeholder cover
        status: 'active',
        featured: FEATURED.has(id),
        createdAt: Date.now() - Math.round((i * 0.9 + 0.5) * DAY),
      };
    },
  );
}

// Pool used by the "Chain Lab" simulation (one entry per distinct title).
export function createLabPool() {
  return createSeedListings().map((l) => ({
    title: l.title,
    author: l.author,
    category: l.category,
    classLevel: l.classLevel,
    subject: l.subject,
    board: l.board,
    condition: l.condition,
    description: l.description,
    featured: false,
    createdAt: l.createdAt,
    pin: l.pin,
    exchangeValue: l.exchangeValue || l.price || 150,
    price: l.price,
  }));
}

export function createSeedState() {
  const t = Date.now();
  return {
    version: STORAGE_VERSION,
    currentUserId: null,
    users: SEED_USERS.map((u) => ({ ...u, wants: [...u.wants] })),
    listings: createSeedListings(),
    favs: { u1: ['b10', 'b30', 'b50'] },
    purchases: [
      {
        id: 'p1',
        listingId: 'b03',
        title: 'The Blue Umbrella',
        buyerId: 'u15',
        sellerId: 'u1',
        price: 80,
        message: 'Hi! Is this still available? I can collect it from Rohini this weekend.',
        status: 'pending',
        createdAt: t - 5 * HOUR,
      },
      {
        id: 'p2',
        listingId: 'b39',
        title: 'NCERT Chemistry Part 1 Class 11',
        buyerId: 'u1',
        sellerId: 'u14',
        price: 100,
        message: 'Interested in this for my cousin. Could you ship to Delhi?',
        status: 'pending',
        createdAt: t - 26 * HOUR,
      },
    ],
    exchangeRequests: [
      {
        id: 'x1',
        fromUserId: 'u3',
        toUserId: 'u1',
        offeredId: 'b09',
        targetId: 'b02',
        message: 'I would love to swap Treasure Island for your R.D. Sharma book.',
        status: 'pending',
        createdAt: t - 9 * HOUR,
      },
    ],
    chains: [],
    conversations: [
      {
        id: 'c1',
        listingId: 'b10',
        participants: ['u1', 'u4'],
        unread: {},
        messages: [
          { id: 'm1', from: 'u1', text: 'Hello Ananya, is Concepts of Physics Vol 1 still available?', ts: t - 30 * HOUR },
          { id: 'm2', from: 'u4', text: 'Yes, it is! Only light pencil marks on a few pages.', ts: t - 29 * HOUR },
          { id: 'm3', from: 'u1', text: 'Great. Would you consider an exchange? I have R.D. Sharma Class 10 Maths.', ts: t - 28 * HOUR },
        ],
      },
      {
        id: 'c2',
        listingId: 'b01',
        participants: ['u1', 'u2'],
        unread: { u1: 1 },
        messages: [
          { id: 'm4', from: 'u2', text: 'Hi Aarav, I am interested in swapping my Palace of Illusions for your Class 10 Maths book.', ts: t - 3 * HOUR },
        ],
      },
    ],
    notifications: [
      { id: 'n1', userId: 'u1', text: 'Fatima Khan asked to buy "The Blue Umbrella".', link: '/dashboard/sales', ts: t - 5 * HOUR, read: false },
      { id: 'n2', userId: 'u1', text: 'Rohan Gowda proposed an exchange for "R.D. Sharma Mathematics Class 10".', link: '/dashboard/exchange-requests', ts: t - 9 * HOUR, read: false },
      { id: 'n3', userId: 'u1', text: 'Priya Nair sent you a message about "NCERT Mathematics Class 10".', link: '/messages/c2', ts: t - 3 * HOUR, read: false },
      { id: 'n4', userId: 'u1', text: 'Tip: add the books you want so Ex-Book can look for exchange chains.', link: '/exchange', ts: t - 48 * HOUR, read: true },
    ],
  };
}
