// Shared lookup data: categories, subjects, boards, conditions, Indian states & cities.

export const CATEGORIES = [
  { id: 'class-9', label: 'Class 9 Textbooks', short: 'Class 9', kind: 'textbook', classLevel: 9, icon: 'book' },
  { id: 'class-10', label: 'Class 10 Textbooks', short: 'Class 10', kind: 'textbook', classLevel: 10, icon: 'book' },
  { id: 'class-11', label: 'Class 11 Textbooks', short: 'Class 11', kind: 'textbook', classLevel: 11, icon: 'book' },
  { id: 'class-12', label: 'Class 12 Textbooks', short: 'Class 12', kind: 'textbook', classLevel: 12, icon: 'book' },
  { id: 'storybooks', label: 'Storybooks', short: 'Storybooks', kind: 'general', icon: 'star' },
  { id: 'novels', label: 'Novels', short: 'Novels', kind: 'general', icon: 'book' },
  { id: 'adventure', label: 'Adventure', short: 'Adventure', kind: 'general', icon: 'compass' },
  { id: 'mystery', label: 'Mystery', short: 'Mystery', kind: 'general', icon: 'search' },
  { id: 'fantasy', label: 'Fantasy', short: 'Fantasy', kind: 'general', icon: 'sparkle' },
  { id: 'childrens', label: "Children's Books", short: "Children's", kind: 'general', icon: 'smile' },
  { id: 'fiction', label: 'Fiction', short: 'Fiction', kind: 'general', icon: 'book' },
  { id: 'non-fiction', label: 'Non-fiction', short: 'Non-fiction', kind: 'general', icon: 'tag' },
];

export const CATEGORY_BY_ID = Object.fromEntries(CATEGORIES.map((c) => [c.id, c]));
export const isTextbookCategory = (id) => CATEGORY_BY_ID[id]?.kind === 'textbook';

export const SUBJECTS = [
  'Mathematics',
  'Science',
  'English',
  'Social Science',
  'Physics',
  'Chemistry',
  'Biology',
  'Commerce',
  'Humanities',
];

export const SUBJECTS_BY_CLASS = {
  9: ['Mathematics', 'Science', 'English', 'Social Science'],
  10: ['Mathematics', 'Science', 'English', 'Social Science'],
  11: ['Physics', 'Chemistry', 'Biology', 'Mathematics', 'English', 'Commerce', 'Humanities'],
  12: ['Physics', 'Chemistry', 'Biology', 'Mathematics', 'English', 'Commerce', 'Humanities'],
};

export const BOARDS = ['CBSE', 'ICSE', 'State Board'];

export const CONDITIONS = [
  { id: 'New', hint: 'Unused, as bought' },
  { id: 'Like New', hint: 'Read once or twice, no marks' },
  { id: 'Good', hint: 'Minor wear, light pencil notes' },
  { id: 'Fair', hint: 'Visible wear but fully readable' },
];

export const LISTING_TYPES = [
  { id: 'sell', label: 'Sell', hint: 'Sell for a fixed price' },
  { id: 'exchange', label: 'Exchange', hint: 'Swap for books you want' },
  { id: 'both', label: 'Both', hint: 'Open to a sale or an exchange' },
];

export const STATES = {
  'Andhra Pradesh': ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Tirupati', 'Nellore'],
  Assam: ['Guwahati', 'Dibrugarh', 'Silchar', 'Jorhat'],
  Bihar: ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur'],
  Chandigarh: ['Chandigarh'],
  Chhattisgarh: ['Raipur', 'Bhilai', 'Bilaspur'],
  Delhi: ['New Delhi', 'Dwarka', 'Rohini', 'Saket'],
  Goa: ['Panaji', 'Margao', 'Vasco da Gama'],
  Gujarat: ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Gandhinagar'],
  Haryana: ['Gurugram', 'Faridabad', 'Panipat', 'Ambala'],
  'Himachal Pradesh': ['Shimla', 'Dharamshala', 'Solan'],
  Jharkhand: ['Ranchi', 'Jamshedpur', 'Dhanbad'],
  Karnataka: ['Bengaluru', 'Mysuru', 'Mangaluru', 'Hubballi'],
  Kerala: ['Kochi', 'Thiruvananthapuram', 'Kozhikode', 'Thrissur'],
  'Madhya Pradesh': ['Bhopal', 'Indore', 'Gwalior', 'Jabalpur'],
  Maharashtra: ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Thane'],
  Odisha: ['Bhubaneswar', 'Cuttack', 'Rourkela'],
  Punjab: ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala'],
  Rajasthan: ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota'],
  'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli'],
  Telangana: ['Hyderabad', 'Warangal', 'Nizamabad'],
  'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Varanasi', 'Noida', 'Agra', 'Prayagraj'],
  Uttarakhand: ['Dehradun', 'Haridwar', 'Haldwani'],
  'West Bengal': ['Kolkata', 'Howrah', 'Siliguri', 'Durgapur'],
};

export const STATE_NAMES = Object.keys(STATES).sort();

export const PIN_RE = /^[1-9][0-9]{5}$/;
