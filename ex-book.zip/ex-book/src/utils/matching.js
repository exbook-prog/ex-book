// Circular exchange matching.
//
// Model: every participant GIVES exactly one book and RECEIVES exactly one book.
// Draw a directed edge G -> R when R "wants" something that G owns (and lists for exchange).
// A valid exchange chain is a simple directed cycle: A -> B -> C -> ... -> A.
// The size of the cycle is NOT limited to three: any size from 2 up to maxLen is searched.
// A chain is only returned when a real cycle exists - nothing is ever invented.

import { CATEGORY_BY_ID } from '../data/taxonomy.js';
import { calcLink, calcChain } from './pricing.js';
import { hashStr } from './format.js';

const STOP = new Set(['the', 'of', 'a', 'an', 'and', 'by', 'in', 'for', 'to', 'on']);
const SYNONYMS = {
  maths: 'mathematics',
  math: 'mathematics',
  bio: 'biology',
  chem: 'chemistry',
  eng: 'english',
  grade: 'class',
  std: 'class',
};

export function tokenize(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/['’]/g, '')
    .split(/[^a-z0-9]+/)
    .filter(Boolean)
    .map((t) => SYNONYMS[t] || t)
    .filter((t) => !STOP.has(t));
}

export function listingTokens(listing) {
  const cat = CATEGORY_BY_ID[listing.category];
  const text = [
    listing.title,
    listing.author,
    cat ? cat.label : '',
    listing.subject || '',
    listing.board || '',
    listing.classLevel ? `class ${listing.classLevel}` : '',
  ].join(' ');
  return new Set(tokenize(text));
}

// A want matches when every keyword in it appears in the listing's title/author/class/subject/board.
export function wantMatches(wantText, tokenSet) {
  const tokens = tokenize(wantText);
  return tokens.length > 0 && tokens.every((t) => tokenSet.has(t));
}

export function isExchangeEligible(l) {
  return (
    l.status === 'active' && (l.type === 'exchange' || l.type === 'both') && Number(l.exchangeValue) > 0
  );
}

export function buildGraph(users, listings) {
  const eligible = listings.filter(isExchangeEligible);
  const tokenCache = new Map(eligible.map((l) => [l.id, listingTokens(l)]));
  const byOwner = new Map();
  eligible.forEach((l) => {
    if (!byOwner.has(l.ownerId)) byOwner.set(l.ownerId, []);
    byOwner.get(l.ownerId).push(l);
  });

  // adj: giverId -> Map(receiverId -> [{ listing, want }])
  const adj = new Map();
  users.forEach((giver) => {
    const owned = byOwner.get(giver.id);
    if (!owned) return;
    users.forEach((receiver) => {
      if (receiver.id === giver.id || !receiver.wants?.length) return;
      const options = [];
      owned.forEach((listing) => {
        const want = receiver.wants.find((w) => wantMatches(w, tokenCache.get(listing.id)));
        if (want) options.push({ listing, want });
      });
      if (options.length) {
        if (!adj.has(giver.id)) adj.set(giver.id, new Map());
        adj.get(giver.id).set(receiver.id, options);
      }
    });
  });
  return adj;
}

// Remove nodes that cannot be on a cycle (no incoming or no outgoing edge), repeatedly.
function prune(adj) {
  const out = new Map();
  adj.forEach((m, k) => out.set(k, new Map(m)));
  let changed = true;
  while (changed) {
    changed = false;
    const indeg = new Map();
    out.forEach((m) => m.forEach((_, v) => indeg.set(v, (indeg.get(v) || 0) + 1)));
    const nodes = new Set([...out.keys(), ...indeg.keys()]);
    nodes.forEach((n) => {
      const outdeg = out.get(n)?.size || 0;
      if (!outdeg || !indeg.get(n)) {
        out.delete(n);
        out.forEach((m) => m.delete(n));
        changed = true;
      }
    });
  }
  return out;
}

// Tarjan's strongly connected components. Only nodes inside an SCC can share a cycle.
function sccs(adj) {
  let index = 0;
  const stack = [];
  const onStack = new Set();
  const idx = new Map();
  const low = new Map();
  const result = [];
  const visit = (v) => {
    idx.set(v, index);
    low.set(v, index);
    index += 1;
    stack.push(v);
    onStack.add(v);
    (adj.get(v) || new Map()).forEach((_, w) => {
      if (!idx.has(w)) {
        visit(w);
        low.set(v, Math.min(low.get(v), low.get(w)));
      } else if (onStack.has(w)) {
        low.set(v, Math.min(low.get(v), idx.get(w)));
      }
    });
    if (low.get(v) === idx.get(v)) {
      const comp = [];
      let w;
      do {
        w = stack.pop();
        onStack.delete(w);
        comp.push(w);
      } while (w !== v);
      result.push(comp);
    }
  };
  [...adj.keys()].forEach((v) => {
    if (!idx.has(v)) visit(v);
  });
  return result.filter((c) => c.length > 1);
}

/**
 * Find circular exchange chains.
 * opts: minLen (>=2), maxLen (up to 60), maxGap (rupees, max value gap in any link),
 *       mustInclude (userId), limit, budget (search steps), sort.
 */
export function findChains(users, listings, opts = {}) {
  const {
    minLen = 2,
    maxLen = 60,
    maxGap = Infinity,
    mustInclude = null,
    limit = 40,
    budget = 400000,
    sort = 'size-desc',
  } = opts;

  const userById = new Map(users.map((u) => [u.id, u]));
  const rawAdj = buildGraph(users, listings);
  const adj = prune(rawAdj);
  const chains = [];
  const seen = new Set();
  let steps = 0;
  let truncated = false;
  let stop = false;

  const gapCost = (la, lb) => {
    const gap = Math.abs(Number(la.exchangeValue) - Number(lb.exchangeValue));
    return gap > maxGap ? Infinity : gap;
  };

  // Choose which of each person's matching books to give so that value gaps stay small.
  function assign(cycle) {
    const n = cycle.length;
    const opts2 = cycle.map((u, i) => adj.get(u).get(cycle[(i + 1) % n]));
    let best = null;
    for (let s = 0; s < opts2[0].length; s += 1) {
      const dp = [[{ cost: 0, back: -1 }]];
      for (let k = 1; k < n; k += 1) {
        const row = opts2[k].map((o, oi) => {
          let bestCost = Infinity;
          let back = -1;
          dp[k - 1].forEach((prev, pi) => {
            if (!Number.isFinite(prev.cost)) return;
            const prevListing = k === 1 ? opts2[0][s].listing : opts2[k - 1][pi].listing;
            const c = prev.cost + gapCost(prevListing, o.listing);
            if (c < bestCost) {
              bestCost = c;
              back = pi;
            }
          });
          return { cost: bestCost, back, oi };
        });
        dp.push(row);
      }
      // Close the ring (a 2-person swap has a single link).
      const closeLinks = n > 2;
      dp[n - 1].forEach((cell, oi) => {
        const lastListing = n === 1 ? opts2[0][s].listing : opts2[n - 1][oi].listing;
        const total = cell.cost + (closeLinks ? gapCost(lastListing, opts2[0][s].listing) : 0);
        if (Number.isFinite(total) && (!best || total < best.total)) {
          // backtrack
          const choice = new Array(n);
          choice[0] = s;
          let cur = oi;
          for (let k = n - 1; k >= 1; k -= 1) {
            choice[k] = cur;
            cur = dp[k][cur].back;
          }
          best = { total, choice };
        }
      });
    }
    if (!best) return null;
    return { opts: opts2, choice: best.choice, total: best.total };
  }

  function record(cycle) {
    const picked = assign(cycle);
    if (!picked) return false;
    const n = cycle.length;
    const given = cycle.map((_, k) => picked.opts[k][picked.choice[k]]);
    const participants = cycle.map((userId, k) => {
      const prev = given[(k - 1 + n) % n];
      return {
        userId,
        giveListingId: given[k].listing.id,
        receiveListingId: prev.listing.id,
        wantMatched: prev.want,
      };
    });
    const values = given.map((g) => Number(g.listing.exchangeValue));
    const calc = calcChain(values, { closed: true });
    const maxLink = calc.links.reduce((m, l) => Math.max(m, l.difference), 0);
    const key = given.map((g) => g.listing.id).sort().join('|');
    if (seen.has(key)) return false;
    seen.add(key);
    chains.push({
      code: `CH-${hashStr(key).toString(36).toUpperCase().slice(0, 6)}`,
      size: n,
      participants,
      totalDifference: calc.totalDifference,
      totalCommission: calc.totalCommission,
      maxLinkDifference: maxLink,
      totalGap: picked.total,
    });
    return true;
  }

  function dfsFrom(start, allowed, canonicalOrder) {
    const path = [start];
    const onPath = new Set([start]);
    const dfs = (u) => {
      const nexts = adj.get(u);
      if (!nexts) return;
      for (const v of nexts.keys()) {
        if (stop) return;
        if (!allowed.has(v)) continue;
        if (canonicalOrder && canonicalOrder.get(v) < canonicalOrder.get(start)) continue;
        if (v === start) {
          if (path.length >= minLen && record([...path]) && chains.length >= limit) {
            stop = true;
            return;
          }
          continue;
        }
        if (onPath.has(v) || path.length >= maxLen) continue;
        steps += 1;
        if (steps > budget) {
          truncated = true;
          stop = true;
          return;
        }
        path.push(v);
        onPath.add(v);
        dfs(v);
        path.pop();
        onPath.delete(v);
      }
    };
    dfs(start);
  }

  const comps = sccs(adj);
  for (const comp of comps) {
    if (stop) break;
    if (mustInclude) {
      if (!comp.includes(mustInclude)) continue;
      dfsFrom(mustInclude, new Set(comp), null);
    } else {
      const order = new Map(comp.map((n, i) => [n, i]));
      const allowed = new Set(comp);
      for (const start of comp) {
        if (stop) break;
        dfsFrom(start, allowed, order);
      }
    }
  }

  const cmp = {
    'size-desc': (a, b) => b.size - a.size || a.totalGap - b.totalGap,
    'size-asc': (a, b) => a.size - b.size || a.totalGap - b.totalGap,
    'gap-asc': (a, b) => a.totalGap - b.totalGap || b.size - a.size,
  }[sort];
  chains.sort(cmp || cmp);

  return {
    chains,
    truncated: truncated || chains.length >= limit,
    stats: {
      participantsConsidered: new Set([...rawAdj.keys(), ...[...rawAdj.values()].flatMap((m) => [...m.keys()])]).size,
      participantsInCycles: comps.reduce((s, c) => s + c.length, 0),
      knownUsers: userById.size,
    },
  };
}

// ---- Chain Lab: simulated community used to demonstrate large chains (4, 8, 15, 25, 50 ...) ----

const LAB_FIRST = [
  'Aditi', 'Rahul', 'Kavya', 'Nikhil', 'Pooja', 'Siddharth', 'Tanvi', 'Manish', 'Ritika', 'Varun',
  'Shreya', 'Akash', 'Nandini', 'Gaurav', 'Isha', 'Harsh', 'Lavanya', 'Pranav', 'Swati', 'Dhruv',
  'Bhavna', 'Yash', 'Anjali', 'Kunal', 'Rekha',
];
const LAB_LAST = [
  'Verma', 'Das', 'Pillai', 'Chopra', 'Bose', 'Naidu', 'Kapoor', 'Shetty', 'Mishra', 'Jain',
  'Ghosh', 'Menon', 'Thakur', 'Rao', 'Saxena', 'Bhatt', 'Sinha', 'Desai', 'Yadav', 'Khanna',
  'Pandey', 'Iyengar', 'Malhotra', 'Chauhan', 'Joshi',
];
const LAB_CITIES = [
  ['Mumbai', 'Maharashtra'], ['Delhi', 'Delhi'], ['Bengaluru', 'Karnataka'], ['Chennai', 'Tamil Nadu'],
  ['Kolkata', 'West Bengal'], ['Hyderabad', 'Telangana'], ['Pune', 'Maharashtra'], ['Ahmedabad', 'Gujarat'],
  ['Jaipur', 'Rajasthan'], ['Lucknow', 'Uttar Pradesh'], ['Kochi', 'Kerala'], ['Bhopal', 'Madhya Pradesh'],
  ['Chandigarh', 'Chandigarh'], ['Patna', 'Bihar'], ['Indore', 'Madhya Pradesh'], ['Nagpur', 'Maharashtra'],
  ['Coimbatore', 'Tamil Nadu'], ['Guwahati', 'Assam'], ['Bhubaneswar', 'Odisha'], ['Dehradun', 'Uttarakhand'],
];

/**
 * Build a simulated community with a guaranteed ring of n readers plus a few decoys
 * whose wants nobody can satisfy (so the demo also shows that not everyone gets matched).
 * pool: array of { title, author, category, classLevel, subject, board, exchangeValue }.
 */
export function generateLabCommunity(n, pool) {
  const maxRing = Math.max(2, pool.length - 6);
  const size = Math.min(Math.max(2, Math.round(n)), maxRing);
  const decoys = Math.min(6, Math.max(2, Math.round(size / 8)));
  const users = [];
  const listings = [];

  for (let i = 0; i < size + decoys; i += 1) {
    const [city, state] = LAB_CITIES[(i * 7 + 3) % LAB_CITIES.length];
    const isDecoy = i >= size;
    const base = pool[i % pool.length];
    const prev = pool[(i - 1 + size) % size];
    users.push({
      id: `lab-u${i + 1}`,
      name: `${LAB_FIRST[i % LAB_FIRST.length]} ${LAB_LAST[(i * 3 + 1) % LAB_LAST.length]}`,
      city,
      state,
      lab: true,
      wants: isDecoy ? [`Rare first edition ${i + 1} nobody lists`] : [prev.title],
    });
    listings.push({
      ...base,
      id: `lab-b${i + 1}`,
      ownerId: `lab-u${i + 1}`,
      type: 'exchange',
      status: 'active',
      city,
      state,
      cover: null,
    });
  }
  return { users, listings, ringSize: size, decoys };
}
