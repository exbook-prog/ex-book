// Browse / Buy filtering and sorting (pure functions).

export const EMPTY_FILTERS = {
  q: '',
  cat: '',
  subject: '',
  board: '',
  cond: '',
  type: '',
  state: '',
  city: '',
  pin: '',
  min: '',
  max: '',
  sort: 'newest',
  fav: '',
};

export const displayPrice = (l) => (l.price != null && l.price !== '' ? Number(l.price) : Number(l.exchangeValue) || 0);

export function filterBooks(listings, f, { mode = 'all', favs = [] } = {}) {
  const q = (f.q || '').trim().toLowerCase();
  const terms = q.split(/\s+/).filter(Boolean);
  const min = f.min === '' ? null : Number(f.min);
  const max = f.max === '' ? null : Number(f.max);

  let out = listings.filter((l) => {
    if (l.status !== 'active') return false;
    if (mode === 'buy' && !(l.type === 'sell' || l.type === 'both')) return false;
    if (f.type === 'sell' && !(l.type === 'sell' || l.type === 'both')) return false;
    if (f.type === 'exchange' && !(l.type === 'exchange' || l.type === 'both')) return false;
    if (f.cat && l.category !== f.cat) return false;
    if (f.subject && l.subject !== f.subject) return false;
    if (f.board && l.board !== f.board) return false;
    if (f.cond && l.condition !== f.cond) return false;
    if (f.state && l.state !== f.state) return false;
    if (f.city && l.city !== f.city) return false;
    if (f.pin && !String(l.pin || '').startsWith(f.pin)) return false;
    if (f.fav && !favs.includes(l.id)) return false;

    const price = mode === 'buy' ? Number(l.price) : displayPrice(l);
    if (min !== null && !(price >= min)) return false;
    if (max !== null && !(price <= max)) return false;

    if (terms.length) {
      const hay = `${l.title} ${l.author} ${l.subject || ''} ${l.board || ''} ${l.city} ${l.state} ${
        l.classLevel ? `class ${l.classLevel}` : ''
      } ${l.category}`.toLowerCase();
      if (!terms.every((t) => hay.includes(t))) return false;
    }
    return true;
  });

  const priceOf = (l) => (mode === 'buy' ? Number(l.price) : displayPrice(l));
  const sorters = {
    newest: (a, b) => b.createdAt - a.createdAt,
    'price-asc': (a, b) => priceOf(a) - priceOf(b),
    'price-desc': (a, b) => priceOf(b) - priceOf(a),
    title: (a, b) => a.title.localeCompare(b.title),
  };
  out = [...out].sort(sorters[f.sort] || sorters.newest);
  return out;
}

export function filtersFromParams(params) {
  const f = { ...EMPTY_FILTERS };
  Object.keys(EMPTY_FILTERS).forEach((k) => {
    const v = params.get(k);
    if (v !== null) f[k] = v;
  });
  return f;
}

export function countActive(f) {
  return Object.keys(EMPTY_FILTERS).filter((k) => k !== 'sort' && f[k] !== '' && f[k] != null).length;
}
