// Exchange chain lifecycle: approvals -> confirmation -> delivery -> completion or cancellation.
// All functions are pure: they take a chain and return a new chain.

import { calcChain } from './pricing.js';
import { uid } from './format.js';

export const CHAIN_STATUS = {
  awaiting_approval: { label: 'Awaiting approvals', tone: 'gold' },
  confirmed: { label: 'Confirmed - ready to ship', tone: 'green' },
  in_delivery: { label: 'In delivery', tone: 'green' },
  completed: { label: 'Completed', tone: 'green' },
  cancelled: { label: 'Cancelled', tone: 'red' },
};

export const APPROVAL_LABEL = {
  pending: 'Waiting',
  approved: 'Approved',
  declined: 'Declined',
};

export const DELIVERY_LABEL = {
  not_dispatched: 'Not dispatched',
  dispatched: 'On the way',
  delivered: 'Delivered',
  return_pending: 'Return pending',
  returned: 'Returned to owner',
  cancelled: 'Cancelled - kept by owner',
};

const log = (chain, text) => ({ ...chain, log: [{ ts: Date.now(), text }, ...chain.log] });

/** Build a chain record (with snapshots of titles/values) from a matcher result. */
export function buildChainRecord(found, users, listings, { simulated = false, createdBy = null } = {}) {
  const userById = new Map(users.map((u) => [u.id, u]));
  const listingById = new Map(listings.map((l) => [l.id, l]));
  const participants = found.participants.map((p) => {
    const u = userById.get(p.userId);
    const give = listingById.get(p.giveListingId);
    const receive = listingById.get(p.receiveListingId);
    return {
      userId: p.userId,
      name: u?.name || 'Reader',
      city: u?.city || '',
      state: u?.state || '',
      giveListingId: p.giveListingId,
      giveTitle: give?.title || '',
      giveAuthor: give?.author || '',
      giveValue: Number(give?.exchangeValue) || 0,
      receiveListingId: p.receiveListingId,
      receiveTitle: receive?.title || '',
      receiveValue: Number(receive?.exchangeValue) || 0,
      wantMatched: p.wantMatched,
      approval: 'pending',
      delivery: 'not_dispatched',
    };
  });
  const calc = calcChain(participants.map((p) => p.giveValue), { closed: true });
  return {
    id: uid('chain'),
    code: found.code,
    createdAt: Date.now(),
    createdBy,
    simulated,
    status: 'awaiting_approval',
    participants,
    links: calc.links,
    net: calc.net,
    totalDifference: calc.totalDifference,
    totalCommission: calc.totalCommission,
    cancelSummary: null,
    log: [
      {
        ts: Date.now(),
        text: `Chain proposed with ${participants.length} participants. Every participant must approve before it is confirmed.`,
      },
    ],
  };
}

export function approveParticipant(chain, idx) {
  if (chain.status !== 'awaiting_approval') return chain;
  const p = chain.participants[idx];
  if (!p || p.approval !== 'pending') return chain;
  const participants = chain.participants.map((x, i) => (i === idx ? { ...x, approval: 'approved' } : x));
  let next = log({ ...chain, participants }, `${p.name} approved the chain.`);
  if (participants.every((x) => x.approval === 'approved')) {
    next = log({ ...next, status: 'confirmed' }, `All ${participants.length} participants approved. Chain confirmed.`);
  }
  return next;
}

export function approveAllOthers(chain, myIdx) {
  let next = chain;
  chain.participants.forEach((_, i) => {
    if (i !== myIdx) next = approveParticipant(next, i);
  });
  return next;
}

export function dispatchBook(chain, idx) {
  if (chain.status !== 'confirmed' && chain.status !== 'in_delivery') return chain;
  const p = chain.participants[idx];
  if (!p || p.delivery !== 'not_dispatched') return chain;
  const participants = chain.participants.map((x, i) => (i === idx ? { ...x, delivery: 'dispatched' } : x));
  const receiver = chain.participants[(idx + 1) % chain.participants.length];
  return log({ ...chain, participants, status: 'in_delivery' }, `${p.name} dispatched "${p.giveTitle}" to ${receiver.name}.`);
}

// The RECEIVER confirms that the book given by participant `giverIdx` has arrived.
export function confirmReceived(chain, giverIdx) {
  if (chain.status !== 'in_delivery') return chain;
  const p = chain.participants[giverIdx];
  if (!p || p.delivery !== 'dispatched') return chain;
  const participants = chain.participants.map((x, i) => (i === giverIdx ? { ...x, delivery: 'delivered' } : x));
  const receiver = chain.participants[(giverIdx + 1) % chain.participants.length];
  let next = log({ ...chain, participants }, `${receiver.name} confirmed receiving "${p.giveTitle}".`);
  if (participants.every((x) => x.delivery === 'delivered')) {
    next = log({ ...next, status: 'completed' }, 'Every book was delivered. Exchange chain completed.');
  }
  return next;
}

export function simulateDelivery(chain) {
  let next = chain;
  chain.participants.forEach((_, i) => {
    next = dispatchBook(next, i);
  });
  chain.participants.forEach((_, i) => {
    next = confirmReceived(next, i);
  });
  return next;
}

/**
 * Cancel handling:
 *  - not yet dispatched  -> released, owner keeps the book
 *  - on the way          -> marked "return pending" so the owner gets it back
 *  - already delivered   -> stays with the receiver; flagged for follow-up between the two people
 */
export function cancelChain(chain, byName, reason) {
  if (chain.status === 'completed' || chain.status === 'cancelled') return chain;
  let returns = 0;
  let delivered = 0;
  const participants = chain.participants.map((p) => {
    if (p.delivery === 'dispatched') {
      returns += 1;
      return { ...p, delivery: 'return_pending' };
    }
    if (p.delivery === 'delivered') {
      delivered += 1;
      return p;
    }
    return { ...p, delivery: 'cancelled' };
  });
  const summary = { by: byName, reason: reason || 'No reason given', returns, delivered };
  return log(
    { ...chain, participants, status: 'cancelled', cancelSummary: summary },
    `${byName} cancelled the chain. ${returns} book(s) to be returned, ${delivered} already delivered.`,
  );
}

export function markReturned(chain, idx) {
  const p = chain.participants[idx];
  if (!p || p.delivery !== 'return_pending') return chain;
  const participants = chain.participants.map((x, i) => (i === idx ? { ...x, delivery: 'returned' } : x));
  return log({ ...chain, participants }, `"${p.giveTitle}" was returned to ${p.name}.`);
}

export function chainProgress(chain) {
  const n = chain.participants.length;
  return {
    total: n,
    approved: chain.participants.filter((p) => p.approval === 'approved').length,
    dispatched: chain.participants.filter((p) => ['dispatched', 'delivered'].includes(p.delivery)).length,
    delivered: chain.participants.filter((p) => p.delivery === 'delivered').length,
  };
}

export const isActiveChain = (c) => c.status !== 'cancelled' && c.status !== 'completed';
