// 50-50 price difference rules for Ex-Book exchanges.
//
// A "link" compares the agreed values of the TWO books in that link.
//   - The owner of the LOWER-value book pays the difference.
//   - 50% of the difference goes to the owner of the HIGHER-value book.
//   - 50% goes to Ex-Book as commission.
// All maths is done in paise (integers) so there are no floating point errors.
// If the difference has an odd number of paise, the extra paisa goes to Ex-Book,
// so ownerShare + commission always equals the difference exactly.

const toPaise = (rupees) => Math.round(Number(rupees) * 100);
const toRupees = (paise) => paise / 100;

export function calcLink(valueA, valueB) {
  const a = toPaise(valueA);
  const b = toPaise(valueB);
  if (!Number.isFinite(a) || !Number.isFinite(b) || a < 0 || b < 0) return null;

  const diff = Math.abs(a - b);
  const ownerShare = Math.floor(diff / 2);
  const commission = diff - ownerShare;
  const equal = diff === 0;
  const lower = equal ? null : a < b ? 'A' : 'B';
  const higher = equal ? null : a < b ? 'B' : 'A';

  return {
    valueA: toRupees(a),
    valueB: toRupees(b),
    difference: toRupees(diff),
    ownerShare: toRupees(ownerShare),
    commission: toRupees(commission),
    equal,
    payer: lower, // side ('A' | 'B') that owns the lower-value book and pays
    receiver: higher, // side that owns the higher-value book and receives the owner share
  };
}

// values[i] is the agreed value of participant i's book.
// In a closed ring, link k pairs book k with book k+1 (the last wraps to the first).
// Every link is calculated on its own - never highest vs lowest across the whole chain.
export function calcChain(values, { closed = true } = {}) {
  const n = values.length;
  const links = [];
  const net = new Array(n).fill(0);
  let totalDifference = 0;
  let totalCommission = 0;

  if (n < 2) return { links, net, totalDifference, totalCommission, valid: false };

  // A closed ring of 2 would repeat the same pair twice, so it is a single link.
  const linkCount = closed && n > 2 ? n : n - 1;

  for (let k = 0; k < linkCount; k += 1) {
    const from = k;
    const to = (k + 1) % n;
    const result = calcLink(values[from], values[to]);
    if (!result) return { links: [], net, totalDifference: 0, totalCommission: 0, valid: false };

    const payerIdx = result.payer === 'A' ? from : result.payer === 'B' ? to : null;
    const receiverIdx = result.receiver === 'A' ? from : result.receiver === 'B' ? to : null;

    if (payerIdx !== null) {
      net[payerIdx] = round2(net[payerIdx] - result.difference);
      net[receiverIdx] = round2(net[receiverIdx] + result.ownerShare);
    }
    totalDifference = round2(totalDifference + result.difference);
    totalCommission = round2(totalCommission + result.commission);
    links.push({ index: k, from, to, ...result, payerIdx, receiverIdx });
  }

  return { links, net, totalDifference, totalCommission, valid: true };
}

function round2(n) {
  return Math.round(n * 100) / 100;
}
