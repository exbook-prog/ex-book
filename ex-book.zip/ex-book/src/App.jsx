import { Component, useEffect } from 'react';
import { HashRouter, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { AppProvider } from './context/AppContext.jsx';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import Toasts from './components/Toasts.jsx';
import Home from './pages/Home.jsx';
import { Browse, Buy } from './pages/Browse.jsx';
import BookDetail from './pages/BookDetail.jsx';
import Sell from './pages/Sell.jsx';
import MyListings from './pages/MyListings.jsx';
import Messages from './pages/Messages.jsx';
import Exchange from './pages/Exchange.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Login from './pages/Login.jsx';
import NotFound from './pages/NotFound.jsx';

// Scroll to the top on navigation, or to an in-page section such as /exchange#calculator.
function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.slice(1));
      if (el) {
        el.scrollIntoView();
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [pathname, hash]);
  return null;
}

function Layout() {
  return (
    <>
      <button
        type="button"
        className="skip-link"
        onClick={() => document.getElementById('main')?.focus()}
      >
        Skip to content
      </button>
      <Navbar />
      <main id="main" tabIndex={-1} className="main">
        <Outlet />
      </main>
      <Footer />
      <Toasts />
    </>
  );
}

// If saved demo data is ever corrupted, offer a one-click reset instead of a blank page.
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  reset = () => {
    try {
      localStorage.removeItem('exbook.demo.state');
    } catch {
      /* ignore */
    }
    window.location.hash = '#/';
    window.location.reload();
  };

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="container page">
        <div className="card gate">
          <h2>Something went wrong</h2>
          <p>The demo data saved in this browser may be out of date. Resetting it brings back the sample books.</p>
          <button type="button" className="btn btn--primary" onClick={this.reset}>
            Reset demo data and reload
          </button>
        </div>
      </div>
    );
  }
}

// HashRouter keeps every page working on any static host (Cloudflare Pages, GitHub Pages, ...)
// with no server rewrite rules, including a refresh on a deep link.
export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <HashRouter>
          <ScrollManager />
          <Routes>
            <Route element={<Layout />}>
              <Route path="/" element={<Home />} />
              <Route path="/browse" element={<Browse />} />
              <Route path="/buy" element={<Buy />} />
              <Route path="/book/:id" element={<BookDetail />} />
              <Route path="/sell" element={<Sell />} />
              <Route path="/my-listings" element={<MyListings />} />
              <Route path="/exchange" element={<Exchange />} />
              <Route path="/messages" element={<Messages />} />
              <Route path="/messages/:id" element={<Messages />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/dashboard/:section" element={<Dashboard />} />
              <Route path="/login" element={<Login />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </HashRouter>
      </AppProvider>
    </ErrorBoundary>
  );
}
