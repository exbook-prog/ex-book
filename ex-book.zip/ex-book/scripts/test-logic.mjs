// Logic tests for pricing and circular exchange matching. Run with: npm test
import assert from 'node:assert/strict';
import { calcLink, calcChain } from '../src/utils/pricing.js';
import { findChains, generateLabCommunity } from '../src/utils/matching.js';
import { createSeedState, createLabPool } from '../src/data/seed.js';
import {
  buildChainRecord,
  approveParticipant,
  dispatchBook,
  confirmReceived,
  cancelChain,
  simulateDelivery,
} from '../src/utils/chainFlow.js';
import { filterBooks, EMPTY_FILTERS } from '../src/utils/filters.js';

let passed = 0;
const test = (name, fn) => {
  fn();
  passed += 1;
  console.log(`  ok  ${name}`);
};

console.log('Pricing');
test('spec example: A=200, B=350 -> diff 150, 75 to owner, 75 to Ex-Book', () => {
  const r = calcLink(200, 350);
  assert.equal(r.difference, 150);
  assert.equal(r.ownerShare, 75);
  assert.equal(r.commission, 75);
  assert.equal(r.payer, 'A'); // owner of the lower-value book pays
  assert.equal(r.receiver, 'B');
});
test('order of arguments does not change who pays', () => {
  const r = calcLink(350, 200);
  assert.equal(r.payer, 'B');
  assert.equal(r.receiver, 'A');
  assert.equal(r.difference, 150);
});
test('equal values -> no payment', () => {
  const r = calcLink(250, 250);
  assert.equal(r.difference, 0);
  assert.equal(r.payer, null);
});
test('odd paise are never lost: ownerShare + commission = difference', () => {
  const r = calcLink(100, 100.01);
  assert.equal(Math.round((r.ownerShare + r.commission) * 100), Math.round(r.difference * 100));
});
test('chain: every link is calculated separately (not highest vs lowest)', () => {
  const c = calcChain([200, 350, 100, 300], { closed: true });
  assert.equal(c.links.length, 4);
  assert.deepEqual(
    c.links.map((l) => l.difference),
    [150, 250, 200, 100],
  );
  assert.equal(c.totalDifference, 700);
  assert.equal(c.totalCommission, 350);
});
test('two-person swap is a single link', () => {
  assert.equal(calcChain([200, 350], { closed: true }).links.length, 1);
});
test('net settlement across a chain sums to minus the commission', () => {
  const c = calcChain([200, 350, 100, 300, 120, 80], { closed: true });
  const sum = c.net.reduce((a, b) => a + b, 0);
  assert.equal(Math.round(sum * 100), -Math.round(c.totalCommission * 100));
});

console.log('Matching (sample community)');
const seed = createSeedState();
const found = findChains(seed.users, seed.listings, { minLen: 2, limit: 50 });
test('finds several chains in the seeded community', () => {
  assert.ok(found.chains.length >= 3, `expected >= 3 chains, got ${found.chains.length}`);
});
test('finds an 8-person ring, a 4-person ring and a larger loop', () => {
  const sizes = found.chains.map((c) => c.size);
  assert.ok(sizes.includes(8), `sizes: ${sizes}`);
  assert.ok(sizes.includes(4), `sizes: ${sizes}`);
  assert.ok(Math.max(...sizes) > 8, `largest: ${Math.max(...sizes)}`);
});
test('every participant gives one book and receives one book, all distinct', () => {
  found.chains.forEach((c) => {
    const gives = c.participants.map((p) => p.giveListingId);
    const gets = c.participants.map((p) => p.receiveListingId);
    assert.equal(new Set(gives).size, c.size);
    assert.equal(new Set(gets).size, c.size);
    assert.deepEqual([...gives].sort(), [...gets].sort());
    assert.equal(new Set(c.participants.map((p) => p.userId)).size, c.size);
    c.participants.forEach((p, i) => {
      assert.equal(p.receiveListingId, c.participants[(i - 1 + c.size) % c.size].giveListingId);
    });
  });
});
test('a user with an unsatisfiable want is not placed in any chain', () => {
  const inChain = found.chains.some((c) => c.participants.some((p) => p.userId === 'u13'));
  assert.equal(inChain, false);
});
test('mustInclude only returns chains containing that user', () => {
  const r = findChains(seed.users, seed.listings, { mustInclude: 'u1', limit: 50 });
  assert.ok(r.chains.length > 0);
  r.chains.forEach((c) => assert.ok(c.participants.some((p) => p.userId === 'u1')));
});
test('maxLen limits chain size; maxGap can remove chains', () => {
  const small = findChains(seed.users, seed.listings, { maxLen: 5 });
  small.chains.forEach((c) => assert.ok(c.size <= 5));
  const strict = findChains(seed.users, seed.listings, { maxGap: 1 });
  assert.ok(strict.chains.length < found.chains.length);
});
test('no chain is returned when no compatible match exists', () => {
  const users = seed.users.map((u) => ({ ...u, wants: ['A book nobody has ever listed'] }));
  assert.equal(findChains(users, seed.listings).chains.length, 0);
});

console.log('Matching (Chain Lab: variable sizes)');
const pool = createLabPool();
[4, 8, 15, 25, 50].forEach((n) => {
  test(`finds a ${n}-person circular chain`, () => {
    const lab = generateLabCommunity(n, pool);
    const r = findChains(lab.users, lab.listings, { limit: 5, minLen: 2 });
    assert.ok(r.chains.length >= 1, 'no chain');
    assert.equal(r.chains[0].size, n, `largest chain was ${r.chains[0].size}`);
    const calc = r.chains[0];
    assert.ok(calc.totalCommission >= 0);
  });
});

console.log('Chain workflow');
test('needs every approval, then ships, then completes', () => {
  const chain8 = found.chains.find((c) => c.size === 8);
  let chain = buildChainRecord(chain8, seed.users, seed.listings);
  assert.equal(chain.status, 'awaiting_approval');
  for (let i = 0; i < 7; i += 1) chain = approveParticipant(chain, i);
  assert.equal(chain.status, 'awaiting_approval'); // 7 of 8 is not enough
  chain = approveParticipant(chain, 7);
  assert.equal(chain.status, 'confirmed');
  chain = simulateDelivery(chain);
  assert.equal(chain.status, 'completed');
});
test('cancellation releases undispatched books and flags dispatched ones for return', () => {
  const chain4 = found.chains.find((c) => c.size === 4);
  let chain = buildChainRecord(chain4, seed.users, seed.listings);
  chain.participants.forEach((_, i) => {
    chain = approveParticipant(chain, i);
  });
  chain = dispatchBook(chain, 0);
  chain = dispatchBook(chain, 1);
  chain = confirmReceived(chain, 1);
  chain = cancelChain(chain, 'Test', 'changed my mind');
  assert.equal(chain.status, 'cancelled');
  assert.equal(chain.participants[0].delivery, 'return_pending');
  assert.equal(chain.participants[1].delivery, 'delivered');
  assert.equal(chain.participants[2].delivery, 'cancelled');
  assert.equal(chain.cancelSummary.returns, 1);
  assert.equal(chain.cancelSummary.delivered, 1);
});

console.log('Filters');
test('buy mode shows only listings with a sale price', () => {
  const r = filterBooks(seed.listings, EMPTY_FILTERS, { mode: 'buy' });
  assert.ok(r.length > 0 && r.every((l) => l.price != null));
});
test('class + subject + board filters combine', () => {
  const r = filterBooks(seed.listings, { ...EMPTY_FILTERS, cat: 'class-10', subject: 'Mathematics', board: 'CBSE' });
  assert.ok(r.length >= 2 && r.every((l) => l.classLevel === 10 && l.subject === 'Mathematics' && l.board === 'CBSE'));
});
test('price sort and PIN prefix filter work', () => {
  const r = filterBooks(seed.listings, { ...EMPTY_FILTERS, sort: 'price-asc' }, { mode: 'buy' });
  for (let i = 1; i < r.length; i += 1) assert.ok(r[i - 1].price <= r[i].price);
  const pin = filterBooks(seed.listings, { ...EMPTY_FILTERS, pin: '1100' });
  assert.ok(pin.length > 0 && pin.every((l) => l.pin.startsWith('1100')));
});
test('seed has exactly one cover field per book and no extra image fields', () => {
  seed.listings.forEach((l) => {
    assert.ok('cover' in l);
    assert.ok(!('images' in l) && !('backCover' in l) && !('photos' in l));
  });
});

console.log(`\n${passed} tests passed`);
